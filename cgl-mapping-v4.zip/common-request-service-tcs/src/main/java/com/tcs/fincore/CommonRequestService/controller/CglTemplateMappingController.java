package com.tcs.fincore.CommonRequestService.controller;

import com.tcs.fincore.CommonRequestService.client.TemplateBindingClient;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Read-only gateway for the CGL code page, so the UI only talks to this service.
 * Answers are the Template service's JSON ({status, message, data}) passed through unchanged.
 */
@RestController
@RequestMapping("/api/cgl-mappings")
@RequiredArgsConstructor
public class CglTemplateMappingController {

    private final TemplateBindingClient client;

    /** Existing mappings of a CGL in all enabled reports (data.reports[].mappings = submit payload shape). */
    @GetMapping("/by-cgl/{cglNumber}")
    public ResponseEntity<String> byCgl(@PathVariable String cglNumber,
                                        @RequestHeader("Authorization") String token) {
        return json(client.mappingsOfCglJson(cglNumber, token));
    }

    /** Picker: mappable Heads / variables / columns of one report. */
    @GetMapping("/targets")
    public ResponseEntity<String> targets(@RequestParam String reportId,
                                          @RequestParam(required = false) String q,
                                          @RequestHeader("Authorization") String token) {
        return json(client.targetsJson(reportId, q, token));
    }

    @GetMapping("/reports")
    public ResponseEntity<String> reports(@RequestHeader("Authorization") String token) {
        return json(client.reportsJson(token));
    }

    private static ResponseEntity<String> json(String body) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(body);
    }
}
