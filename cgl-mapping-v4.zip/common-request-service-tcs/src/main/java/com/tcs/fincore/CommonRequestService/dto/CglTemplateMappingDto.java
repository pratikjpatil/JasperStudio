package com.tcs.fincore.CommonRequestService.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * One Head (+ Variable) of a report template the CGL is mapped to. Plain text the UI already shows
 * (GET /api/cgl-mappings/... returns exactly this shape); no internal ids or versions.
 * Resolved by the Template service against the ACTIVE template.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CglTemplateMappingDto {

    /** NWSA | YSA | PNL | PFORM (any report enabled in the Template service). */
    @NotBlank(message = "reportId is required for a template mapping")
    private String reportId;

    /** Head code: CODE NO. (NWSA), YSA CODE (YSA), Sr. no. (PNL). Give code and/or head. */
    private String code;

    /** Head text: DESCRIPTION (NWSA), NOMENCLATURE (YSA), Head (PNL). */
    private String head;

    /** Optional, to tell apart rows sharing a head (PNL). */
    private String subHead;

    /** Variable name (N, Normal ...). Optional when the head has a single variable. */
    private String variable;

    /** Optional amount column names. Empty/null = every column carrying the variable (PNL: both). */
    private List<String> columns;
}
