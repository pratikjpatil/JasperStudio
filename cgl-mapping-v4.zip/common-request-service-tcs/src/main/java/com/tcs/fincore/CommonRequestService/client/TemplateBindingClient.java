package com.tcs.fincore.CommonRequestService.client;

import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.*;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.function.Supplier;

/**
 * Calls the Template Configuration Service with the caller's own JWT (so it authenticates and audits the real user).
 * JSON is handled by Spring's message converters only: no ObjectMapper/JsonMapper dependency here.
 *
 * 4xx -> BusinessRuleViolationException (HTTP 400 to the UI with the Template service's message).
 * Anything else (5xx, timeout, I/O) -> IllegalStateException, which rolls the CGL approval back so nothing is
 * half-applied. apply is idempotent on the request id, so the checker can simply retry.
 */
@Slf4j
@Component
public class TemplateBindingClient {

    private static final String BASE = "/api/template-config/cgl-mappings";

    private final RestClient restClient;

    public TemplateBindingClient(RestClient.Builder builder,
                                 @Value("${template.service.base-url}") String baseUrl,
                                 @Value("${template.service.connect-timeout-ms:3000}") int connectTimeoutMs,
                                 @Value("${template.service.read-timeout-ms:30000}") int readTimeoutMs) {
        HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(connectTimeoutMs)).build();
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpClient);
        factory.setReadTimeout(Duration.ofMillis(readTimeoutMs));
        this.restClient = builder.clone().baseUrl(baseUrl).requestFactory(factory).build();
    }

    public ValidateResponse validate(ValidateRequest request, String token) {
        return unwrap("validate", () -> restClient.post().uri(BASE + "/validate")
                .header(HttpHeaders.AUTHORIZATION, token).body(request).retrieve()
                .body(new ParameterizedTypeReference<Envelope<ValidateResponse>>() {
                }));
    }

    public ApplyResult apply(ApplyRequest request, String token) {
        return unwrap("apply", () -> restClient.post().uri(BASE + "/apply")
                .header(HttpHeaders.AUTHORIZATION, token).body(request).retrieve()
                .body(new ParameterizedTypeReference<Envelope<ApplyResult>>() {
                }));
    }

    /** Raw JSON pass-through for the UI (picker). */
    public String targetsJson(String reportId, String q, String token) {
        return raw("targets", () -> restClient.get()
                .uri(u -> u.path(BASE + "/targets").queryParam("reportId", reportId)
                        .queryParamIfPresent("q", java.util.Optional.ofNullable(q)).build())
                .header(HttpHeaders.AUTHORIZATION, token).retrieve().body(String.class));
    }

    /** Raw JSON pass-through for the UI (existing mappings of a CGL). */
    public String mappingsOfCglJson(String cglNumber, String token) {
        return raw("by-cgl", () -> restClient.get().uri(BASE + "/by-cgl/{cgl}", cglNumber)
                .header(HttpHeaders.AUTHORIZATION, token).retrieve().body(String.class));
    }

    public String reportsJson(String token) {
        return raw("reports", () -> restClient.get().uri(BASE + "/reports")
                .header(HttpHeaders.AUTHORIZATION, token).retrieve().body(String.class));
    }

    // ------------------------------------------------------------------

    private <T> T unwrap(String op, Supplier<Envelope<T>> call) {
        Envelope<T> env = raw(op, call);
        if (env == null || env.getData() == null) {
            throw new IllegalStateException("Template service returned an empty answer for " + op + "; please retry.");
        }
        return env.getData();
    }

    private <T> T raw(String op, Supplier<T> call) {
        try {
            return call.get();
        } catch (HttpClientErrorException e) {
            throw new BusinessRuleViolationException(messageOf(e));
        } catch (RestClientException e) {
            log.error("Template service call failed: {}", op, e);
            throw new IllegalStateException("Template service is unavailable or failed; the request was not processed. "
                    + "Please retry. (" + e.getMessage() + ")", e);
        }
    }

    private String messageOf(HttpClientErrorException e) {
        try {
            ErrorBody body = e.getResponseBodyAs(ErrorBody.class);
            if (body != null && body.getMessage() != null && !body.getMessage().isBlank()) {
                return body.getMessage();
            }
        } catch (RuntimeException ignored) {
            // fall through
        }
        return "Template service rejected the CGL mapping (HTTP " + e.getStatusCode().value() + ")";
    }
}
