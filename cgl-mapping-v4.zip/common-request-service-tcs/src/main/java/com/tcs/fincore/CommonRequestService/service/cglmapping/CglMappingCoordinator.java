package com.tcs.fincore.CommonRequestService.service.cglmapping;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingClient;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ApplyRequest;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ApplyResult;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ValidateRequest;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ValidateResponse;
import com.tcs.fincore.CommonRequestService.dto.CglPayloadDto;
import com.tcs.fincore.CommonRequestService.dto.CglTemplateMappingDto;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.ChangeType;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;
import java.util.stream.Collectors;

/**
 * The only CGL-mapping logic inside the Common Request Service. CglCodeStrategy just delegates to it, so the
 * existing CGL master handling and every other request type (currency, segment ...) stay untouched.
 *
 * Rules
 *  - Only CGL ADD and non-blocking UPDATE touch templates. BLOCK / UNBLOCK / UPDATE-to-blocked never do.
 *  - templateMappings == null  -> mappings not edited in this request: nothing to do (UI omits it when untouched).
 *  - templateMappings == []    -> UPDATE: remove the CGL from all templates (rejected when enforcement is on).
 *  - the list is the COMPLETE desired mapping set; the Template service computes the difference.
 *  - validateOnSubmit never writes; applyOnApproval is the last step of the approval transaction and any failure
 *    throws, rolling the approval back.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CglMappingCoordinator {

    private static final String REQUIRED_MSG =
            "At least one Head/Variable mapping in the NWSA / YSA / PNL / PFORM templates is required for a CGL.";
    private static final int STATUS_BLOCKED = 0;

    private final TemplateBindingClient client;

    /** Own mapper: no dependency on how the application wires its ObjectMapper/JsonMapper bean. */
    private final JsonMapper jsonMapper = JsonMapper.builder().build();

    /** When true, every CGL create / non-block update must carry at least one mapping. */
    @Value("${cgl.mapping.enforced:false}")
    private boolean enforced;

    /** Maker submit. */
    public void validateOnSubmit(CreateRequestDto dto, String token) {
        if (!(dto.getPayload() instanceof CglPayloadDto payload)) {
            return;
        }
        if (!touchesTemplates(dto.getChangeType(), payload.getStatus())) {
            return;
        }
        List<CglTemplateMappingDto> mappings = payload.getTemplateMappings();
        if (mappings == null || mappings.isEmpty()) {
            if (enforced) {
                throw new BusinessRuleViolationException(REQUIRED_MSG);
            }
            return;
        }
        ValidateResponse result = client.validate(new ValidateRequest(payload.getKey(), enforced, mappings), token);
        if (!result.isValid()) {
            throw new BusinessRuleViolationException(String.join("; ", result.getErrors()));
        }
    }

    /** Checker approval, after the CGL master and the request status are flushed. */
    public void applyOnApproval(CommonReq request, String token) {
        ChangeType changeType = request.getChangeType();
        PayloadView p = jsonMapper.readValue(request.getPayload(), PayloadView.class);
        if (!touchesTemplates(changeType, p.getStatus())) {
            return;
        }
        List<CglTemplateMappingDto> mappings = p.getTemplateMappings();
        if (mappings == null) {
            if (enforced) {
                throw new BusinessRuleViolationException("CGL request has no template mappings; approval is not possible.");
            }
            return;                                              // legacy request / mappings not edited
        }
        if (mappings.isEmpty() && (enforced || changeType == ChangeType.ADD)) {
            if (enforced) {
                throw new BusinessRuleViolationException(REQUIRED_MSG);
            }
            return;
        }

        ApplyRequest apply = new ApplyRequest();
        apply.setCommonReqId(request.getId());
        apply.setChangeType(changeType.name());
        apply.setCglNumber(p.getComp1() + p.getSegmentCode() + p.getComp2());
        apply.setMakerId(request.getCreatorId());
        apply.setRequireMapping(enforced);
        apply.setMappings(mappings);

        ApplyResult result = client.apply(apply, token);

        String summary = result.getChanges().isEmpty()
                ? "No template change needed."
                : result.getChanges().stream()
                        .map(c -> c.getReportId() + " v" + c.getFromVersion() + "->v" + c.getToVersion())
                        .collect(Collectors.joining(", "));
        request.setExecutionRemarks("Successfully processed approval. Template mappings: " + summary);
        log.info("CGL {} mapped in templates for request {}: {}", apply.getCglNumber(), request.getId(), summary);
    }

    private static boolean touchesTemplates(ChangeType changeType, Integer status) {
        if (changeType != ChangeType.ADD && changeType != ChangeType.UPDATE) {
            return false;
        }
        return !(changeType == ChangeType.UPDATE && status != null && status == STATUS_BLOCKED);
    }

    /** The few payload fields this class needs; everything else in the stored payload is ignored. */
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class PayloadView {
        private String comp1;
        private String segmentCode;
        private String comp2;
        private Integer status;
        private List<CglTemplateMappingDto> templateMappings;
    }
}
