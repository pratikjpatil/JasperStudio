# CGL → Report Template mapping (v4) — handover + design

## Read this first
- **No network in my sandbox, so I could NOT re-clone `common-request-service-tcs` (feature/16-11-26).** I worked from `cgl-mapping-3.zip`.
  The CRS files in that zip use Jackson 2 imports, so they are from stale code. To avoid depending on it, **all new CRS logic is in
  new files** (Jackson-3, no changes to other request types) and the 4 edits to existing CRS files are tiny snippets in `CRS_INTEGRATION.md`.
- Nothing was compiled (no Maven deps offline). No unit tests, as requested. Dry run is at the bottom.
- TCS folder is a complete drop-in over `template-config-service` (feature/28-10-26). **Delete** `cglmapping/CglMappingService.java` if you applied the earlier patch.

## What changed vs the previous output (the FE problem)
Old payload needed `rowId`, `cellId`, `baseVersion`, `fingerprint` — data the FE does not have.
New payload is plain text the screens already show, resolved server-side against the ACTIVE template at validate/apply time:

```json
"templateMappings": [
  {"reportId":"NWSA","code":"L01","head":"Example liability","variable":"Normal"},
  {"reportId":"YSA","code":"1","head":"Example Head","variable":"N"},
  {"reportId":"PNL","head":"Cash","subHead":"Cash in hand","variable":"N"},
  {"reportId":"PNL","head":"Adjustment","variable":"N","columns":["AMOUNT"]}
]
```
- Give `code` and/or `head` (+ optional `subHead`); all given fields must match (case/space-insensitive).
- `variable` optional if the Head has a single variable name; else `VARIABLE_REQUIRED` lists the choices.
- `columns` optional: omitted = **every column carrying the variable** (PNL's two amount columns are both updated).
- The list is the **complete desired set** for the CGL. Moving a CGL A→B = send only B; A is removed in the same new version.
- `templateMappings` **omitted/null = not edited** → nothing happens (FE must omit it when the user didn't touch mappings).
- Errors are explicit: `HEAD_NOT_FOUND`, `HEAD_AMBIGUOUS` (lists candidates), `HEAD_NOT_MAPPABLE` (calculated row),
  `VARIABLE_REQUIRED/NOT_FOUND`, `COLUMN_NOT_FOUND`.

## Endpoints
CRS (what the FE calls; pass-through to TCS, JWT forwarded):
| GET | purpose |
|---|---|
| `/api/cgl-mappings/by-cgl/{cgl}` | **existing mappings of a CGL in all 4 reports** for the CGL code page |
| `/api/cgl-mappings/targets?reportId=PNL&q=` | picker: mappable Heads → variables → columns |
| `/api/cgl-mappings/reports` | enabled reports (tabs; no hard-coded four) |

`by-cgl` returns `data = {cglNumber, mapped, reports:[{reportId,status(OK|NO_ACTIVE_TEMPLATE|ERROR),templateId,version,mappings:[selector…]}]}`.
`mappings[]` has the same shape as the submit payload, so the screen can load → edit → post back unchanged.
Targets: `data = {reportId,templateId,version,heads:[{code,head,subHead,variables:[{name,type,columns,otherFilters,cglCount}]}]}`.

TCS (internal): same under `/api/template-config/cgl-mappings/` plus `POST /validate`, `POST /apply`, `GET /unmapped`.

## Flow (unchanged shape, one transaction)
1. Maker submits CGL request → `CglCodeStrategy.validateRequest` → `CglMappingCoordinator.validateOnSubmit` → TCS `/validate` (dry run).
2. Checker approves → CRS saves CGL master/status → last step `afterApprovalFlushed` → TCS `/apply`:
   lock ACTIVE templates (ascending report order) → resolve selectors → diff vs current → edit CGL IN-lists → archive old version to
   history → new version → audit row in `RB_TEMPLATE_REQUEST` (CGL_MAP, maker, checker, time, "CGL code ADD/UPDATE", CRS req id).
   Any exception → CRS approval rolls back. Apply is idempotent on the CRS request id (retry-safe).
3. `CglMappingReconciler` (TCS) covers the CRS-commit-failed-after-TCS-commit window by reading `COMMON_REQ`: accepted → confirm, else → inverse new version.
BLOCK/UNBLOCK/UPDATE-to-blocked never touch templates.

## TCS code structure (SOLID)
| class | single responsibility |
|---|---|
| `ReportMappingProfile` (+`ConfiguredReportProfile`, `ReportProfileRegistry`) | everything report-specific (head/code/sub column, eligible types, filter shape, filter key). **New report = properties or one bean; no service changes (OCP).** |
| `MappingTargetExtractor` | template JSON → rows + carriers |
| `SelectorResolver` | selector → carriers (pure, no I/O) |
| `CglFilterCodec` | read/add/remove CGL IN-list in array or object shape |
| `MappingViews` | carriers → UI selectors (inverse of resolver) |
| `MappingQueryService` | picker, by-CGL, unmapped list |
| `MappingValidator` | dry run |
| `CglMappingApplier` | apply (diff + orchestration) |
| `MappingEditor` | the only JSON-edit + audit-description step |
| `TemplateVersionWriter` | archive → next version → audit row → save |
| `CglMappingCompensator` | confirm / revert (reconciler) |
| `ActiveTemplates`, `CglMembership`, `TemplateWriteGuard` | template access; CGL membership; optional guard (off by default) |

## Config (defaults keep existing behaviour)
TCS `cgl.mapping.guard-enabled=false`, `stale-guard-enabled=false`, `reconcile-enabled=true`; CRS `cgl.mapping.enforced=false`.
Rollout: run `cgl_template_mapping.sql` → deploy TCS → deploy CRS → use `/unmapped` to back-fill → switch guards/enforced on.
PFORM: no sample seen; defaults assume `Head` / `Sr. no.`, DB_SUM, array filter. Override with `cgl.mapping.reports.PFORM.*`.

## Behaviours to know
- Head text is matched at approval time. If someone renames a Head in the template between submit and approval, apply fails with `HEAD_NOT_FOUND` and the approval rolls back (checker rejects, maker resubmits). Hence FE must omit `templateMappings` unless edited.
- Removing the last CGL of a variable's list is refused (`EMPTY_IN_LIST`, `cgl.mapping.empty-list-policy=BLOCK`). Moving a Head's only CGL needs `ALLOW_EMPTY` after confirming the report engine treats an empty IN list as no rows.
- `by-cgl` parses 4 active template JSONs per call (no cache). Fine for a single CGL page; add a (templateId, version)-keyed cache if it becomes hot.
- Pending (not yet approved) CGL requests are not reflected in `by-cgl`; it shows approved state only.

## Dry run (on the 3 sample templates you pasted)
- **PNL**: cols `Sr. no./Category/Head/Sub Head/BID/AMOUNT`. Carriers: R__1 N(DB_SUM, AMOUNT), R__2 N(DB_AVG), R__5 N. R__3/R__4 are formula-only → no carriers.
  `{PNL, head:"Cash", variable:"N"}` → R__1 ✔. `{PNL, head:"Combined"}` → `HEAD_NOT_MAPPABLE` ✔. `{PNL, head:"Cash"}` without variable → single name `N` → ✔.
  by-cgl for `2001` → `{PNL, code:"2", head:"Average", variable:"N"}` (columns null = all). Adding `5001` to R__1 → new version v+1, history row for v, audit row CGL_MAP.
- **NWSA**: head col `DESCRIPTION`, code `CODE NO.`. R__1 variable `Normal` carries `CGL:[{IN,[1001,1002]}]`; `L99/A99` have `variables:{}` → not mappable. A head with Normal+Debit_Pos+… needs `variable`.
- **YSA**: `filters.CGL` is a single object; codec reads/edits it in place and creates new CGL filters in object shape (profile `OBJECT`). Column `NOMENCLATURE`, code `YSA CODE`; R__2 (`value:null`) not mappable.
- **Move A→B (PNL, 2 amount columns)**: selector B without `columns` → both columns' `N` carriers get the CGL; A's carriers lose it; one version, one audit row, both in `changes[]`.
- **Replay**: same `commonReqId` again → existing CGL_MAP rows found → returns `replay:true`, no new version.
- **Unchanged re-submit**: desired == current → no new version, `No template change needed.`
- Found and fixed a bug in the previous client: TCS answers `{status,message,data}` but the old CRS client read the body as the DTO itself (validate would always look "invalid"). The new client unwraps the envelope.
