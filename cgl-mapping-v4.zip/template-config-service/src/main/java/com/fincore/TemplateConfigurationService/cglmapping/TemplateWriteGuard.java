package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Protects "every CGL has at least one mapping" against template writes that replace the whole JSON
 * (update, rollback, delete, re-create). If such a write would remove an ACTIVE CGL from this report and the CGL
 * is not mapped in any other enabled report, the write is refused with the list of affected CGLs.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TemplateWriteGuard {

    private static final int IN_CHUNK = 500;

    private final ReportTemplateRepository templateRepository;
    private final ReportProfileRegistry profiles;
    private final CglMembership membership;
    private final CglMappingProperties props;
    private final JdbcTemplate jdbcTemplate;

    /** @param newJson the template JSON that will replace oldJson; null when the template is being deleted. */
    public void assertNoCglLosesAllMappings(String reportId, String oldJson, String newJson) {
        if (!props.isGuardEnabled() || profiles.find(reportId).isEmpty() || oldJson == null) {
            return;
        }
        Set<String> before = membership.cglsOf(reportId, oldJson);
        if (before.isEmpty()) {
            return;
        }
        Set<String> after = newJson == null ? Set.of() : membership.cglsOf(reportId, newJson);

        Set<String> dropped = new TreeSet<>(before);
        dropped.removeAll(after);
        if (dropped.isEmpty()) {
            return;
        }
        Set<String> activeDropped = activeInMaster(dropped);
        if (activeDropped.isEmpty()) {
            return;
        }
        for (String other : profiles.reportIds()) {
            if (other.equalsIgnoreCase(reportId)) {
                continue;
            }
            templateRepository.findFirstByReportIdAndStatus(other, "ACTIVE")
                    .map(ReportTemplate::getTemplateJson)
                    .ifPresent(json -> activeDropped.removeAll(membership.cglsOf(other, json)));
            if (activeDropped.isEmpty()) {
                return;
            }
        }
        List<String> sample = new ArrayList<>(activeDropped).subList(0, Math.min(20, activeDropped.size()));
        throw new CglMappingException("CGL_WOULD_BE_UNMAPPED",
                activeDropped.size() + " active CGL(s) would be left without any report mapping by this change to "
                        + reportId + ": " + sample + (activeDropped.size() > 20 ? " ..." : "")
                        + ". Re-map them through CGL update first.");
    }

    private Set<String> activeInMaster(Set<String> cgls) {
        Set<String> active = new HashSet<>();
        List<String> all = new ArrayList<>(cgls);
        for (int i = 0; i < all.size(); i += IN_CHUNK) {
            List<String> chunk = all.subList(i, Math.min(all.size(), i + IN_CHUNK));
            String placeholders = String.join(",", Collections.nCopies(chunk.size(), "?"));
            active.addAll(jdbcTemplate.queryForList(
                    "SELECT CGL_NUMBER FROM CGL_MASTER WHERE STATUS = 1 AND CGL_NUMBER IN (" + placeholders + ")",
                    String.class, chunk.toArray()));
        }
        return active;
    }
}
