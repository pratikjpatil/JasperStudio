package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.RowView;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/** Read side: the Head/Variable picker, the existing mappings of a CGL, and the unmapped-CGL gap list. */
@Slf4j
@Service
@RequiredArgsConstructor
public class MappingQueryService {

    private final ReportProfileRegistry profiles;
    private final ActiveTemplates templates;
    private final MappingTargetExtractor extractor;
    private final CglFilterCodec codec;
    private final MappingViews views;
    private final CglMembership membership;
    private final JdbcTemplate jdbcTemplate;

    /** Report ids enabled for CGL mapping (lets the UI build its tabs without hard-coding the four reports). */
    public List<String> reports() {
        return profiles.reportIds();
    }

    /** Mappable Heads of the ACTIVE template of a report, with their variables and columns. */
    @Transactional(readOnly = true)
    public ReportTargets targets(String reportId, String q) {
        ReportMappingProfile profile = profiles.require(reportId);
        ReportTemplate t = templates.find(profile.reportId());
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);

        List<HeadTarget> heads = new ArrayList<>();
        for (RowView row : extractor.rows(profile.reportId(), templates.parse(t.getTemplateJson()))) {
            if (row.carriers().isEmpty() || !matches(row, needle)) {
                continue;
            }
            Map<String, List<Carrier>> byVariable = new LinkedHashMap<>();
            row.carriers().forEach(c -> byVariable.computeIfAbsent(nz(c.variableName()), k -> new ArrayList<>()).add(c));

            List<VariableTarget> variables = new ArrayList<>();
            byVariable.forEach((name, list) -> variables.add(VariableTarget.builder()
                    .name(name).type(list.get(0).variableType())
                    .columns(list.stream().map(Carrier::columnName).distinct().collect(Collectors.toList()))
                    .otherFilters(list.stream().map(Carrier::otherFilters).filter(s -> !s.isEmpty()).distinct()
                            .collect(Collectors.joining(" | ")))
                    .cglCount(list.stream().mapToInt(c -> codec.read(c.node(), profile).size()).max().orElse(0))
                    .build()));
            heads.add(HeadTarget.builder().code(row.code()).head(row.head()).subHead(row.subHead())
                    .variables(variables).build());
        }
        return ReportTargets.builder().reportId(profile.reportId()).templateId(t.getTemplateId())
                .version(t.getVersionNo()).heads(heads).build();
    }

    /**
     * Current mappings of a CGL in every enabled report (ACTIVE templates). One failing report never hides the
     * others: it is returned with status ERROR / NO_ACTIVE_TEMPLATE.
     */
    @Transactional(readOnly = true)
    public CglMappings mappingsOfCgl(String cglNumber) {
        String cgl = cglNumber.trim();
        List<ReportMappings> reports = new ArrayList<>();
        boolean mapped = false;
        for (String reportId : profiles.reportIds()) {
            ReportMappings rm = ReportMappings.builder().reportId(reportId).mappings(new ArrayList<>()).build();
            Optional<ReportTemplate> t = templates.findOptional(reportId);
            if (t.isEmpty()) {
                rm.setStatus("NO_ACTIVE_TEMPLATE");
                reports.add(rm);
                continue;
            }
            rm.setTemplateId(t.get().getTemplateId());
            rm.setVersion(t.get().getVersionNo());
            try {
                ReportMappingProfile profile = profiles.require(reportId);
                List<RowView> rows = extractor.rows(reportId, templates.parse(t.get().getTemplateJson()));
                rm.setMappings(views.selectorsFor(reportId, rows, c -> codec.read(c.node(), profile).contains(cgl)));
                rm.setStatus("OK");
                mapped |= !rm.getMappings().isEmpty();
            } catch (RuntimeException e) {
                log.warn("Reading mappings of {} in {} failed", cgl, reportId, e);
                rm.setStatus("ERROR");
                rm.setMessage(e.getMessage());
            }
            reports.add(rm);
        }
        return CglMappings.builder().cglNumber(cgl).mapped(mapped).reports(reports).build();
    }

    /** ACTIVE CGLs of CGL_MASTER that appear in none of the enabled reports' active templates. */
    @Transactional(readOnly = true)
    public List<String> unmappedActiveCgls() {
        Set<String> mapped = new HashSet<>();
        for (String reportId : profiles.reportIds()) {
            templates.findOptional(reportId).ifPresent(t -> mapped.addAll(membership.cglsOf(reportId, t.getTemplateJson())));
        }
        List<String> all = new ArrayList<>(jdbcTemplate.queryForList(
                "SELECT CGL_NUMBER FROM CGL_MASTER WHERE STATUS = 1 ORDER BY CGL_NUMBER", String.class));
        all.removeAll(mapped);
        return all;
    }

    private boolean matches(RowView row, String needle) {
        if (needle.isEmpty()) {
            return true;
        }
        if (lower(row.head()).contains(needle) || lower(row.code()).contains(needle) || lower(row.subHead()).contains(needle)) {
            return true;
        }
        return row.carriers().stream().anyMatch(c -> lower(c.variableName()).contains(needle)
                || lower(c.columnName()).contains(needle));
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
