package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.ApplyRequest;
import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.ValidateRequest;
import com.fincore.TemplateConfigurationService.response.ApiResponse;
import com.fincore.commonutilities.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * CGL mapping API (ApiResponse envelope {status, message, data}). The Common Request Service forwards the user's
 * JWT, so the existing authentication filter and audit user resolution apply unchanged.
 */
@Slf4j
@RestController
@RequestMapping("/api/template-config/cgl-mappings")
@RequiredArgsConstructor
public class CglMappingController {

    private final MappingQueryService queries;
    private final MappingValidator validator;
    private final CglMappingApplier applier;
    private final JwtUtil jwtUtil;

    /** Reports enabled for mapping (NWSA, YSA, PNL, PFORM ...). */
    @GetMapping("/reports")
    public ResponseEntity<ApiResponse> reports(HttpServletRequest request) {
        return ok("Reports fetched", queries.reports(), request);
    }

    /** Picker: mappable Heads (+ variables, columns) of a report's ACTIVE template. */
    @GetMapping("/targets")
    public ResponseEntity<ApiResponse> targets(@RequestParam String reportId,
                                               @RequestParam(required = false) String q,
                                               HttpServletRequest request) {
        return ok("Targets fetched", queries.targets(reportId, q), request);
    }

    /** CGL code page: current mappings of a CGL in all enabled reports; same shape as the submit payload. */
    @GetMapping("/by-cgl/{cglNumber}")
    public ResponseEntity<ApiResponse> byCgl(@PathVariable String cglNumber, HttpServletRequest request) {
        return ok("Mappings fetched", queries.mappingsOfCgl(cglNumber), request);
    }

    /** Active CGLs that are not mapped anywhere yet (back-fill list before enforcing mapping). */
    @GetMapping("/unmapped")
    public ResponseEntity<ApiResponse> unmapped(HttpServletRequest request) {
        return ok("Unmapped CGLs fetched", queries.unmappedActiveCgls(), request);
    }

    /** Dry run at maker submit. */
    @PostMapping("/validate")
    public ResponseEntity<ApiResponse> validate(@Valid @RequestBody ValidateRequest body, HttpServletRequest request) {
        return ok("Validated", validator.validate(body), request);
    }

    /** Idempotent on commonReqId. One transaction across all affected templates. */
    @PostMapping("/apply")
    public ResponseEntity<ApiResponse> apply(@Valid @RequestBody ApplyRequest body,
                                             @RequestHeader("Authorization") String token,
                                             HttpServletRequest request) {
        String checkerId = jwtUtil.getUserIdFromToken(token);
        log.info("CGL mapping apply: cgl={}, commonReqId={}, checker={}", body.getCglNumber(), body.getCommonReqId(), checkerId);
        return ok("CGL mappings applied", applier.apply(body, checkerId), request);
    }

    private ResponseEntity<ApiResponse> ok(String message, Object data, HttpServletRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .status("SUCCESS")
                .message(message)
                .data(data)
                .timestamp(LocalDateTime.now())
                .path(request.getRequestURI())
                .build());
    }
}
