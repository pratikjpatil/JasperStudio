package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cache.TemplateCacheEvictor;
import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.RowView;
import com.fincore.TemplateConfigurationService.cglmapping.TemplateVersionWriter.VersionContext;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * Write side. One call = one transaction across every affected template: each gets a new version (previous one
 * goes to history) and one accepted RB_TEMPLATE_REQUEST row (CGL_MAP) records who/when/what, linked to the CGL
 * request through SOURCE_REF. The selectors are the COMPLETE desired mapping set of the CGL: whatever is
 * currently mapped and not desired is removed, so "move a CGL from Head A to Head B" is a single version.
 * Idempotent on commonReqId.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CglMappingApplier {

    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final TemplateRequestRepository requestRepository;
    private final ReportProfileRegistry profiles;
    private final ActiveTemplates templates;
    private final MappingTargetExtractor extractor;
    private final SelectorResolver resolver;
    private final CglFilterCodec codec;
    private final MappingEditor editor;
    private final TemplateVersionWriter writer;
    private final TemplateCacheEvictor cacheEvictor;
    private final JsonMapper jsonMapper;

    @Transactional(rollbackFor = Exception.class)
    public ApplyResult apply(ApplyRequest req, String checkerId) {
        final String sourceRef = String.valueOf(req.getCommonReqId());

        List<TemplateRequest> existing = requestRepository.findBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP);
        if (!existing.isEmpty()) {
            return replay(req.getCommonReqId(), existing);
        }

        final String cgl = req.getCglNumber().trim();
        final String changeType = req.getChangeType().trim().toUpperCase(Locale.ROOT);
        if (!changeType.equals("ADD") && !changeType.equals("UPDATE")) {
            throw new CglMappingException("INVALID_CHANGE_TYPE", "changeType must be ADD or UPDATE");
        }
        Map<String, List<MappingSelector>> desiredByReport = MappingGrouping.byReport(req.getMappings());
        if (req.isRequireMapping() && desiredByReport.isEmpty()) {
            throw new CglMappingException("MAPPING_REQUIRED", "At least one Head/Variable mapping is required for CGL " + cgl);
        }

        // Reports to touch: the desired ones, plus (UPDATE) every report where the CGL is mapped today (removals).
        TreeSet<String> affected = new TreeSet<>(desiredByReport.keySet());
        if (changeType.equals("UPDATE")) {
            affected.addAll(reportsContaining(cgl));
        }

        LocalDateTime now = LocalDateTime.now(IST);
        List<ReportChange> changes = new ArrayList<>();
        List<String> touchedTemplateIds = new ArrayList<>();

        for (String reportId : affected) {                        // ascending -> consistent lock order
            ReportMappingProfile profile = profiles.require(reportId);
            ReportTemplate t = templates.lock(reportId);
            JsonNode root = templates.parse(t.getTemplateJson());
            List<RowView> rows = extractor.rows(reportId, root);
            List<Carrier> carriers = MappingTargetExtractor.flatten(rows);

            Map<String, Carrier> current = new LinkedHashMap<>();
            for (Carrier c : carriers) {
                if (codec.read(c.node(), profile).contains(cgl)) {
                    current.put(c.key(), c);
                }
            }
            Map<String, Carrier> desired = new LinkedHashMap<>();
            for (MappingSelector sel : desiredByReport.getOrDefault(reportId, List.of())) {
                for (Carrier c : resolver.resolve(reportId, rows, sel)) {
                    desired.put(c.key(), c);
                }
            }

            List<Carrier> toAdd = new ArrayList<>();
            List<Carrier> toRemove = new ArrayList<>();
            desired.forEach((k, c) -> {
                if (!current.containsKey(k)) toAdd.add(c);
            });
            current.forEach((k, c) -> {
                if (!desired.containsKey(k)) toRemove.add(c);
            });
            if (toAdd.isEmpty() && toRemove.isEmpty()) {
                continue;                                         // already as desired: no new version
            }

            ArrayNode changeLog = jsonMapper.createArrayNode();
            for (Carrier c : toAdd) {
                changeLog.add(editor.edit(c, cgl, profile, true, false));
            }
            for (Carrier c : toRemove) {
                changeLog.add(editor.edit(c, cgl, profile, false, false));
            }

            ReportChange rc = writer.write(t, root, changeLog, new VersionContext(cgl,
                    MappingStates.SOURCE_APPLY_PREFIX + changeType, sourceRef, req.getCommonReqId(), req.getMakerId(),
                    checkerId, now, "Applied from CGL code " + changeType + " request #" + req.getCommonReqId()));
            rc.setAdded(toAdd.size());
            rc.setRemoved(toRemove.size());
            changes.add(rc);
            touchedTemplateIds.add(t.getTemplateId());
        }

        cacheEvictor.evictAfterCommit(touchedTemplateIds);
        log.info("CGL mapping applied: cgl={}, commonReqId={}, changes={}", cgl, req.getCommonReqId(), changes);
        return ApplyResult.builder().commonReqId(req.getCommonReqId()).replay(false).changes(changes).build();
    }

    private Set<String> reportsContaining(String cgl) {
        Set<String> out = new TreeSet<>();
        for (String reportId : profiles.reportIds()) {
            templates.findOptional(reportId).ifPresent(t -> {
                if (!extractor.containing(reportId, templates.parse(t.getTemplateJson()), cgl).isEmpty()) {
                    out.add(reportId);
                }
            });
        }
        return out;
    }

    private ApplyResult replay(Long commonReqId, List<TemplateRequest> rows) {
        List<ReportChange> changes = new ArrayList<>();
        for (TemplateRequest r : rows) {
            JsonNode p = templates.parse(r.getPayload());
            int n = p.path("changes").size();
            int added = 0;
            for (JsonNode ch : p.path("changes")) {
                if ("ADD_MAPPING".equals(ch.path("action").asString())) added++;
            }
            changes.add(ReportChange.builder().reportId(p.path("reportId").asString())
                    .templateId(p.path("templateId").asString())
                    .fromVersion(p.path("fromVersion").asInt()).toVersion(p.path("toVersion").asInt())
                    .added(added).removed(n - added).auditReqId(r.getReqId()).build());
        }
        return ApplyResult.builder().commonReqId(commonReqId).replay(true).changes(changes).build();
    }
}
