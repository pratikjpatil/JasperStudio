package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

/** Which CGLs a template JSON contains in its eligible carriers (read through the codec: every shape works). */
@Component
@RequiredArgsConstructor
public class CglMembership {

    private final ActiveTemplates templates;
    private final MappingTargetExtractor extractor;
    private final CglFilterCodec codec;
    private final ReportProfileRegistry profiles;

    public Set<String> cglsOf(String reportId, String json) {
        ReportMappingProfile profile = profiles.require(reportId);
        Set<String> out = new HashSet<>();
        for (Carrier c : extractor.extract(reportId, templates.parse(json))) {
            out.addAll(codec.read(c.node(), profile));
        }
        return out;
    }
}
