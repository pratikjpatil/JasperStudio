package com.fincore.TemplateConfigurationService.cglmapping;

/**
 * Everything that differs between reports, behind one interface. Services never look at report ids.
 * Add a report with properties (cgl.mapping.reports.X.*) or by declaring a bean implementing this interface
 * (a bean overrides the property-based profile of the same report id).
 */
public interface ReportMappingProfile {

    String reportId();

    /** Column NAME holding the Head text (Head / DESCRIPTION / NOMENCLATURE ...). */
    String headColumn();

    /** Column NAME holding the row code (Sr. no. / CODE NO. / YSA CODE ...); may be null. */
    String codeColumn();

    /** Column NAME holding the sub head; may be null. */
    String subHeadColumn();

    /** Whether a variable of this type (DB_SUM, DB_AVG ...) can carry a CGL list. */
    boolean isEligible(String variableType);

    /** true: filters.CGL = {op,value} (YSA); false: filters.CGL = [{op,value}] (NWSA, PNL). Used when creating. */
    boolean objectShapedFilter();

    /** Name of the filter that holds CGLs, normally "CGL". */
    String filterKey();

    /** Also treat DB_* cells with a 'source' block as carriers. */
    boolean includeCellSource();
}
