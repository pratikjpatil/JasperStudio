package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.util.List;

/** Adds/removes a CGL on a carrier and returns the audit description of that edit (the only JSON-editing step). */
@Component
@RequiredArgsConstructor
public class MappingEditor {

    private final CglFilterCodec codec;
    private final JsonMapper jsonMapper;

    public ObjectNode edit(Carrier c, String cgl, ReportMappingProfile profile, boolean add, boolean revert) {
        List<String> before = codec.read(c.node(), profile);
        if (add) {
            codec.add(c.node(), cgl, profile);
        } else {
            codec.remove(c.node(), cgl, profile, revert);
        }
        List<String> after = codec.read(c.node(), profile);

        ObjectNode o = jsonMapper.createObjectNode();
        o.put("action", revert ? (add ? "REVERT_REMOVE" : "REVERT_ADD") : (add ? "ADD_MAPPING" : "REMOVE_MAPPING"));
        o.put("rowId", c.rowId());
        o.put("cellId", c.cellId());
        o.put("columnName", c.columnName() == null ? "" : c.columnName());
        o.put("variableName", c.variableName() == null ? "" : c.variableName());
        o.put("headText", c.headText());
        o.put("codeText", c.codeText());
        ArrayNode b = o.putArray("oldCglList");
        before.forEach(b::add);
        ArrayNode a = o.putArray("newCglList");
        after.forEach(a::add);
        return o;
    }
}
