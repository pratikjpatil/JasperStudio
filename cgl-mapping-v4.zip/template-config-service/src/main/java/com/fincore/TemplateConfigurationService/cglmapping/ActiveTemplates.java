package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import java.util.Optional;

/** Access to the ACTIVE template of a report (plain or row-locked) and JSON parsing, in one place. */
@Component
@RequiredArgsConstructor
public class ActiveTemplates {

    private final ReportTemplateRepository repository;
    private final JsonMapper jsonMapper;

    public Optional<ReportTemplate> findOptional(String reportId) {
        return repository.findFirstByReportIdAndStatus(reportId, "ACTIVE");
    }

    public ReportTemplate find(String reportId) {
        return findOptional(reportId).orElseThrow(() ->
                new CglMappingException("TEMPLATE_NOT_ACTIVE", "No ACTIVE template for report " + reportId));
    }

    /** Pessimistic write lock; call in ascending report order to keep a consistent lock order. */
    public Optional<ReportTemplate> lockOptional(String reportId) {
        return repository.lockActiveByReportId(reportId).stream().findFirst();
    }

    public ReportTemplate lock(String reportId) {
        return lockOptional(reportId).orElseThrow(() ->
                new CglMappingException("TEMPLATE_NOT_ACTIVE", "No ACTIVE template for report " + reportId));
    }

    public JsonNode parse(String json) {
        return jsonMapper.readTree(json);
    }
}
