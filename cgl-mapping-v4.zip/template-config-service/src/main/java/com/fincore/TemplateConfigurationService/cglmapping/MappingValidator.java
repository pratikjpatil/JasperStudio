package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.RowView;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/** Dry run at maker submit: resolves every selector against the ACTIVE templates. Writes nothing. */
@Service
@RequiredArgsConstructor
public class MappingValidator {

    private final ReportProfileRegistry profiles;
    private final ActiveTemplates templates;
    private final MappingTargetExtractor extractor;
    private final SelectorResolver resolver;
    private final MappingViews views;

    @Transactional(readOnly = true)
    public ValidateResponse validate(ValidateRequest req) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<MappingSelector> resolved = new ArrayList<>();

        List<MappingSelector> mappings = req.getMappings() == null ? List.of() : req.getMappings();
        if (req.isRequireMapping() && mappings.isEmpty()) {
            errors.add("[MAPPING_REQUIRED] At least one Head/Variable mapping is required");
        }
        for (Map.Entry<String, List<MappingSelector>> e : MappingGrouping.byReport(mappings).entrySet()) {
            String reportId = e.getKey();
            try {
                profiles.require(reportId);
                ReportTemplate t = templates.find(reportId);
                List<RowView> rows = extractor.rows(reportId, templates.parse(t.getTemplateJson()));
                Set<String> seen = new HashSet<>();
                Set<String> headRows = new LinkedHashSet<>();
                for (MappingSelector sel : e.getValue()) {
                    try {
                        List<Carrier> carriers = resolver.resolve(reportId, rows, sel);
                        if (!carriers.stream().map(Carrier::key).allMatch(seen::add)) {
                            warnings.add(reportId + ": duplicate selection of " + SelectorResolver.describe(sel) + " ignored");
                            continue;
                        }
                        headRows.add(carriers.get(0).rowId());
                        resolved.add(views.explicit(reportId, carriers));
                    } catch (CglMappingException ex) {
                        errors.add(ex.getMessage());
                    }
                }
                if (headRows.size() > 1) {
                    warnings.add(reportId + ": CGL is mapped to " + headRows.size() + " different Heads (check for double counting)");
                }
            } catch (CglMappingException ex) {
                errors.add(reportId + ": " + ex.getMessage());
            }
        }
        return ValidateResponse.builder().valid(errors.isEmpty()).errors(errors).warnings(warnings).resolved(resolved).build();
    }
}
