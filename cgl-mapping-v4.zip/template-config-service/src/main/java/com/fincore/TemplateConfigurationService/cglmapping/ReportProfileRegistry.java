package com.fincore.TemplateConfigurationService.cglmapping;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Single lookup point for report profiles: property-based ones first, code-defined beans override them. */
@Component
public class ReportProfileRegistry {

    private final Map<String, ReportMappingProfile> profiles = new LinkedHashMap<>();

    public ReportProfileRegistry(CglMappingProperties props, ObjectProvider<ReportMappingProfile> custom) {
        props.getReports().forEach((id, rule) -> {
            String key = key(id);
            profiles.put(key, new ConfiguredReportProfile(key, rule));
        });
        custom.orderedStream().forEach(p -> profiles.put(key(p.reportId()), p));
    }

    public Optional<ReportMappingProfile> find(String reportId) {
        return reportId == null ? Optional.empty() : Optional.ofNullable(profiles.get(key(reportId)));
    }

    public ReportMappingProfile require(String reportId) {
        return find(reportId).orElseThrow(() ->
                new CglMappingException("REPORT_NOT_CONFIGURED", "Report " + reportId + " is not enabled for CGL mapping"));
    }

    public List<String> reportIds() {
        return new ArrayList<>(profiles.keySet());
    }

    private static String key(String id) {
        return id.trim().toUpperCase(Locale.ROOT);
    }
}
