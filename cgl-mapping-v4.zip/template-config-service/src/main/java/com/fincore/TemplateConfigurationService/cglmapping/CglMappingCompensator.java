package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cache.TemplateCacheEvictor;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.TemplateVersionWriter.VersionContext;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Cross-service safety net, driven by the reconciler: confirms an applied change once the CGL request is ACCEPTED,
 * or compensates it (inverse change as a NEW version; never restores snapshots, so later unrelated edits survive).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CglMappingCompensator {

    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final TemplateRequestRepository requestRepository;
    private final ReportProfileRegistry profiles;
    private final ActiveTemplates templates;
    private final MappingTargetExtractor extractor;
    private final MappingEditor editor;
    private final TemplateVersionWriter writer;
    private final TemplateCacheEvictor cacheEvictor;
    private final JsonMapper jsonMapper;

    @Transactional
    public void confirm(String sourceRef) {
        for (TemplateRequest r : requestRepository.lockBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP)) {
            if (MappingStates.APPLIED.equals(r.getExecutorRemarks())) {
                r.setExecutorRemarks(MappingStates.CONFIRMED);
                requestRepository.save(r);
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void revert(String sourceRef, String actor, String reason) {
        List<TemplateRequest> rows = requestRepository.lockBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP);
        LocalDateTime now = LocalDateTime.now(IST);
        List<String> touched = new ArrayList<>();

        for (TemplateRequest row : rows) {
            if (!MappingStates.APPLIED.equals(row.getExecutorRemarks())) {
                continue;
            }
            JsonNode audit = templates.parse(row.getPayload());
            String reportId = audit.path("reportId").asString();
            String cgl = audit.path("cglNumber").asString();
            ReportMappingProfile profile = profiles.require(reportId);

            Optional<ReportTemplate> locked = templates.lockOptional(reportId);
            if (locked.isEmpty()) {
                row.setExecutorRemarks(MappingStates.REVERT_SKIPPED);
                requestRepository.save(row);
                log.warn("Revert skipped, no active template for report {} (ref {})", reportId, sourceRef);
                continue;
            }
            ReportTemplate t = locked.get();
            JsonNode root = templates.parse(t.getTemplateJson());
            List<Carrier> carriers = extractor.extract(reportId, root);

            ArrayNode changeLog = jsonMapper.createArrayNode();
            for (JsonNode ch : audit.path("changes")) {
                Carrier c = MappingTargetExtractor.locate(carriers, ch.path("rowId").asString(),
                        ch.path("cellId").asString(), ch.path("variableName").asString());
                if (c == null) {
                    log.warn("Revert: target gone ({} {}), skipped", ch.path("rowId").asString(), ch.path("cellId").asString());
                    continue;
                }
                boolean wasAdd = "ADD_MAPPING".equals(ch.path("action").asString());
                changeLog.add(editor.edit(c, cgl, profile, !wasAdd, true));
            }
            if (!changeLog.isEmpty()) {
                writer.write(t, root, changeLog, new VersionContext(cgl, MappingStates.SOURCE_REVERT,
                        sourceRef + "R" + row.getReqId(), audit.path("commonReqId").asLong(), actor, actor, now,
                        "Reverted CGL request #" + sourceRef + ": " + reason));
                touched.add(t.getTemplateId());
            }
            // Free the reference so a later retry of the approval runs apply() again instead of replaying.
            row.setExecutorRemarks(MappingStates.REVERTED);
            row.setSourceRef(sourceRef + "X" + row.getReqId());
            requestRepository.save(row);
        }
        cacheEvictor.evictAfterCommit(touched);
    }
}
