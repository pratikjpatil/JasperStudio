package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Safety net for the one cross-service window: TCS committed an apply but the CRS transaction did not commit
 * (CRS crash, timeout, commit failure). For every applied CGL_MAP audit row older than the grace period it reads
 * COMMON_REQ (same schema, read-only): ACCEPTED -> confirm; anything else -> revert (inverse change, new version).
 * Safe on several instances: confirm/revert lock the audit rows first and re-check their state.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CglMappingReconciler {

    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final TemplateRequestRepository requestRepository;
    private final CglMappingCompensator compensator;
    private final CglMappingProperties props;
    private final JdbcTemplate jdbcTemplate;

    @Scheduled(fixedDelayString = "${cgl.mapping.reconcile-interval-ms:120000}",
            initialDelayString = "${cgl.mapping.reconcile-initial-delay-ms:60000}")
    public void run() {
        if (!props.isReconcileEnabled()) {
            return;
        }
        LocalDateTime now = LocalDateTime.now(IST);
        List<TemplateRequest> stale = requestRepository
                .findByChangeTypeAndReqStatusAndExecutorRemarksAndExecutionDateBetween(
                        ChangeType.CGL_MAP, RequestStatus.ACCEPTED, MappingStates.APPLIED,
                        now.minusHours(props.getReconcileLookbackHours()),
                        now.minusMinutes(props.getReconcileGraceMinutes()));

        Set<String> refs = new LinkedHashSet<>();
        for (TemplateRequest r : stale) {
            if (r.getSourceRef() != null) {
                refs.add(r.getSourceRef());
            }
        }
        for (String ref : refs) {
            try {
                String status = commonReqStatus(ref);
                if ("A".equals(status)) {
                    compensator.confirm(ref);
                } else {
                    log.warn("CGL mapping reconcile: COMMON_REQ {} status={}, reverting template changes", ref, status);
                    compensator.revert(ref, "SYSTEM", "CGL request status=" + status);
                }
            } catch (Exception e) {
                log.error("CGL mapping reconcile failed for ref {}; will retry", ref, e);
            }
        }
    }

    private String commonReqStatus(String ref) {
        List<String> r = jdbcTemplate.query("SELECT REQ_STATUS FROM COMMON_REQ WHERE REQ_ID = ?",
                (rs, n) -> rs.getString(1), Long.valueOf(ref));
        return r.isEmpty() ? null : r.get(0);
    }
}
