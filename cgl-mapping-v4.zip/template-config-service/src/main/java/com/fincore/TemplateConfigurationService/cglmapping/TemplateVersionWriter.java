package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.ReportChange;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import com.fincore.TemplateConfigurationService.service.TemplateVersioningService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.time.LocalDateTime;

/**
 * Archives the current version (history), writes the edited JSON as the next version and records the audit row
 * (RB_TEMPLATE_REQUEST, change type CGL_MAP). Joins the caller's transaction.
 * Order matters: archive -> next version -> audit row (gives REQ_ID) -> template save (links SOURCE_REQ_ID).
 */
@Component
@RequiredArgsConstructor
public class TemplateVersionWriter {

    /** What the audit row needs to say about who/when/why. */
    public record VersionContext(String cgl, String source, String sourceRef, Long commonReqId, String makerId,
                                 String executorId, LocalDateTime now, String executionRemarks) {
    }

    private final TemplateVersioningService versioning;
    private final TemplateRequestRepository requestRepository;
    private final ReportTemplateRepository templateRepository;
    private final JsonMapper jsonMapper;

    public ReportChange write(ReportTemplate t, JsonNode root, ArrayNode changeLog, VersionContext ctx) {
        int from = t.getVersionNo();
        int to = versioning.archiveAndNextVersion(t, ctx.executorId(), ctx.now());

        JsonNode meta = root.path("templateMeta");
        if (meta.isObject()) {
            ((ObjectNode) meta).put("version", String.valueOf(to));
        }

        ObjectNode payload = jsonMapper.createObjectNode();
        payload.put("source", ctx.source());
        payload.put("commonReqId", ctx.commonReqId() == null ? 0L : ctx.commonReqId());
        payload.put("cglNumber", ctx.cgl());
        payload.put("reportId", t.getReportId());
        payload.put("templateId", t.getTemplateId());
        payload.put("fromVersion", from);
        payload.put("toVersion", to);
        payload.set("changes", changeLog);

        String remarks = "CGL " + ctx.cgl() + " mapped via " + ctx.source() + " request #" + ctx.commonReqId();
        TemplateRequest audit = TemplateRequest.builder()
                .changeType(ChangeType.CGL_MAP)
                .reqStatus(RequestStatus.ACCEPTED)
                .reqDate(ctx.now())
                .creatorId(ctx.makerId())
                .executionDate(ctx.now())
                .executorId(ctx.executorId())
                .executorRemarks(MappingStates.SOURCE_REVERT.equals(ctx.source()) ? MappingStates.REVERT_ROW : MappingStates.APPLIED)
                .executionRemarks(ctx.executionRemarks() + ": " + t.getReportId() + " v" + from + " -> v" + to)
                .payload(jsonMapper.writeValueAsString(payload))
                .targetId(t.getReportId())
                .remarks(remarks.length() > 500 ? remarks.substring(0, 500) : remarks)
                .sourceRef(ctx.sourceRef())
                .build();
        audit = requestRepository.save(audit);

        t.setTemplateJson(jsonMapper.writeValueAsString(root));
        t.setVersionNo(to);
        t.setUpdatedAt(ctx.now());
        t.setUpdatedBy(ctx.executorId());
        t.setRemarks(audit.getRemarks());
        t.setSourceReqId(audit.getReqId());
        templateRepository.save(t);

        return ReportChange.builder().reportId(t.getReportId()).templateId(t.getTemplateId())
                .fromVersion(from).toVersion(to).auditReqId(audit.getReqId()).build();
    }
}
