package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.MappingSelector;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** Groups selectors by report id (ascending, which is also the template lock order). */
final class MappingGrouping {

    private MappingGrouping() {
    }

    static Map<String, List<MappingSelector>> byReport(List<MappingSelector> selectors) {
        Map<String, List<MappingSelector>> m = new TreeMap<>();
        if (selectors != null) {
            for (MappingSelector s : selectors) {
                m.computeIfAbsent(s.getReportId().trim().toUpperCase(Locale.ROOT), k -> new ArrayList<>()).add(s);
            }
        }
        return m;
    }
}
