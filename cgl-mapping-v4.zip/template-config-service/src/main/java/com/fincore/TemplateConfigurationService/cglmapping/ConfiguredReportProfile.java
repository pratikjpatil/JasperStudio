package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingProperties.ReportRule;

/** Property-driven profile (application.properties, prefix cgl.mapping.reports.<ID>). */
public record ConfiguredReportProfile(String reportId, ReportRule rule) implements ReportMappingProfile {

    @Override
    public String headColumn() {
        return rule.getHeadColumn();
    }

    @Override
    public String codeColumn() {
        return rule.getCodeColumn();
    }

    @Override
    public String subHeadColumn() {
        return rule.getSubHeadColumn();
    }

    @Override
    public boolean isEligible(String variableType) {
        return variableType != null && rule.getEligibleTypes().stream().anyMatch(t -> t.equalsIgnoreCase(variableType));
    }

    @Override
    public boolean objectShapedFilter() {
        return "OBJECT".equalsIgnoreCase(rule.getFilterShape());
    }

    @Override
    public String filterKey() {
        return rule.getFilterKey();
    }

    @Override
    public boolean includeCellSource() {
        return rule.isIncludeCellSource();
    }
}
