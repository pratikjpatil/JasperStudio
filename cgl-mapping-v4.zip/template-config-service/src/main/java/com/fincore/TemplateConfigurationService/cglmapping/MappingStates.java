package com.fincore.TemplateConfigurationService.cglmapping;

/** Audit-row states (RB_TEMPLATE_REQUEST.EXECUTOR_REMARKS) and sources of the CGL_MAP change type. */
public final class MappingStates {

    private MappingStates() {
    }

    public static final String APPLIED = "CGL_APPLIED";
    public static final String CONFIRMED = "CGL_CONFIRMED";
    public static final String REVERTED = "CGL_REVERTED";
    public static final String REVERT_ROW = "CGL_REVERT_ROW";
    public static final String REVERT_SKIPPED = "CGL_REVERT_SKIPPED";

    public static final String SOURCE_REVERT = "CGL_REVERT";
    public static final String SOURCE_APPLY_PREFIX = "CGL_CODE_";
}
