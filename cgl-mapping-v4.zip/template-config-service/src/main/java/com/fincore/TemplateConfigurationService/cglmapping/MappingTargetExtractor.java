package com.fincore.TemplateConfigurationService.cglmapping;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Parses a template JSON into rows and "carriers" (the places where a CGL list can live), using the report's
 * profile to find the Head / code / sub-head columns. Only DB-backed variables of an eligible type qualify;
 * formula-only cells never do.
 */
@Component
@RequiredArgsConstructor
public class MappingTargetExtractor {

    private final CglFilterCodec codec;
    private final ReportProfileRegistry profiles;

    public static final String KIND_VARIABLE = "VARIABLE";
    public static final String KIND_CELL_SOURCE = "CELL_SOURCE";

    /** A concrete, editable location of a CGL list inside a parsed template tree. */
    public record Carrier(String reportId, String rowId, String cellId, String columnId, String columnName,
                          String variableName, String kind, String variableType,
                          String headText, String codeText, String subHeadText,
                          String otherFilters, ObjectNode node) {

        public String key() {
            return rowId + "|" + cellId + "|" + (variableName == null ? "" : variableName);
        }
    }

    /** One template row with its identifying texts; carriers is empty for formula-only rows. */
    public record RowView(String rowId, String code, String head, String subHead, List<Carrier> carriers) {
    }

    public List<RowView> rows(String reportId, JsonNode templateRoot) {
        ReportMappingProfile profile = profiles.require(reportId);
        JsonNode reportData = templateRoot.path("reportData");
        JsonNode columns = reportData.path("columns");
        int headIdx = indexOf(columns, profile.headColumn());
        int codeIdx = indexOf(columns, profile.codeColumn());
        int subIdx = indexOf(columns, profile.subHeadColumn());

        List<RowView> out = new ArrayList<>();
        for (JsonNode row : reportData.path("rows")) {
            String rowId = text(row.path("id"));
            JsonNode cells = row.path("cells");
            String head = cellText(cells, headIdx);
            String code = cellText(cells, codeIdx);
            String sub = cellText(cells, subIdx);
            List<Carrier> carriers = new ArrayList<>();

            int j = 0;
            for (JsonNode cell : cells) {
                String columnId = text(columns.path(j).path("id"));
                String columnName = text(columns.path(j).path("name"));
                String cellId = text(cell.path("id"));
                if (cellId.isEmpty()) {
                    cellId = "cell_" + rowId + "_" + columnId;
                }
                String type = text(cell.path("type"));

                JsonNode variables = cell.path("variables");
                if (variables.isObject()) {
                    for (Map.Entry<String, JsonNode> e : variables.properties()) {
                        JsonNode def = e.getValue();
                        if (def.isObject() && profile.isEligible(text(def.path("type")))) {
                            carriers.add(new Carrier(reportId, rowId, cellId, columnId, columnName, e.getKey(),
                                    KIND_VARIABLE, text(def.path("type")), head, code, sub,
                                    otherFilters(def.path("filters"), profile), (ObjectNode) def));
                        }
                    }
                }
                if (profile.includeCellSource() && type.startsWith("DB_") && cell.path("source").isObject()
                        && profile.isEligible(type)) {
                    carriers.add(new Carrier(reportId, rowId, cellId, columnId, columnName, "", KIND_CELL_SOURCE, type,
                            head, code, sub, otherFilters(cell.path("source").path("filters"), profile),
                            (ObjectNode) cell.path("source")));
                }
                j++;
            }
            out.add(new RowView(rowId, code, head, sub, carriers));
        }
        return out;
    }

    public List<Carrier> extract(String reportId, JsonNode templateRoot) {
        return flatten(rows(reportId, templateRoot));
    }

    public static List<Carrier> flatten(List<RowView> rows) {
        List<Carrier> all = new ArrayList<>();
        rows.forEach(r -> all.addAll(r.carriers()));
        return all;
    }

    /** Carriers whose CGL list currently contains the given CGL. */
    public List<Carrier> containing(String reportId, JsonNode root, String cgl) {
        ReportMappingProfile profile = profiles.require(reportId);
        List<Carrier> out = new ArrayList<>();
        for (Carrier c : extract(reportId, root)) {
            if (codec.read(c.node(), profile).contains(cgl)) {
                out.add(c);
            }
        }
        return out;
    }

    /** Finds a carrier by its location (used by revert, which replays the audit trail). */
    public static Carrier locate(List<Carrier> carriers, String rowId, String cellId, String variableName) {
        String v = variableName == null ? "" : variableName;
        for (Carrier c : carriers) {
            if (c.rowId().equals(rowId) && c.cellId().equals(cellId)
                    && (c.variableName() == null ? "" : c.variableName()).equals(v)) {
                return c;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------

    private int indexOf(JsonNode columns, String name) {
        if (name == null || name.isBlank() || !columns.isArray()) {
            return -1;
        }
        int i = 0;
        for (JsonNode c : columns) {
            if (name.trim().equalsIgnoreCase(text(c.path("name")).trim())) {
                return i;
            }
            i++;
        }
        return -1;
    }

    private String cellText(JsonNode cells, int idx) {
        if (idx < 0 || !cells.isArray() || idx >= cells.size()) {
            return "";
        }
        return text(cells.get(idx).path("value"));
    }

    private String otherFilters(JsonNode filters, ReportMappingProfile profile) {
        if (!filters.isObject()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, JsonNode> e : filters.properties()) {
            if (e.getKey().equalsIgnoreCase(profile.filterKey())) {
                continue;
            }
            JsonNode f = e.getValue();
            List<JsonNode> list = new ArrayList<>();
            if (f.isArray()) {
                f.forEach(list::add);
            } else {
                list.add(f);
            }
            for (JsonNode one : list) {
                if (sb.length() > 0) {
                    sb.append("; ");
                }
                sb.append(e.getKey()).append(' ').append(text(one.path("op"))).append(' ')
                        .append(one.path("value").toString());
            }
        }
        return sb.length() > 1000 ? sb.substring(0, 1000) : sb.toString();
    }

    private static String text(JsonNode n) {
        return (n == null || n.isMissingNode() || n.isNull()) ? "" : n.asString();
    }
}
