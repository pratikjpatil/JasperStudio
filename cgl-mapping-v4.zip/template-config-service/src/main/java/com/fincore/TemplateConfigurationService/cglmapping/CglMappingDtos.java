package com.fincore.TemplateConfigurationService.cglmapping;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Request/response models of the CGL mapping API. Everything the UI sends or receives is human-visible text. */
public final class CglMappingDtos {

    private CglMappingDtos() {
    }

    /**
     * Business-key pointer to a Head (+ Variable) of a report template. No internal ids, no versions.
     * Resolved against the ACTIVE template at validate/apply time.
     * <ul>
     *   <li>head / code / subHead: all given fields must match (case-insensitive); at least one of code, head.</li>
     *   <li>variable: optional when the Head has only one variable name.</li>
     *   <li>columns: optional. Empty/null = every amount column that carries the variable (PNL: both columns).</li>
     * </ul>
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MappingSelector {
        @NotBlank
        private String reportId;
        private String code;
        private String head;
        private String subHead;
        private String variable;
        private List<String> columns;
    }

    // ---------------- picker (maker chooses Head/Variable) ----------------

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class VariableTarget {
        private String name;
        private String type;
        private List<String> columns;
        private String otherFilters;
        private int cglCount;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class HeadTarget {
        private String code;
        private String head;
        private String subHead;
        private List<VariableTarget> variables;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ReportTargets {
        private String reportId;
        private String templateId;
        private Integer version;
        private List<HeadTarget> heads;
    }

    // ---------------- existing mappings of a CGL (CGL code page) ----------------

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ReportMappings {
        private String reportId;
        /** OK | NO_ACTIVE_TEMPLATE | ERROR */
        private String status;
        private String message;
        private String templateId;
        private Integer version;
        /** Same shape the UI sends back on submit, so it can be edited and re-posted as is. */
        private List<MappingSelector> mappings;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CglMappings {
        private String cglNumber;
        private boolean mapped;
        private List<ReportMappings> reports;
    }

    // ---------------- validate / apply ----------------

    @Data
    @NoArgsConstructor
    public static class ValidateRequest {
        private String cglNumber;
        private boolean requireMapping;
        @Valid
        private List<MappingSelector> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ValidateResponse {
        private boolean valid;
        @Builder.Default
        private List<String> errors = new ArrayList<>();
        @Builder.Default
        private List<String> warnings = new ArrayList<>();
        /** Every selector resolved to explicit code/head/subHead/variable/columns, for a confirmation screen. */
        @Builder.Default
        private List<MappingSelector> resolved = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    public static class ApplyRequest {
        /** COMMON_REQ.REQ_ID: idempotency key and audit reference. */
        @NotNull
        private Long commonReqId;
        /** ADD or UPDATE (the CGL request's change type). */
        @NotBlank
        private String changeType;
        @NotBlank
        private String cglNumber;
        @NotBlank
        private String makerId;
        private boolean requireMapping;
        /** Complete desired set of mappings of this CGL after approval. */
        @Valid
        private List<MappingSelector> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ReportChange {
        private String reportId;
        private String templateId;
        private int fromVersion;
        private int toVersion;
        private int added;
        private int removed;
        private Long auditReqId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ApplyResult {
        private Long commonReqId;
        private boolean replay;
        @Builder.Default
        private List<ReportChange> changes = new ArrayList<>();
    }
}
