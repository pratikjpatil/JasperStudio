package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.MappingSelector;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.RowView;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Turns a business-key {@link MappingSelector} into the concrete carriers of the template being edited.
 * Pure function of (rows, selector): no I/O, no JSON editing.
 *
 * Rules: Head rows are matched on every field given (code, head, subHead), case/space-insensitive. Several matches
 * are narrowed to rows that can carry a CGL; if still more than one -> HEAD_AMBIGUOUS. A variable is required only
 * when the row has more than one variable name. Without 'columns' every column carrying the variable is selected
 * (PNL: both amount columns).
 */
@Component
public class SelectorResolver {

    public List<Carrier> resolve(String reportId, List<RowView> rows, MappingSelector s) {
        String code = norm(s.getCode());
        String head = norm(s.getHead());
        String sub = norm(s.getSubHead());
        if (code.isEmpty() && head.isEmpty()) {
            throw new CglMappingException("SELECTOR_INCOMPLETE",
                    reportId + ": give the head code or the head name of the mapping");
        }

        List<RowView> hits = rows.stream()
                .filter(r -> same(code, r.code()) && same(head, r.head()) && same(sub, r.subHead()))
                .collect(Collectors.toList());
        if (hits.isEmpty()) {
            throw new CglMappingException("HEAD_NOT_FOUND", reportId + ": no head matches " + describe(s));
        }
        List<RowView> pick = hits;
        if (hits.size() > 1) {
            List<RowView> mappable = hits.stream().filter(r -> !r.carriers().isEmpty()).collect(Collectors.toList());
            if (!mappable.isEmpty()) {
                pick = mappable;
            }
        }
        if (pick.size() > 1) {
            String candidates = pick.stream().limit(5)
                    .map(r -> "[code=" + r.code() + ", head=" + r.head() + ", subHead=" + r.subHead() + "]")
                    .collect(Collectors.joining(" "));
            throw new CglMappingException("HEAD_AMBIGUOUS", reportId + ": " + describe(s) + " matches "
                    + pick.size() + " rows " + candidates + ". Add the head code or sub head.");
        }
        RowView row = pick.get(0);
        if (row.carriers().isEmpty()) {
            throw new CglMappingException("HEAD_NOT_MAPPABLE", reportId + ": " + describe(s)
                    + " is a calculated row without a database variable. Map the rows that feed it instead.");
        }

        List<Carrier> pool = row.carriers();
        String variable = s.getVariable() == null ? "" : s.getVariable().trim();
        if (!variable.isEmpty()) {
            pool = pool.stream().filter(c -> variable.equalsIgnoreCase(nz(c.variableName()))).collect(Collectors.toList());
            if (pool.isEmpty()) {
                throw new CglMappingException("VARIABLE_NOT_FOUND", reportId + ": " + describe(s) + " has no variable '"
                        + variable + "'. Available: " + variableNames(row.carriers()));
            }
        } else {
            Set<String> names = variableNames(row.carriers());
            if (names.size() > 1) {
                throw new CglMappingException("VARIABLE_REQUIRED", reportId + ": " + describe(s)
                        + " has several variables " + names + ". Choose one.");
            }
        }

        if (s.getColumns() != null && !s.getColumns().isEmpty()) {
            List<Carrier> source = pool;
            List<Carrier> chosen = new ArrayList<>();
            for (String wanted : s.getColumns()) {
                String w = norm(wanted);
                List<Carrier> m = source.stream()
                        .filter(c -> w.equalsIgnoreCase(norm(c.columnName())) || w.equalsIgnoreCase(norm(c.columnId())))
                        .collect(Collectors.toList());
                if (m.isEmpty()) {
                    throw new CglMappingException("COLUMN_NOT_FOUND", reportId + ": " + describe(s) + " has no column '"
                            + wanted + "' for this variable. Available: "
                            + source.stream().map(Carrier::columnName).distinct().collect(Collectors.toList()));
                }
                chosen.addAll(m);
            }
            pool = chosen;
        }
        return pool;
    }

    // ------------------------------------------------------------------

    private static Set<String> variableNames(List<Carrier> carriers) {
        Set<String> names = new LinkedHashSet<>();
        carriers.forEach(c -> names.add(nz(c.variableName())));
        return names;
    }

    static String describe(MappingSelector s) {
        List<String> parts = new ArrayList<>();
        if (!norm(s.getCode()).isEmpty()) parts.add("code=" + norm(s.getCode()));
        if (!norm(s.getHead()).isEmpty()) parts.add("head=" + norm(s.getHead()));
        if (!norm(s.getSubHead()).isEmpty()) parts.add("subHead=" + norm(s.getSubHead()));
        return String.join(", ", parts);
    }

    static boolean same(String wanted, String have) {
        return wanted.isEmpty() || wanted.equalsIgnoreCase(norm(have));
    }

    static String norm(String s) {
        return s == null ? "" : s.trim().replaceAll("\\s+", " ");
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
