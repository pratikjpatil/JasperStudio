package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.MappingSelector;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.RowView;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/** Builds UI-facing selectors from template rows/carriers (the inverse of {@link SelectorResolver}). */
@Component
public class MappingViews {

    /**
     * One selector per (row, variable) that has at least one included carrier. 'columns' is null when the included
     * carriers cover every column carrying that variable (so the selector round-trips as "all columns").
     */
    public List<MappingSelector> selectorsFor(String reportId, List<RowView> rows, Predicate<Carrier> included) {
        List<MappingSelector> out = new ArrayList<>();
        for (RowView row : rows) {
            Map<String, List<Carrier>> byVariable = new LinkedHashMap<>();
            for (Carrier c : row.carriers()) {
                byVariable.computeIfAbsent(c.variableName() == null ? "" : c.variableName(), k -> new ArrayList<>()).add(c);
            }
            byVariable.forEach((variable, all) -> {
                List<Carrier> picked = all.stream().filter(included).collect(Collectors.toList());
                if (picked.isEmpty()) {
                    return;
                }
                out.add(MappingSelector.builder().reportId(reportId).code(blankToNull(row.code()))
                        .head(blankToNull(row.head())).subHead(blankToNull(row.subHead()))
                        .variable(blankToNull(variable))
                        .columns(picked.size() == all.size() ? null : columnNames(picked)).build());
            });
        }
        return out;
    }

    /** Fully explicit selector for carriers that share one row and one variable (validate's "resolved" output). */
    public MappingSelector explicit(String reportId, List<Carrier> carriers) {
        Carrier c = carriers.get(0);
        return MappingSelector.builder().reportId(reportId).code(blankToNull(c.codeText()))
                .head(blankToNull(c.headText())).subHead(blankToNull(c.subHeadText()))
                .variable(blankToNull(c.variableName())).columns(columnNames(carriers)).build();
    }

    private static List<String> columnNames(List<Carrier> carriers) {
        return carriers.stream().map(Carrier::columnName).distinct().collect(Collectors.toList());
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s;
    }
}
