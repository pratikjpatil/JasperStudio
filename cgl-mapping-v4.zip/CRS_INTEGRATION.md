# Edits to EXISTING common-request-service-tcs files (apply on feature/16-11-26)
New files (already in this package): `dto/CglTemplateMappingDto`, `client/TemplateBindingDtos`, `client/TemplateBindingClient`,
`service/cglmapping/CglMappingCoordinator`, `controller/CglTemplateMappingController`.
Assumes Spring Boot 4.x / Jackson 3 (`tools.jackson`) as you stated. Annotation imports stay `com.fasterxml.jackson.annotation`.

## 1. `CglPayloadDto` — add the field (+ import `java.util.List`, `jakarta.validation.Valid`)
```java
/** Complete desired set of report-template mappings. null = not edited by this request. */
@Valid
private List<CglTemplateMappingDto> templateMappings;
```

## 2. `CGLMaster` — ignore the extra payload property (keeps the existing master deserialisation untouched)
```java
@JsonIgnoreProperties({"templateMappings"})
public class CGLMaster { ... }
```
(If your branch's `readMaster` already strips/ignores it, skip.)

## 3. `RequestTypeStrategy` — two no-op default hooks (skip any that already exist; other strategies are unaffected)
```java
default void validateRequest(CreateRequestDto requestDto, String token) { validateRequest(requestDto); }
default void afterApprovalFlushed(CommonReq request, String token) { }
```

## 4. `RequestServiceImpl`
In `createRequest`, replace `...validateRequest(dto)` with `...validateRequest(dto, token)`.
In `updateRequestStatus`, right after `saveAndFlush(request)` and before returning:
```java
if (RequestStatus.ACCEPTED.equals(dto.getStatus())) {
    strategyFactory.getStrategy(updatedRequest.getReqType()).afterApprovalFlushed(updatedRequest, token);
}
```
(The method is already `@Transactional(rollbackOn = Exception.class)`; a thrown error rolls everything back.)
If your hooks declare `throws JsonProcessingException`/`JacksonException`, keep whatever your branch uses; the coordinator throws only unchecked exceptions.

## 5. `CglCodeStrategy` — delegate (add field `private final CglMappingCoordinator mappingCoordinator;`)
```java
@Override
public void validateRequest(CreateRequestDto dto, String token) { mappingCoordinator.validateOnSubmit(dto, token); }

@Override
public void afterApprovalFlushed(CommonReq request, String token) { mappingCoordinator.applyOnApproval(request, token); }
```
Remove the earlier patch's `readMaster`/`templateMappings` handling and the `TemplateBindingClient`/`@Value cgl.mapping.enforced` fields from the strategy;
`handleAdd/handleUpdate/handleStatusChange` stay exactly as in your branch.

## 6. `application.properties`
```
template.service.base-url=http://localhost:8090
template.service.connect-timeout-ms=3000
template.service.read-timeout-ms=30000
cgl.mapping.enforced=false
spring.transaction.default-timeout=120
```
