import React, {
  useEffect,
  useMemo,
  useCallback,
  useState,
  useRef,
} from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Box,
  Grid,
  TextField,
  MenuItem,
  Typography,
  FormControlLabel,
  Checkbox,
  FormHelperText,
  FormControl,
  FormLabel,
  RadioGroup,
  Radio,
  Button,
  IconButton,
  Divider,
  DialogActions,
  Card,
  Autocomplete,
} from "@mui/material";
import LockOpenIcon from "@mui/icons-material/LockOpen";
import CloseIcon from "@mui/icons-material/Close";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import BlockIcon from "@mui/icons-material/Block";
import useApi from "../../hooks/useApi";
import useCustomSnackbar from "../../utils/useCustomSnackbar";
import LoadingOverlay from "../../utils/LoadingOverlay";
import _ from "lodash";
// ---- CGL -> report template mapping (new) ----
import TemplateMappingSection from "./templateMapping/TemplateMappingSection";
import useTemplateMappingApi from "./templateMapping/useTemplateMappingApi";
import {
  TEMPLATE_MAPPING_ENABLED,
  TEMPLATE_MAPPING_REQUIRED,
  MAPPING_OPTIONAL_CLASSIFICATIONS,
  sameMappingSet,
  toPayloadMapping,
} from "./templateMapping/templateMappingConfig";

const initialCGLState = {
  comp1: "",
  segmentCode: "",
  comp2: "",
  description: "",
  acClassification: "",
  balFwd: false,
  defBalType: "",
  balCompare: "1",
  manualPosting: "1",
  status: "Active",
  openDate: new Date().toISOString().split("T")[0],
  closeDate: null,
};

function classificationFromComp1(comp1Val) {
  if (!comp1Val || comp1Val.length === 0) return null;
  const ch = String(comp1Val)[0];
  if (ch === "1" || ch === "6") return "A"; // Asset
  if (ch === "2" || ch === "3" || ch === "4") return "L"; // Liability
  if (ch === "5") return "M"; // Memo
  if (ch === "7") return "I"; // Income
  if (ch === "8") return "E"; // Expense
  return null;
}

function defBalTypeFromClassification(ac) {
  switch (ac) {
    case "A":
      return "D";
    case "L":
      return "C";
    case "M":
      return "M";
    case "I":
      return "C";
    case "E":
      return "D";
    default:
      return "";
  }
}

const descRegex = /^[A-Za-z0-9 .,"<>/&()=_-]*$/;

export default function CGLDialog({
  open,
  onClose,
  onSaved,
  editInitialData = null,
  accountClassifications = null,
  permissions = {},
}) {
  const { callApi } = useApi();
  const mappingApi = useTemplateMappingApi();
  const snackbar = useCustomSnackbar();
  const [cglData, setCglData] = useState(initialCGLState);
  const [errors, setErrors] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [loadOverlay, setLoadOverlay] = useState(false);
  const [segments, setSegments] = useState([]);
  const [blockConfirmOpen, setBlockConfirmOpen] = useState(false);
  const [classificationLocked, setClassificationLocked] = useState(false);

  // ---- template mapping state ----
  const [mappings, setMappings] = useState([]); // picker targets selected for this CGL
  const [initialMappings, setInitialMappings] = useState([]); // what the CGL has today (edit only)
  const [mappingsLoading, setMappingsLoading] = useState(false);
  const [mappingsError, setMappingsError] = useState("");

  // throttle snackbars during typing
  const snackGateRef = useRef(true);
  const notifyOnce = (msg, variant = "warning") => {
    if (!snackGateRef.current) return;
    snackGateRef.current = false;
    snackbar(msg, variant);
    setTimeout(() => (snackGateRef.current = true), 800);
  };

  // derived cglNumber
  const cglNumber = useMemo(() => {
    return cglData.comp1 && cglData.segmentCode && cglData.comp2
      ? `${cglData.comp1}${cglData.segmentCode}${String(cglData.comp2).padStart(
          2,
          "0",
        )}`
      : "";
  }, [cglData.comp1, cglData.segmentCode, cglData.comp2]);

  // load segments
  const fetchSegments = useCallback(async () => {
    const resp = await callApi(
      "/CM/common-master/segment-codes",
      { requestType: "SEGMENT_CODE" },
      "GET",
    );
    setSegments(resp?.data || []);
  }, [callApi]);

  // load the mapping the CGL has today (edit flow)
  const loadExistingMappings = useCallback(
    async (existingCglNumber) => {
      if (!TEMPLATE_MAPPING_ENABLED || !existingCglNumber) return;
      try {
        setMappingsLoading(true);
        setMappingsError("");
        const list = await mappingApi.fetchCglMappings(existingCglNumber);
        setMappings(list);
        setInitialMappings(list);
      } catch (e) {
        setMappingsError(e?.message || "Please retry.");
      } finally {
        setMappingsLoading(false);
      }
    },
    [mappingApi],
  );

  // when dialog opens for Add or Edit, populate
  useEffect(() => {
    if (!open) return;
    fetchSegments();

    if (editInitialData) {
      // populate form from editInitialData
      const mapped = classificationFromComp1(editInitialData.comp1 ?? "");

      const initial = {
        ...initialCGLState,
        ...editInitialData,
        comp1: editInitialData.comp1 ?? "",
        comp2: editInitialData.comp2 ?? "",
        segmentCode: editInitialData.segmentCode ?? "",
        description: editInitialData.description ?? "",
        balFwd: !!editInitialData.balFwd,
      };

      // if comp1 determines classification, enforce it and lock dropdown
      if (mapped) {
        initial.acClassification = mapped;
        initial.defBalType = defBalTypeFromClassification(mapped);
        setClassificationLocked(true);
      } else {
        initial.acClassification = editInitialData.acClassification ?? "";
        initial.defBalType =
          editInitialData.defBalType ||
          defBalTypeFromClassification(initial.acClassification);
        setClassificationLocked(false);
      }

      // Apply balFwd and balCompare rules based on classification
      const ac = initial.acClassification;
      if (ac === "A" || ac === "L") {
        initial.balFwd = true;
        initial.balCompare = initial.balCompare ?? "1";
      } else if (ac === "I" || ac === "E") {
        initial.balFwd = false;
        initial.balCompare = "0";
      }

      setCglData(initial);
      setEditingId(editInitialData.cglNumber);
      setErrors({});

      setMappings([]);
      setInitialMappings([]);
      loadExistingMappings(editInitialData.cglNumber);
    } else {
      // fresh
      setCglData(initialCGLState);
      setEditingId(null);
      setErrors({});
      setClassificationLocked(false);
      setMappings([]);
      setInitialMappings([]);
      setMappingsError("");
    }
  }, [open, editInitialData, fetchSegments, loadExistingMappings]);

  // whenever acClassification changes we auto-set defBalType and adjust balFwd / balCompare rules
  useEffect(() => {
    const ac = cglData.acClassification;
    if (!ac) {
      setCglData((prev) => {
        const next = {
          ...prev,
          balFwd: false,
          defBalType: "",
          balCompare: "1",
          manualPosting: "1",
        };
        return next;
      });
    }

    setCglData((prev) => {
      const newDef = defBalTypeFromClassification(ac);
      const next = { ...prev, defBalType: newDef };

      // balFwd rules:
      if (ac === "A" || ac === "L") {
        next.balFwd = true; // disabled & checked
      } else if (ac === "I" || ac === "E") {
        next.balFwd = false; // disabled & unchecked
      } // else leave balFwd as-is (user can change)

      // balCompare rules:
      if (ac === "I" || ac === "E") {
        next.balCompare = "0"; // force exclude
      }

      return next;
    });
  }, [cglData.acClassification]);

  // single-field validator
  const validateField = useCallback((name, value) => {
    switch (name) {
      case "comp1":
        if (!value) return "Comp1 is required";
        if (!/^\d{4}$/.test(value)) return "Comp1 must be exactly 4 digits";
        if (parseInt(value, 10) < 1000) return "Comp1 must be ≥ 1000";
        return "";
      case "segmentCode":
        if (!value) return "Segment code is required";
        return "";
      case "comp2":
        if (!value) return "Comp2 is required";
        if (!/^\d{2}$/.test(value)) return "Comp2 must be 2 digits";
        if (parseInt(value, 10) < 1 || parseInt(value, 10) > 99)
          return "Comp2 must be between 01 and 99";
        return "";
      case "description":
        if (!value) return "Description is required";
        if (!descRegex.test(value))
          return 'Only letters, digits, spaces, .,"<>/&()=_-';
        if (value?.trim()?.length < 5 || value?.trim()?.length > 100)
          return "Description should be min 5 and max 100 characters";
        return "";
      case "acClassification":
        if (!value) return "Account classification is required";
        return "";
      default:
        return "";
    }
  }, []);

  // ---- template mapping rules ----
  const mappingRequired =
    TEMPLATE_MAPPING_ENABLED &&
    TEMPLATE_MAPPING_REQUIRED &&
    !MAPPING_OPTIONAL_CLASSIFICATIONS.includes(cglData.acClassification);

  // For an update the existing mapping must have been read, otherwise we could not tell what the user changed.
  const mappingsReady =
    !TEMPLATE_MAPPING_ENABLED || !editingId || (!mappingsLoading && !mappingsError);

  const mappingValid =
    !TEMPLATE_MAPPING_ENABLED ||
    (!mappingsLoading &&
      !(mappingsError && mappingRequired) &&
      (!mappingRequired || !mappingsReady || mappings.length > 0));

  const isFormValid = useMemo(() => {
    const fields = [
      "comp1",
      "segmentCode",
      "comp2",
      "description",
      "acClassification",
    ];
    return (
      fields.every((f) => !validateField(f, cglData[f])) && mappingValid
    );
  }, [cglData, validateField, mappingValid]);

  const handleChange = useCallback(
    (e) => {
      const { name, value, type, checked } = e.target;

      // hard-constraints / input blocking
      if (name === "comp1") {
        if (!/^\d*$/.test(value)) {
          notifyOnce("Comp1 accepts digits only");
          return;
        }
        if (value.length > 4) {
          notifyOnce("Comp1 must be exactly 4 digits");
          return;
        }
      }

      if (name === "comp2") {
        if (!/^\d*$/.test(value)) {
          notifyOnce("Comp2 accepts numbers only");
          return;
        }
        if (value.length > 2) {
          notifyOnce("Comp2 should be 2 digits");
          return;
        }
      }

      if (name === "description") {
        if (value && !/^[A-Za-z0-9]$/.test(value[0])) {
          notifyOnce("Should not start with special character");
          return;
        }
        if (!descRegex.test(value)) {
          notifyOnce("Invalid character in Description");
          return;
        }
      }

      if (name === "comp1") {
        const newComp1 = value;
        setCglData((prev) => ({ ...prev, comp1: newComp1 }));
        const mapped = classificationFromComp1(newComp1);
        if (mapped) {
          setCglData((prev) => {
            const def = defBalTypeFromClassification(mapped);
            const updated = {
              ...prev,
              comp1: newComp1,
              acClassification: mapped,
              defBalType: def,
            };

            if (mapped === "A" || mapped === "L") updated.balFwd = true;
            else if (mapped === "I" || mapped === "E") updated.balFwd = false;

            if (mapped === "I" || mapped === "E") updated.balCompare = "0";

            return updated;
          });
          setClassificationLocked(true);

          setErrors((prev) => ({ ...prev, comp1: "", acClassification: "" }));
        } else {
          setClassificationLocked(false);
          setCglData((prev) => ({ ...prev, acClassification: "" }));
        }

        // validate comp1
        const err = validateField("comp1", newComp1);
        setErrors((prev) => ({ ...prev, comp1: err }));
        return;
      }

      // For balFwd checkbox toggling (only possible when enabled)
      if (name === "balFwd") {
        setCglData((prev) => ({ ...prev, balFwd: checked }));
        setErrors((prev) => ({ ...prev, balFwd: "" }));
        return;
      }

      // For balCompare (radio)
      if (name === "balCompare") {
        setCglData((prev) => ({ ...prev, balCompare: value }));
        setErrors((prev) => ({ ...prev, balCompare: "" }));
        return;
      }

      // Normal update for other fields
      setCglData((prev) => ({
        ...prev,
        [name]: type === "checkbox" ? checked : value,
      }));

      // set per-field error
      const msg = validateField(name, type === "checkbox" ? checked : value);
      setErrors((prev) => ({ ...prev, [name]: msg }));
    },
    [cglData, notifyOnce, validateField],
  );

  const validateForm = useCallback(() => {
    const fields = [
      "comp1",
      "segmentCode",
      "comp2",
      "description",
      "acClassification",
    ];
    const newErrors = {};
    fields.forEach((f) => {
      const msg = validateField(f, cglData[f]);
      if (msg) newErrors[f] = msg;
    });
    setErrors(newErrors);
    if (Object.keys(newErrors).length) {
      snackbar("Please fix validation errors", "error");
      return false;
    }
    if (!mappingValid) {
      snackbar("Select at least one Head / Variable for the CGL", "error");
      return false;
    }
    return true;
  }, [cglData, validateField, snackbar, mappingValid]);

  // submit — dialog does the API call
  const handleSubmit = useCallback(
    async (e) => {
      e?.preventDefault();
      if (!validateForm()) return;

      setLoadOverlay(true);
      try {
        const apiEndpoint = "/CR/create-request";
        const method = "POST";
        const changeType = editingId ? "UPDATE" : "ADD";

        const effectiveDef = defBalTypeFromClassification(
          cglData.acClassification,
        );

        const innerPayload = {
          comp1: cglData.comp1,
          segmentCode: cglData.segmentCode,
          comp2: cglData.comp2,
          description: cglData.description,
          acClassification: cglData.acClassification,
          balFwd: cglData.balFwd ? 1 : 0,
          defBalType: effectiveDef,
          status: cglData.status == "Active" ? 1 : cglData.status,
          balCompare: cglData.balCompare,
          manualPosting: cglData.manualPosting,
        };
        delete innerPayload.cglNumber;

        const initialData = { ...editInitialData };
        delete initialData.cglNumber;
        delete initialData.openDate;
        delete initialData.closeDate;

        if (innerPayload.description.trim().length < 5) {
          snackbar("Description should be minimum 5 characters", "warning");
          return;
        }

        // "nothing changed" check now also looks at the template mapping
        const mappingUnchanged =
          !TEMPLATE_MAPPING_ENABLED ||
          !mappingsReady ||
          sameMappingSet(initialMappings, mappings);
        if (_.isEqual(initialData, innerPayload) && mappingUnchanged) {
          snackbar("Kindly Modify data before saving", "warning");
          return;
        }

        // Sent as the complete desired set. Left out when the current mapping could not be read,
        // so an update can never wipe a mapping it did not see.
        if (TEMPLATE_MAPPING_ENABLED && mappingsReady) {
          innerPayload.templateMappings = mappings.map(toPayloadMapping);
        }

        const payloadData = {
          requestType: "CGL_CODE",
          changeType,
          payload: innerPayload,
        };

        const response = await callApi(apiEndpoint, payloadData, method);
        if (response) {
          snackbar(
            editingId
              ? "CGL update request submitted successfully with request id " +
                  response?.data?.id
              : "CGL creation request submitted successfully with request id " +
                  response?.data?.id,
            "success",
          );

          onSaved?.();
          handleClose();
        } else {
          snackbar("No response from server", "error");
        }
      } catch (error) {
        console.error(error);
        snackbar(error?.message || "Request failed", "error");
      } finally {
        setLoadOverlay(false);
      }
    },
    [
      callApi,
      cglData,
      cglNumber,
      editingId,
      onSaved,
      snackbar,
      validateForm,
      mappings,
      initialMappings,
      mappingsReady,
    ],
  );

  const handleReset = useCallback(() => {
    setCglData(initialCGLState);
    setEditingId(null);
    setErrors({});
    setClassificationLocked(false);
    setMappings([]);
    setInitialMappings([]);
    setMappingsError("");
  }, []);

  const handleClose = useCallback(() => {
    onClose?.();
    handleReset();
    setBlockConfirmOpen(false);
  }, [onClose, handleReset]);

  // block flow — dialog owns the blocking behaviour (local mock here)
  const openBlockConfirm = useCallback(() => {
    setBlockConfirmOpen(true);
  }, []);

  const handleBlockUnBlockConfirm = useCallback(async () => {
    try {
      setLoadOverlay(true);
      const newData = { ...editInitialData };
      const isActive = newData.status == "1";
      delete newData.cglNumber;
      delete newData.openDate;
      delete newData.closeDate;
      newData.status = isActive ? "0" : "1";
      const changeType = isActive ? "BLOCK" : "UNBLOCK";

      // block / unblock never touch the template mapping, so no templateMappings here
      const payload = {
        requestType: "CGL_CODE",
        changeType,
        payload: newData,
      };

      const resp = await callApi("/CR/create-request", payload, "POST");
      if (resp) {
        snackbar(
          `CGL ${isActive ? "block" : "unblock"} request created successfully`,
          "success",
        );
        onSaved?.();
      } else {
        snackbar("Block failed", "error");
      }
    } catch (err) {
      snackbar(err?.message || "Block request failed", "error");
    } finally {
      setBlockConfirmOpen(false);
      setLoadOverlay(false);
      handleClose();
    }
  }, [editInitialData, callApi, snackbar, onSaved, handleClose]);

  // helpers to decide UI disabled state based on current classification
  const classification = cglData.acClassification;
  const isBalFwdDisabled =
    classification === "A" ||
    classification === "L" ||
    classification === "I" ||
    classification === "E";
  const balFwdChecked =
    classification === "A" || classification === "L"
      ? true
      : classification === "I" || classification === "E"
        ? false
        : cglData.balFwd;
  const isBalCompareDisabled = classification === "I" || classification === "E";

  const getSegmentValue = (code, allSegments) => {
    return allSegments.find((segment) => segment.segmentCode === code) || null;
  };

  return (
    <>
      <LoadingOverlay loading={loadOverlay} />
      <Dialog
        open={open}
        fullWidth
        maxWidth="md"
        component="form"
        onSubmit={handleSubmit}
      >
        <DialogTitle>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h6" color="primary">
              {editingId ? "Edit CGL" : "Add New CGL"}
            </Typography>
            <IconButton onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <Divider />

        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12 }}>
                <Box display="flex" gap={1}>
                  <TextField
                    fullWidth
                    label="Comp1 *"
                    name="comp1"
                    value={cglData.comp1}
                    onChange={handleChange}
                    error={!!errors.comp1}
                    helperText={errors.comp1 || "Exactly 4 numbers(≥1000)"}
                    placeholder="1000 to 9999"
                    disabled={!!editingId}
                    slotProps={{
                      input: {
                        maxLength: 4,
                        inputMode: "numeric",
                      },
                    }}
                  />

                  <Autocomplete
                    fullWidth
                    options={segments}
                    getOptionLabel={(option) =>
                      `${option.segmentCode} - ${option.description}`
                    }
                    value={getSegmentValue(cglData.segmentCode, segments)}
                    onChange={(event, newValue) => {
                      // Manually call the parent form handler to update the state with the segmentCode
                      handleChange({
                        target: {
                          name: "segmentCode",
                          value: newValue ? newValue.segmentCode : "",
                        },
                      });
                    }}
                    disabled={!!editingId}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Segment Code *"
                        name="segmentCode"
                        error={!!errors.segmentCode}
                        helperText={errors.segmentCode}
                      />
                    )}
                  />

                  <TextField
                    fullWidth
                    label="Comp2 *"
                    name="comp2"
                    value={cglData.comp2?.toString()}
                    onChange={handleChange}
                    error={!!errors.comp2}
                    helperText={errors.comp2 || "Exactly 2 numbers(01-99)"}
                    placeholder="01-99"
                    disabled={!!editingId}
                    slotProps={{
                      input: {
                        maxLength: 2,
                      },
                    }}
                  />
                </Box>
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Card variant="outlined" sx={{ p: 2, width: "100%" }}>
                  <Typography variant="h6" color="textDisabled">
                    CGL Code {cglNumber || ""}
                  </Typography>
                </Card>
              </Grid>

              <Grid size={{ xs: 12 }} sm={6}>
                <TextField
                  fullWidth
                  label="Description *"
                  name="description"
                  value={cglData.description}
                  onChange={handleChange}
                  error={!!errors.description}
                  slotProps={{ htmlInput: { maxLength: 100 } }}
                  helperText={
                    errors.description ||
                    'Allowed 5-100 characters (alphabets, numbers, spaces,._"<>/&()=-)'
                  }
                  multiline
                  rows={3}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Box display="flex" gap={2}>
                  {/* Account Classification: auto-set & disabled when classificationLocked is true */}
                  <TextField
                    select
                    fullWidth
                    label="Account Classification *"
                    name="acClassification"
                    value={cglData.acClassification}
                    onChange={handleChange}
                    error={!!errors.acClassification}
                    helperText={
                      classificationLocked
                        ? "Set by Comp1"
                        : errors.acClassification || ""
                    }
                    disabled={classificationLocked}
                  >
                    <MenuItem value="">Select Classification</MenuItem>
                    {accountClassifications.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>

                  {/* Default Balance Type is HIDDEN from UI (auto-managed) */}
                </Box>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <FormControl component="fieldset" fullWidth>
                  <FormLabel component="legend">Balance Compare Flag</FormLabel>
                  <RadioGroup
                    row
                    name="balCompare"
                    value={cglData.balCompare}
                    onChange={handleChange}
                  >
                    <FormControlLabel
                      value="1"
                      control={<Radio />}
                      label="Include"
                      disabled={isBalCompareDisabled}
                    />
                    <FormControlLabel
                      value="0"
                      control={<Radio />}
                      label="Exclude"
                      disabled={isBalCompareDisabled}
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <FormControl component="fieldset" fullWidth>
                  <FormLabel component="legend">Manual Posting Flag</FormLabel>
                  <RadioGroup
                    row
                    name="manualPosting"
                    value={cglData.manualPosting}
                    onChange={handleChange}
                  >
                    <FormControlLabel
                      value="1"
                      control={<Radio />}
                      label="Allowed"
                    />
                    <FormControlLabel
                      value="0"
                      control={<Radio />}
                      label="Not Allowed"
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>

              <Grid size={{ xs: 12 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      name="balFwd"
                      checked={!!balFwdChecked}
                      onChange={handleChange}
                      disabled={isBalFwdDisabled}
                    />
                  }
                  label="Balance Carry Forward to next year"
                />
                <FormHelperText>
                  {classification === "I" || classification === "E"
                    ? "Not applicable for Income/Expense accounts (Unchecked)"
                    : classification === "A" || classification === "L"
                      ? "Automatically enabled for Asset/Liability"
                      : ""}
                </FormHelperText>
              </Grid>

              {/* ---- Report template mapping (NWSA / YSA / PNL / PFORM) ---- */}
              {TEMPLATE_MAPPING_ENABLED && (
                <Grid size={{ xs: 12 }}>
                  <TemplateMappingSection
                    cglNumber={editingId || cglNumber}
                    mappings={mappings}
                    onChange={setMappings}
                    loading={mappingsLoading}
                    error={mappingsError}
                    onRetry={() => loadExistingMappings(editingId)}
                    required={mappingRequired}
                  />
                </Grid>
              )}
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Box
            sx={{
              mt: 3,
              display: "flex",
              gap: 1,
              justifyContent: "flex-end",
            }}
          >
            {!editingId && (
              <Button
                onClick={handleReset}
                variant="outlined"
                sx={{
                  "&:hover": {
                    color: "#fff",
                  },
                }}
              >
                Reset
              </Button>
            )}

            {permissions?.block &&
              editingId &&
              editInitialData.status == "1" && (
                <Button
                  onClick={openBlockConfirm}
                  variant="contained"
                  color="error"
                  startIcon={<BlockIcon />}
                >
                  Block CGL
                </Button>
              )}

            {permissions?.unblock &&
              editingId &&
              editInitialData.status == "0" && (
                <Button
                  onClick={openBlockConfirm}
                  variant="contained"
                  color="warning"
                  startIcon={<LockOpenIcon />}
                >
                  Un Block CGL
                </Button>
              )}

            {permissions?.modify && editingId && (
              <Button
                type="submit"
                variant="contained"
                startIcon={<EditIcon />}
                disabled={!isFormValid}
              >
                Update CGL
              </Button>
            )}

            {permissions?.create && !editingId && (
              <Button
                type="submit"
                variant="contained"
                startIcon={<AddIcon />}
                disabled={!isFormValid}
              >
                Add CGL
              </Button>
            )}
          </Box>
        </DialogActions>
      </Dialog>

      {/* Block confirmation dialog (owned by dialog component) */}
      <Dialog
        open={blockConfirmOpen}
        onClose={() => setBlockConfirmOpen(false)}
      >
        <DialogTitle>
          {editingId && editInitialData.status == "1" ? "Block" : "Un Block"}{" "}
          CGL
        </DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to{" "}
            {editingId && editInitialData.status == "1" ? "Block" : "Un Block"}{" "}
            CGL {editingId || cglNumber}?
          </Typography>
        </DialogContent>
        <Box sx={{ display: "flex", gap: 1, justifyContent: "flex-end", p: 2 }}>
          <Button onClick={() => setBlockConfirmOpen(false)}>Cancel</Button>
          <Button
            color={
              editingId && editInitialData.status == "1" ? "error" : "success"
            }
            variant="contained"
            onClick={handleBlockUnBlockConfirm}
          >
            {editingId && editInitialData.status == "1"
              ? "Block CGL"
              : "Un Block CGL"}
          </Button>
        </Box>
      </Dialog>
    </>
  );
}
