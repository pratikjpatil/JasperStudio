# CGL Template Mapping: UI

## Where the data comes from
| Data | Source | Why |
|---|---|---|
| Heads / Variables of NWSA, YSA, PNL, PFORM (the picker) | **Template Configuration Service** `GET .../cgl-mappings/targets?reportId=` | Only it reads the template JSON, so the list always matches the active template version |
| Current mapping of a CGL (edit pre-fill, "copy from CGL", lookup screen) | **Template Configuration Service** `GET .../cgl-mappings/by-cgl/{cgl}` | The template JSON is the source of truth for which CGL sits in which Head/Variable |
| CGL search for "copy from" | existing **Common Master** `/CM/common-master/view-cgl` | same lookup the CGL Master Lookup screen uses |
| Saving | existing **Common Request** `/CR/create-request` with `templateMappings` inside the CGL payload | maker-checker unchanged; nothing is written until approval |

Common Master is **not** used for the mapping: it only holds the CGL master record.

## Files (drop into your CGL components folder)
```
CGLDialog.jsx                         <- replaces the existing file (full file)
MyCGLRequestsTab.jsx                  <- replaces the existing file (full file): request screen
templateMapping/
  templateMappingConfig.js            <- switches, gateway path, helpers
  useTemplateMappingApi.js            <- the 3 API calls
  TemplateMappingSection.jsx          <- block shown inside the CGL form
  MappingPickerDialog.jsx             <- tabbed picker (NWSA | YSA | PNL | PFORM)
  CopyMappingDialog.jsx               <- copy another CGL's mapping
  TemplateMappingView.jsx             <- read-only list (lookup screen)
  CglRequestMappingPanel.jsx          <- mapping of a request, with New / Removed / No change (reusable)
  CglRequestMappingDialog.jsx         <- dialog around the panel (My Requests)
```
Imports assume the files sit in `src/components/<cgl folder>/` (same depth as your current `CGLDialog.jsx`: `../../hooks/useApi`, `../../utils/...`). Adjust the `../../../` imports inside `templateMapping/` if your folder depth differs.

## Must set before testing
1. `TEMPLATE_MAPPING_API_BASE` in `templateMappingConfig.js` = the gateway prefix that routes to the Template service (like `/CM`, `/CR`). I used `/TC/template-config/cgl-mappings` as a placeholder.
2. `TEMPLATE_MAPPING_REQUIRED` must equal `cgl.mapping.enforced` on the Common Request Service.
3. `MAPPING_OPTIONAL_CLASSIFICATIONS`: add `"M"` if Memo CGLs do not need a mapping.
4. Gateway/RBAC: allow the new Template service paths for maker and checker roles.

## Two small edits in existing screens
**CglView.jsx** (lookup screen): show the mapping of the selected CGL.
```jsx
import TemplateMappingView from "./templateMapping/TemplateMappingView";
// inside the details <Box>, right after the closing </Grid> of the details grid:
<Divider sx={{ my: 3 }} />
<TemplateMappingView cglNumber={selected.cglNumber} />
```
**MyCGLRequestsTab.jsx** (request screen): use the full file provided. It adds a "Template Mapping" column (chip with the count, tooltip with the per-report split) that opens a dialog showing what the request maps the CGL to. While a request is PENDING and is an UPDATE, the dialog compares with the CGL's current mapping and marks every Head/Variable **New**, **Removed** or **No change**; an ADD shows everything as New; approved requests also show the "Template mappings: PNL v3->v4" result written at approval. The existing View dialog is unchanged except for a one-line "Template Mapping" summary.

**Checker / approval screen** (the screen where pending CGL requests are approved or rejected; its code was not in what you sent): drop the same panel into its view dialog.
```jsx
import CglRequestMappingPanel from "./templateMapping/CglRequestMappingPanel";
<CglRequestMappingPanel
  cglNumber={`${p.comp1}${p.segmentCode}${p.comp2}`}   // p = request payload
  changeType={request.changeType}
  reqStatus={request.reqStatus}
  mappings={p.templateMappings}                         // undefined for old requests
  executionRemarks={request.executionRemarks}
/>
```

## Optional backend addition (better "My Requests" / checker view)
The UI also sends display text with each mapping (`headText`, `subHeadText`, `codeText`, `columnName`). The Common Request DTO currently ignores them, so saved requests only keep ids. To store them, add four fields to `CglTemplateMappingDto`:
```java
private String headText;
private String subHeadText;
private String codeText;
private String columnName;
```
Nothing else changes; the Template service ignores them.

## UX walkthrough
- **Create CGL**: new "Report Template Mapping" card at the bottom of the form with a Required chip and per-report counters (NWSA 0, YSA 0, PNL 0, PFORM 0). "Add CGL" stays disabled until at least one mapping exists.
- **Select Heads & Variables**: big dialog, one tab per report with a badge of what is ticked. Targets load when a tab is opened (skeleton rows, retry on error). Search by code/head/sub head/column/variable, column filter (PNL's two amount columns), "Selected only" switch, 25 rows per page, per-row "N CGLs mapped" and extra filters such as `CURRENCY IN ["USD"]`. Nothing is applied until "Apply selection".
- **Copy from another CGL**: search a CGL (3+ characters), see its live mapping grouped by report with checkboxes (all ticked), items already in your selection are marked "Already added", choose "Add to my current selection" or "Replace". Copied rows show a "Copied from <CGL>" chip and can be removed individually.
- **Edit CGL**: current mapping is loaded from the templates (skeleton while loading, Retry on failure). Editing is blocked while it cannot be read, so an update can never wipe a mapping it did not see. Moving a CGL between Heads (PNL) = untick old row, tick new row.
- **Save**: the CGL payload carries `templateMappings` as the **complete desired set**. "Kindly modify data" now also counts a mapping-only change as a change. Block / Unblock do not send mappings.
- A heads-up appears when the same CGL is mapped to more than one Head of a report (allowed, may double count).

## Assumptions to check
- `callApi(url, payload, "GET")` sends the payload as query parameters (as your `segment-codes` call does) and returns the response body, so `resp.data` is the Template service's `data` array.
- Backend rejecting an UPDATE where only the mapping changed (no master field change) would show as a normal error snackbar; tell me if your Common Request validation does that.
- Not run in a browser: files were only syntax-checked (esbuild), no tests written.
