import React, { useState, useMemo, useEffect } from "react";
import {
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  Typography,
  Tooltip,
  IconButton,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import CancelIcon from "@mui/icons-material/Cancel";
import VisibilityIcon from "@mui/icons-material/Visibility";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import BlockFlippedIcon from "@mui/icons-material/BlockFlipped";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AddBoxIcon from "@mui/icons-material/AddBox";
import AutoDeleteIcon from "@mui/icons-material/AutoDelete";
import EditDocumentIcon from "@mui/icons-material/EditDocument";
import GppBadIcon from "@mui/icons-material/GppBad";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import useApi from "../../hooks/useApi";
import CustomChip from "../../utils/CustomChip";
import {
  getPermissions,
  timeStampFormatter,
} from "../../utils/CommonUtilities";
import InfoIcon from "@mui/icons-material/Info";
import useCustomSnackbar from "../../utils/useCustomSnackbar";
import { useSelector } from "react-redux";
import ViewMyRequestDialog from "../common/ViewMyRequestDialog";
import DatasetIcon from "@mui/icons-material/Dataset";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import TrendingDownIcon from "@mui/icons-material/TrendingDown";
import NoteIcon from "@mui/icons-material/Note";
// ---- CGL -> report template mapping (new) ----
import CglRequestMappingDialog from "./templateMapping/CglRequestMappingDialog";
import {
  TEMPLATE_MAPPING_ENABLED,
  summarizeMappings,
} from "./templateMapping/templateMappingConfig";

function CustomNoRowsOverlay() {
  return (
    <Stack height="100%" alignItems="center" justifyContent="center">
      <InfoIcon sx={{ fontSize: 48, color: "text.secondary", mb: 2 }} />
      <Typography variant="h6">No CGL Requests Found</Typography>
      <Typography>You have not created any CGL requests.</Typography>
    </Stack>
  );
}

const ACCOUNT_CLASSIFICATIONS = [
  { value: "A", label: "Asset", icon: <DatasetIcon fontSize="small" /> },
  {
    value: "L",
    label: "Liability",
    icon: <AccountBalanceWalletIcon fontSize="small" />,
  },
  { value: "I", label: "Income", icon: <TrendingUpIcon fontSize="small" /> },
  { value: "E", label: "Expense", icon: <TrendingDownIcon fontSize="small" /> },
  { value: "M", label: "Memo A/c", icon: <NoteIcon fontSize="small" /> },
];

export default function MyCGLRequestsTab() {
  const [cglList, setCglList] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [requestId, setRequestId] = useState(null);
  const [viewOpen, setViewOpen] = useState(false);
  const [viewData, setViewData] = useState(null);
  const [mappingViewRow, setMappingViewRow] = useState(null); // request whose template mapping is shown
  const { callApi } = useApi();
  const showSnackBar = useCustomSnackbar();
  const selectedMenuItem = useSelector((state) => state.menus.selectedMenuItem);
  const permissions = getPermissions(selectedMenuItem);

  const fetchData = async () => {
    try {
      setIsLoading(true);
      const payload = { requestType: "CGL_CODE" };
      const response = await callApi("/CR/my-requests", payload, "POST");
      const result = response.data?.map((row) => {
        let parsedPayload = {};
        parsedPayload = row.payload ? row.payload : {};
        const { comp1 = "", segmentCode = "", comp2 = "" } = parsedPayload;
        parsedPayload = {
          ...parsedPayload,
          ...row,
        };
        return {
          ...parsedPayload,
          cglNumber: `${comp1}${segmentCode}${comp2}`,
        };
      });
      setCglList(result);
    } catch (error) {
      console.error(
        "Something went wrong, Kindly try again after sometime.",
        error,
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCancelRequest = async () => {
    try {
      const payload = {
        requestId,
        remarks: "User canceled this Request",
      };

      const response = await callApi("/CR/cancel-request", payload, "PATCH");
      if (response?.success) {
        showSnackBar(
          `Request Id ${requestId} Cancelled Successfully.`,
          "success",
        );
      } else {
        showSnackBar(
          response?.message
            ? response?.message
            : "Failed to process your cancel request, Kindly try again",
          "error",
        );
      }
    } catch (error) {
      console.error(error);
    } finally {
      fetchData();
      setConfirmDialog(false);
    }
  };

  const handleViewClick = (data) => {
    const {
      comp1,
      segmentCode,
      comp2,
      description,
      acClassification,
      balFwd,
      defBalType,
      status,
      balCompare,
      manualPosting,
      templateMappings,
    } = data;

    const accountClassifications = ACCOUNT_CLASSIFICATIONS.find(
      (x) => x.value === acClassification,
    );

    const balanceForward = balFwd == "1" ? "Yes" : "No";

    const defaultBalanceType =
      defBalType == "C" ? "Credit" : defBalType == "D" ? "Debit" : "Memo";

    const cglStatus = status == "1" ? "Active" : "Inactive";

    const balanceCompare = balCompare == "1" ? "Include" : "Exclude";

    const manualPostingAllowed = manualPosting == "1" ? "Yes" : "No";

    const showData = {
      "CGL Code": comp1 + segmentCode + comp2,
      description,
      accountClassification: accountClassifications.label,
      comp1,
      segmentCode,
      comp2,
      balanceForward,
      // defaultBalanceType,
      "CGL Status": cglStatus,
      balanceCompare,
      manualPostingAllowed,
      // one-line summary here; the full list is in the "Template mapping" dialog
      ...(TEMPLATE_MAPPING_ENABLED && Array.isArray(templateMappings)
        ? { "Template Mapping": summarizeMappings(templateMappings) }
        : {}),
    };

    data.showData = showData;
    setViewData(data);
    setViewOpen(true);
  };

  const columns = useMemo(
    () => [
      { field: "id", headerName: "Request Id", flex: 0.5, minWidth: 150 },
      {
        field: "cglNumber",
        headerName: "CGL Code",
        flex: 1,
        minWidth: 150,
        renderCell: (params) => <Box>{params.value}</Box>,
      },
      {
        field: "description",
        headerName: "Description",
        flex: 2,
        minWidth: 300,
        sortable: true,
      },
      {
        field: "changeType",
        headerName: "Request Type",
        flex: 0.5,
        minWidth: 150,
        headerAlign: "center",
        align: "center",
        filterable: false,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (params) => {
          const val = params.value;
          const color =
            val === "ADD" ? "success" : val === "DELETE" ? "error" : "warning";
          const icon =
            val === "ADD" ? (
              <AddBoxIcon />
            ) : val === "DELETE" ? (
              <AutoDeleteIcon />
            ) : (
              <EditDocumentIcon />
            );
          return (
            <CustomChip
              sx={{
                width: 105,
                justifyContent: "flex-start",
              }}
              icon={icon}
              label={
                val === "ADD"
                  ? "Added"
                  : val === "DELETE"
                    ? "Deleted"
                    : "Modified"
              }
              color={color}
              variant="outlined"
            />
          );
        },
      },

      // ---- new: how many Heads/Variables the request maps the CGL to ----
      ...(TEMPLATE_MAPPING_ENABLED
        ? [
            {
              field: "templateMappings",
              headerName: "Template Mapping",
              flex: 0.7,
              minWidth: 170,
              headerAlign: "center",
              align: "center",
              filterable: false,
              sortable: false,
              disableColumnMenu: true,
              renderCell: (params) => {
                const list = params.row.templateMappings;
                if (!Array.isArray(list)) {
                  return (
                    <Typography variant="caption" color="text.secondary">
                      -
                    </Typography>
                  );
                }
                return (
                  <Tooltip title={summarizeMappings(list)}>
                    <Chip
                      size="small"
                      variant="outlined"
                      icon={<AccountTreeIcon />}
                      label={`${list.length} mapped`}
                      onClick={() => setMappingViewRow(params.row)}
                    />
                  </Tooltip>
                );
              },
            },
          ]
        : []),

      {
        field: "reqDate",
        headerName: "Requested Date",
        flex: 1,
        minWidth: 200,
        filterable: false,
        disableColumnMenu: true,
        renderCell: (params) => timeStampFormatter(params.value),
      },
      {
        field: "reqStatus",
        headerName: "Status",
        flex: 1,
        minWidth: 150,
        headerAlign: "center",
        align: "center",
        filterable: false,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (params) => (
          <Box>
            <CustomChip
              variant="outlined"
              icon={
                params.value === "REJECTED" ? (
                  <BlockFlippedIcon />
                ) : params.value === "ACCEPTED" ? (
                  <CheckCircleIcon />
                ) : params.value === "CANCELLED" ? (
                  <GppBadIcon />
                ) : (
                  <PendingActionsIcon />
                )
              }
              label={
                params.value === "REJECTED"
                  ? "Rejected"
                  : params.value === "ACCEPTED"
                    ? "Approved"
                    : params.value === "CANCELLED"
                      ? "Cancelled"
                      : "Pending"
              }
              sx={{
                width: 120,
                justifyContent: "flex-start",
                color:
                  params.value === "REJECTED"
                    ? "error.dark"
                    : params.value === "ACCEPTED"
                      ? "success.dark"
                      : params.value === "CANCELLED"
                        ? "primary.dark"
                        : "warning.dark",

                "& .MuiChip-icon": {
                  color:
                    params.value === "REJECTED"
                      ? "error.dark"
                      : params.value === "ACCEPTED"
                        ? "success.dark"
                        : params.value === "CANCELLED"
                          ? "primary.dark"
                          : "warning.dark",
                },
              }}
            />
          </Box>
        ),
      },
      {
        field: "action",
        headerName: "Action",
        flex: 0.6,
        minWidth: 150,
        headerAlign: "center",
        align: "center",
        filterable: false,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (params) => {
          return (
            <Stack
              direction="row"
              spacing={1}
              justifyContent="center"
              alignItems="center"
              height="100%"
            >
              {permissions.view && (
                <Tooltip title="View">
                  <IconButton
                    // color="primary"
                    onClick={() => handleViewClick(params.row)}
                  >
                    <VisibilityIcon />
                  </IconButton>
                </Tooltip>
              )}

              {params.row.reqStatus === "PENDING" && permissions.cancel && (
                <Tooltip title={"Cancel Request"}>
                  <IconButton
                    onClick={() => {
                      setConfirmDialog(true);
                      setRequestId(params.row.id);
                    }}
                  >
                    <CancelIcon fontSize="inherit" />
                  </IconButton>
                </Tooltip>
              )}
            </Stack>
          );
        },
      },
    ],
    [permissions.cancel, permissions.view],
  );

  const filteredColumns = useMemo(() => {
    if (permissions.view || permissions.cancel) {
      return columns;
    }
    // Otherwise, filter out the column where field name is 'action'.
    else {
      return columns.filter((column) => column.field !== "action");
    }
  }, [columns, permissions]);

  return (
    <>
      <Box>
        <Box>
          <DataGrid
            loading={isLoading}
            rows={cglList}
            columns={filteredColumns}
            getRowId={(row) => row.id}
            disableRowSelectionOnClick
            pageSizeOptions={[5, 10, 25, 50]}
            initialState={{
              pagination: { paginationModel: { pageSize: 10, page: 0 } },
              sorting: { sortModel: [{ field: "reqDate", sort: "desc" }] },
            }}
            slots={{
              noRowsOverlay: CustomNoRowsOverlay,
            }}
            sx={{
              minHeight: 760,
              width: "100%",
              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: "#f5f5f5 !important",
                fontWeight: 700,
                borderBottom: "2px solid rgba(88, 70, 159, 0.2)",
                position: "sticky",
                top: 0,
                zIndex: 1,
              },
            }}
          />
        </Box>
      </Box>

      {/* View Dialog */}
      <ViewMyRequestDialog
        open={viewOpen}
        handleClose={() => setViewOpen(false)}
        data={viewData}
      />

      {/* Template mapping of a request (compares with the current mapping while pending) */}
      <CglRequestMappingDialog
        open={!!mappingViewRow}
        onClose={() => setMappingViewRow(null)}
        request={mappingViewRow}
      />

      {/* Cancel Dialog */}
      <Dialog
        open={confirmDialog}
        // onClose={() => {
        //   setConfirmDialog(false);
        // }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ fontWeight: 600 }}>
          Cancel Request ID: {requestId}
        </DialogTitle>
        <DialogContent>
          <Typography sx={{ p: 1 }}>
            Are you sure you want to cancel this request, please confirm ?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setConfirmDialog(false);
            }}
            variant="outlined"
            sx={{
              "&:hover": {
                color: "#fff",
              },
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleCancelRequest}
            color="error"
            variant="contained"
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
