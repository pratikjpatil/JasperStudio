import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Alert, Box, Button, Chip, Skeleton, Stack, Typography } from "@mui/material";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import RefreshIcon from "@mui/icons-material/Refresh";
import useTemplateMappingApi from "./useTemplateMappingApi";
import { MAPPING_REPORTS, groupByReport, headLabel, mappingKey } from "./templateMappingConfig";

/** Read-only list of the Heads/Variables a CGL is mapped to (used in the CGL lookup screen). */
export default function TemplateMappingView({ cglNumber }) {
  const api = useTemplateMappingApi();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!cglNumber) return;
    try {
      setLoading(true);
      setError("");
      setItems(await api.fetchCglMappings(cglNumber));
    } catch (e) {
      setItems([]);
      setError(e?.message || "Could not load template mapping");
    } finally {
      setLoading(false);
    }
  }, [api, cglNumber]);

  useEffect(() => {
    load();
  }, [load]);

  const grouped = useMemo(() => groupByReport(items), [items]);

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1.5 }}>
        <AccountTreeIcon color="primary" fontSize="small" />
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Report Template Mapping
        </Typography>
        {!loading && !error && (
          <Typography variant="caption" color="text.secondary">
            {items.length} Head/Variable{items.length === 1 ? "" : "s"}
          </Typography>
        )}
      </Box>

      {loading ? (
        <Stack spacing={1}>
          <Skeleton variant="rounded" height={32} />
          <Skeleton variant="rounded" height={32} />
        </Stack>
      ) : error ? (
        <Alert severity="error" action={<Button color="inherit" size="small" startIcon={<RefreshIcon />} onClick={load}>Retry</Button>}>
          {error}
        </Alert>
      ) : items.length === 0 ? (
        <Alert severity="warning">This CGL is not mapped to any report Head or Variable.</Alert>
      ) : (
        <Stack spacing={1.5}>
          {MAPPING_REPORTS.filter((r) => grouped[r.id]?.length).map((r) => (
            <Box key={r.id}>
              <Chip size="small" label={`${r.label} · ${grouped[r.id].length}`} sx={{ bgcolor: r.color, color: "#fff", mb: 0.75 }} />
              <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap">
                {grouped[r.id].map((m) => (
                  <Chip
                    key={mappingKey(m)}
                    size="small"
                    variant="outlined"
                    label={`${headLabel(m)}${m.columnName ? ` [${m.columnName}]` : ""} / ${m.variableName || "cell"}`}
                  />
                ))}
              </Stack>
            </Box>
          ))}
        </Stack>
      )}
    </Box>
  );
}
