import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Radio,
  RadioGroup,
  Skeleton,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import useTemplateMappingApi from "./useTemplateMappingApi";
import { groupByReport, headLabel, mappingKey, reportMeta } from "./templateMappingConfig";

/**
 * Copy the Head/Variable mapping of an existing CGL (the "source") into the CGL being created or edited.
 * The source's current mappings are read live from the templates, previewed, and the user can untick items.
 */
export default function CopyMappingDialog({ open, onClose, currentCgl = "", selected = [], onApply }) {
  const api = useTemplateMappingApi();

  const [input, setInput] = useState("");
  const [options, setOptions] = useState([]);
  const [searching, setSearching] = useState(false);
  const [source, setSource] = useState(null);
  const [items, setItems] = useState([]);
  const [loadingItems, setLoadingItems] = useState(false);
  const [error, setError] = useState("");
  const [checked, setChecked] = useState(new Set());
  const [mode, setMode] = useState("merge");

  useEffect(() => {
    if (!open) return;
    setInput("");
    setOptions([]);
    setSource(null);
    setItems([]);
    setChecked(new Set());
    setError("");
    setMode("merge");
  }, [open]);

  // debounced CGL search (>= 3 characters, same rule as the CGL lookup screen)
  useEffect(() => {
    const text = input.trim();
    if (!open || text.length < 3 || (source && `${source.cglNumber} - ${source.description}` === input)) {
      if (text.length < 3) setOptions([]);
      return undefined;
    }
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        setSearching(true);
        const list = await api.searchCgls(text);
        if (!cancelled) setOptions(list.filter((c) => String(c.cglNumber) !== String(currentCgl)));
      } catch (e) {
        if (!cancelled) setOptions([]);
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 400);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [input, open, api, currentCgl, source]);

  const handleSourceChange = async (_, value) => {
    setSource(value);
    setItems([]);
    setChecked(new Set());
    setError("");
    if (!value) return;
    try {
      setLoadingItems(true);
      const list = await api.fetchCglMappings(value.cglNumber);
      setItems(list);
      setChecked(new Set(list.map(mappingKey)));
    } catch (e) {
      setError(e?.message || "Could not read the mapping of this CGL");
    } finally {
      setLoadingItems(false);
    }
  };

  const grouped = useMemo(() => groupByReport(items), [items]);
  const selectedKeys = useMemo(() => new Set(selected.map(mappingKey)), [selected]);

  const toggle = (key) =>
    setChecked((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });

  const toggleReport = (reportId, on) =>
    setChecked((prev) => {
      const next = new Set(prev);
      grouped[reportId].forEach((m) => (on ? next.add(mappingKey(m)) : next.delete(mappingKey(m))));
      return next;
    });

  const chosen = items.filter((m) => checked.has(mappingKey(m)));
  const newOnes = chosen.filter((m) => mode === "replace" || !selectedKeys.has(mappingKey(m)));

  const apply = () =>
    onApply(
      chosen.map((m) => ({ ...m, _origin: { type: "COPY", cgl: source.cglNumber } })),
      { mode, fromCgl: source.cglNumber, added: newOnes.length },
    );

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle sx={{ pb: 1 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Box>
            <Typography variant="h6" color="primary">
              Copy mapping from another CGL
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Reuse the Heads and Variables an existing CGL is already mapped to.
            </Typography>
          </Box>
          <IconButton onClick={onClose} aria-label="close">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      <Divider />

      <DialogContent sx={{ minHeight: 360 }}>
        <Autocomplete
          fullWidth
          autoHighlight
          value={source}
          options={options}
          loading={searching}
          filterOptions={(x) => x}
          inputValue={input}
          onInputChange={(_, v) => setInput(v)}
          onChange={handleSourceChange}
          isOptionEqualToValue={(o, v) => o.cglNumber === v.cglNumber}
          getOptionLabel={(o) => (o ? `${o.cglNumber} - ${o.description}` : "")}
          noOptionsText={input.trim().length < 3 ? "Type at least 3 characters..." : "No CGLs found"}
          renderInput={(params) => (
            <TextField
              {...params}
              autoFocus
              label="Source CGL (number or description)"
              placeholder="e.g. 1234567890 or Savings Account"
              slotProps={{
                input: {
                  ...params.InputProps,
                  endAdornment: (
                    <>
                      {searching && <CircularProgress size={18} />}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                },
              }}
            />
          )}
        />

        {!source && (
          <Stack alignItems="center" spacing={1} sx={{ mt: 6, color: "text.secondary" }}>
            <ContentCopyIcon fontSize="large" />
            <Typography variant="body2" textAlign="center">
              Search for the CGL whose mapping you want to copy. You will see its Heads and Variables before anything is
              added.
            </Typography>
          </Stack>
        )}

        {source && loadingItems && (
          <Stack spacing={1} sx={{ mt: 3 }}>
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} variant="rounded" height={40} />
            ))}
          </Stack>
        )}

        {source && error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}

        {source && !loadingItems && !error && items.length === 0 && (
          <Alert severity="info" sx={{ mt: 2 }}>
            CGL {source.cglNumber} is not mapped to any Head or Variable yet, so there is nothing to copy.
          </Alert>
        )}

        {source && !loadingItems && items.length > 0 && (
          <Box sx={{ mt: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1, flexWrap: "wrap" }}>
              <Typography variant="subtitle2">
                {source.cglNumber} - {source.description}
              </Typography>
              <Chip
                size="small"
                variant="outlined"
                color={String(source.cglStatus ?? source.status) === "1" ? "success" : "default"}
                label={String(source.cglStatus ?? source.status) === "1" ? "Active" : "Inactive"}
              />
              <Typography variant="caption" color="text.secondary">
                {items.length} mapping{items.length > 1 ? "s" : ""} found
              </Typography>
            </Box>

            <Box sx={{ maxHeight: 300, overflow: "auto", border: 1, borderColor: "divider", borderRadius: 1 }}>
              {Object.keys(grouped)
                .filter((id) => grouped[id].length > 0)
                .map((id) => {
                  const meta = reportMeta(id);
                  const all = grouped[id].every((m) => checked.has(mappingKey(m)));
                  const some = grouped[id].some((m) => checked.has(mappingKey(m)));
                  return (
                    <Box key={id}>
                      <Box sx={{ display: "flex", alignItems: "center", px: 1.5, py: 0.5, bgcolor: "action.hover" }}>
                        <Checkbox
                          size="small"
                          checked={all}
                          indeterminate={!all && some}
                          onChange={(e) => toggleReport(id, e.target.checked)}
                        />
                        <Chip size="small" label={meta.label} sx={{ bgcolor: meta.color, color: "#fff", mr: 1 }} />
                        <Typography variant="caption" color="text.secondary">
                          {grouped[id].length} Head/Variable
                        </Typography>
                      </Box>
                      <List dense disablePadding>
                        {grouped[id].map((m) => {
                          const k = mappingKey(m);
                          return (
                            <ListItem key={k} disableGutters sx={{ pl: 1.5, pr: 2, cursor: "pointer" }} onClick={() => toggle(k)}>
                              <ListItemIcon sx={{ minWidth: 36 }}>
                                <Checkbox
                                  size="small"
                                  edge="start"
                                  checked={checked.has(k)}
                                  onClick={(e) => e.stopPropagation()}
                                  onChange={() => toggle(k)}
                                />
                              </ListItemIcon>
                              <ListItemText
                                primary={`${m.codeText ? m.codeText + " · " : ""}${headLabel(m)}${m.subHeadText ? " › " + m.subHeadText : ""}`}
                                secondary={`${m.columnName ? "Column " + m.columnName + " · " : ""}Variable ${m.variableName || "(cell)"}${m.otherFilters ? " · " + m.otherFilters : ""}`}
                              />
                              {selectedKeys.has(k) && <Chip size="small" variant="outlined" label="Already added" />}
                            </ListItem>
                          );
                        })}
                      </List>
                    </Box>
                  );
                })}
            </Box>

            {selected.length > 0 && (
              <FormControl sx={{ mt: 1.5 }}>
                <RadioGroup row value={mode} onChange={(e) => setMode(e.target.value)}>
                  <FormControlLabel value="merge" control={<Radio size="small" />} label="Add to my current selection" />
                  <FormControlLabel value="replace" control={<Radio size="small" />} label="Replace my current selection" />
                </RadioGroup>
              </FormControl>
            )}
          </Box>
        )}
      </DialogContent>

      <Divider />
      <DialogActions sx={{ px: 3, py: 1.5 }}>
        <Button onClick={onClose} variant="outlined" sx={{ "&:hover": { color: "#fff" } }}>
          Cancel
        </Button>
        <Button variant="contained" startIcon={<ContentCopyIcon />} disabled={chosen.length === 0 || (mode === "merge" && newOnes.length === 0)} onClick={apply}>
          {chosen.length === 0
            ? "Copy"
            : mode === "replace"
              ? `Replace with ${chosen.length}`
              : newOnes.length === 0
                ? "Already added"
                : `Copy ${newOnes.length} mapping${newOnes.length > 1 ? "s" : ""}`}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
