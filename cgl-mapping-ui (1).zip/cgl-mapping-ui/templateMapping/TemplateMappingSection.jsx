import React, { useMemo, useState } from "react";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  Card,
  Chip,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Skeleton,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import PlaylistAddCheckIcon from "@mui/icons-material/PlaylistAddCheck";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import RefreshIcon from "@mui/icons-material/Refresh";
import LinkOffIcon from "@mui/icons-material/LinkOff";
import useCustomSnackbar from "../../../utils/useCustomSnackbar";
import MappingPickerDialog from "./MappingPickerDialog";
import CopyMappingDialog from "./CopyMappingDialog";
import { MAPPING_REPORTS, groupByReport, headLabel, mappingKey, reportMeta } from "./templateMappingConfig";

/**
 * "Report Template Mapping" block of the CGL form.
 * Pure UI: the parent owns the `mappings` array (list of picker targets) and receives every change via onChange.
 */
export default function TemplateMappingSection({
  cglNumber = "",
  mappings,
  onChange,
  loading = false,
  error = "",
  onRetry,
  required = false,
}) {
  const snackbar = useCustomSnackbar();
  const [pickerOpen, setPickerOpen] = useState(false);
  const [copyOpen, setCopyOpen] = useState(false);

  const grouped = useMemo(() => groupByReport(mappings), [mappings]);
  const usedReports = MAPPING_REPORTS.filter((r) => grouped[r.id]?.length > 0);
  const locked = loading || !!error;

  const remove = (key) => onChange(mappings.filter((m) => mappingKey(m) !== key));

  const handleCopy = (items, { mode, fromCgl, added }) => {
    if (mode === "replace") {
      onChange(items);
    } else {
      const have = new Set(mappings.map(mappingKey));
      onChange([...mappings, ...items.filter((m) => !have.has(mappingKey(m)))]);
    }
    setCopyOpen(false);
    snackbar(`Copied ${added} mapping${added > 1 ? "s" : ""} from CGL ${fromCgl}. Review and save the request.`, "success");
  };

  // same CGL under several Heads of one report is allowed, but worth a visible heads-up
  const multiHead = usedReports.filter((r) => new Set(grouped[r.id].map((m) => m.rowId)).size > 1);

  return (
    <Card variant="outlined" sx={{ p: 2 }}>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: "wrap", mb: 1 }}>
        <AccountTreeIcon color="primary" />
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          Report Template Mapping
        </Typography>
        <Chip
          size="small"
          label={required ? "Required" : "Optional"}
          color={required && mappings.length === 0 ? "warning" : "default"}
          variant="outlined"
        />
        <Box sx={{ flex: 1 }} />
        {MAPPING_REPORTS.map((r) => (
          <Chip
            key={r.id}
            size="small"
            label={`${r.label} ${grouped[r.id]?.length || 0}`}
            variant={grouped[r.id]?.length ? "filled" : "outlined"}
            sx={grouped[r.id]?.length ? { bgcolor: r.color, color: "#fff" } : undefined}
          />
        ))}
      </Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
        Choose the Heads and Variables of NWSA, YSA, PNL and PFORM this CGL belongs to. On approval the CGL is added to those
        report templates.
      </Typography>

      <Stack direction="row" spacing={1} sx={{ mb: 1.5, flexWrap: "wrap" }} useFlexGap>
        <Button variant="contained" size="small" startIcon={<PlaylistAddCheckIcon />} disabled={locked} onClick={() => setPickerOpen(true)}>
          Select Heads &amp; Variables
        </Button>
        <Button variant="outlined" size="small" startIcon={<ContentCopyIcon />} disabled={locked} onClick={() => setCopyOpen(true)} sx={{ "&:hover": { color: "#fff" } }}>
          Copy from another CGL
        </Button>
        {mappings.length > 0 && !locked && (
          <Button size="small" color="inherit" onClick={() => onChange([])}>
            Clear all
          </Button>
        )}
      </Stack>

      {error && (
        <Alert
          severity="error"
          sx={{ mb: 1 }}
          action={
            <Button color="inherit" size="small" startIcon={<RefreshIcon />} onClick={onRetry}>
              Retry
            </Button>
          }
        >
          Could not load the current mapping of this CGL. {error}
        </Alert>
      )}

      {loading ? (
        <Stack spacing={1}>
          <Skeleton variant="rounded" height={36} />
          <Skeleton variant="rounded" height={36} />
        </Stack>
      ) : mappings.length === 0 && !error ? (
        <Stack alignItems="center" spacing={0.5} sx={{ py: 3, color: required ? "warning.main" : "text.secondary" }}>
          <LinkOffIcon />
          <Typography variant="body2" textAlign="center">
            {required
              ? "No mapping yet. Select Heads & Variables or copy them from an existing CGL to continue."
              : "No mapping yet."}
          </Typography>
        </Stack>
      ) : (
        <Box sx={{ maxHeight: 300, overflow: "auto" }}>
          {usedReports.map((r) => (
            <Accordion key={r.id} defaultExpanded disableGutters variant="outlined" sx={{ "&:before": { display: "none" } }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 40, "& .MuiAccordionSummary-content": { alignItems: "center", gap: 1 } }}>
                <Chip size="small" label={r.label} sx={{ bgcolor: r.color, color: "#fff" }} />
                <Typography variant="body2" color="text.secondary">
                  {r.description} · {grouped[r.id].length} selected
                </Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ p: 0 }}>
                <List dense disablePadding>
                  {grouped[r.id].map((m) => (
                    <ListItem
                      key={mappingKey(m)}
                      divider
                      secondaryAction={
                        <Tooltip title="Remove">
                          <IconButton edge="end" size="small" onClick={() => remove(mappingKey(m))} aria-label="remove mapping">
                            <DeleteOutlineIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      }
                    >
                      <ListItemText
                        primary={
                          <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, flexWrap: "wrap" }}>
                            <span>
                              {m.codeText ? `${m.codeText} · ` : ""}
                              {headLabel(m)}
                              {m.subHeadText ? ` › ${m.subHeadText}` : ""}
                            </span>
                            {m._origin?.type === "COPY" && (
                              <Chip size="small" variant="outlined" color="info" label={`Copied from ${m._origin.cgl}`} />
                            )}
                          </Box>
                        }
                        secondary={`${m.columnName ? `Column ${m.columnName} · ` : ""}Variable ${m.variableName || "(cell)"}${m.otherFilters ? ` · ${m.otherFilters}` : ""}`}
                      />
                    </ListItem>
                  ))}
                </List>
              </AccordionDetails>
            </Accordion>
          ))}
        </Box>
      )}

      {multiHead.length > 0 && (
        <Alert severity="info" sx={{ mt: 1 }}>
          Mapped to more than one Head in {multiHead.map((r) => r.label).join(", ")}. That is allowed, just make sure the
          amounts are not meant to be counted once.
        </Alert>
      )}

      <MappingPickerDialog
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        selected={mappings}
        onApply={(list) => {
          onChange(list);
          setPickerOpen(false);
        }}
      />
      <CopyMappingDialog
        open={copyOpen}
        onClose={() => setCopyOpen(false)}
        currentCgl={cglNumber}
        selected={mappings}
        onApply={handleCopy}
      />
    </Card>
  );
}
