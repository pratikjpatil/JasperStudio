import React, { useEffect, useMemo, useState } from "react";
import { Alert, Box, Chip, Skeleton, Stack, Typography } from "@mui/material";
import useTemplateMappingApi from "./useTemplateMappingApi";
import { MAPPING_REPORTS, mappingKey } from "./templateMappingConfig";

const STATUS_CHIP = {
  added: { label: "New", color: "success" },
  removed: { label: "Removed", color: "error" },
  same: { label: "No change", color: "default" },
};

const lineOf = (m) => {
  const head = m.headText || m.codeText;
  if (!head) return `Row ${m.rowId}`;
  return `${m.codeText && m.headText ? m.codeText + " · " : ""}${m.headText || m.codeText}${m.subHeadText ? " › " + m.subHeadText : ""}`;
};

const detailOf = (m) =>
  `${m.columnName ? "Column " + m.columnName + " · " : ""}Variable ${m.variableName || "(cell)"}${m.otherFilters ? " · " + m.otherFilters : ""}`;

/**
 * Template mapping carried by a CGL request, for the maker's "My Requests" and the checker's approval screen.
 *  - PENDING UPDATE : compared with what the CGL is mapped to today (New / Removed / No change)
 *  - PENDING ADD    : everything is new
 *  - other statuses : the mapping that was requested
 * Head names are taken from the request when stored, otherwise looked up in the current templates.
 */
export default function CglRequestMappingPanel({
  cglNumber,
  changeType,
  reqStatus,
  mappings,
  executionRemarks,
}) {
  const api = useTemplateMappingApi();
  const [current, setCurrent] = useState([]);
  const [compareState, setCompareState] = useState("idle"); // idle | loading | ready | error
  const [lookup, setLookup] = useState({});

  const isBlockType = changeType === "BLOCK" || changeType === "UNBLOCK";
  const requested = useMemo(() => (Array.isArray(mappings) ? mappings : []), [mappings]);
  const pending = reqStatus === "PENDING";
  const compare = pending && changeType === "UPDATE" && !!cglNumber;

  // current mapping of the CGL (pending updates only)
  useEffect(() => {
    if (!compare) {
      setCurrent([]);
      setCompareState("idle");
      return undefined;
    }
    let cancelled = false;
    setCompareState("loading");
    api
      .fetchCglMappings(cglNumber)
      .then((list) => {
        if (cancelled) return;
        setCurrent(list);
        setCompareState("ready");
      })
      .catch(() => !cancelled && setCompareState("error"));
    return () => {
      cancelled = true;
    };
  }, [compare, cglNumber, api]);

  // fill in head names when the stored request only has ids
  const needsNames = requested.some((m) => !m.headText && !m.codeText);
  useEffect(() => {
    if (!needsNames) return undefined;
    let cancelled = false;
    const reports = Array.from(new Set(requested.map((m) => m.reportId)));
    Promise.allSettled(reports.map((id) => api.fetchTargets(id))).then((results) => {
      if (cancelled) return;
      const map = {};
      results.forEach((r) => r.status === "fulfilled" && r.value.forEach((t) => (map[mappingKey(t)] = t)));
      setLookup(map);
    });
    return () => {
      cancelled = true;
    };
  }, [needsNames, requested, api]);

  const rows = useMemo(() => {
    const fill = (m) => (m.headText || m.codeText ? m : { ...m, ...(lookup[mappingKey(m)] || {}) });
    const currentKeys = new Set(current.map(mappingKey));
    const requestedKeys = new Set(requested.map(mappingKey));
    const list = requested.map((m) => ({
      ...fill(m),
      status: compare && compareState === "ready" ? (currentKeys.has(mappingKey(m)) ? "same" : "added") : pending && changeType === "ADD" ? "added" : null,
    }));
    if (compare && compareState === "ready") {
      current.filter((c) => !requestedKeys.has(mappingKey(c))).forEach((c) => list.push({ ...c, status: "removed" }));
    }
    return list;
  }, [requested, current, lookup, compare, compareState, pending, changeType]);

  const counts = rows.reduce((acc, r) => ({ ...acc, [r.status || "plain"]: (acc[r.status || "plain"] || 0) + 1 }), {});

  if (isBlockType) {
    return <Alert severity="info">Block / unblock requests do not change the template mapping.</Alert>;
  }
  if (!Array.isArray(mappings)) {
    return <Alert severity="info">This request did not include a template mapping (the existing mapping is left as it is).</Alert>;
  }

  return (
    <Box>
      <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap" alignItems="center" sx={{ mb: 1.5 }}>
        <Typography variant="subtitle2">
          {requested.length} Head/Variable{requested.length === 1 ? "" : "s"} requested
        </Typography>
        {counts.added > 0 && <Chip size="small" color="success" variant="outlined" label={`${counts.added} new`} />}
        {counts.removed > 0 && <Chip size="small" color="error" variant="outlined" label={`${counts.removed} removed`} />}
        {counts.same > 0 && <Chip size="small" variant="outlined" label={`${counts.same} unchanged`} />}
      </Stack>

      {compare && compareState === "loading" && <Skeleton variant="rounded" height={28} sx={{ mb: 1 }} />}
      {compare && compareState === "error" && (
        <Alert severity="warning" sx={{ mb: 1 }}>
          Could not load the current mapping to compare with, so the requested mapping is shown as is.
        </Alert>
      )}
      {requested.length === 0 && rows.length === 0 && (
        <Alert severity="warning">The request asks for no Head / Variable mapping.</Alert>
      )}
      {reqStatus === "ACCEPTED" && executionRemarks && String(executionRemarks).includes("Template mappings") && (
        <Alert severity="success" sx={{ mb: 1 }}>
          {executionRemarks}
        </Alert>
      )}

      {MAPPING_REPORTS.filter((r) => rows.some((x) => x.reportId === r.id)).map((r) => (
        <Box key={r.id} sx={{ mb: 1.5 }}>
          <Chip size="small" label={`${r.label} · ${rows.filter((x) => x.reportId === r.id).length}`} sx={{ bgcolor: r.color, color: "#fff", mb: 0.5 }} />
          <Box sx={{ border: 1, borderColor: "divider", borderRadius: 1 }}>
            {rows
              .filter((x) => x.reportId === r.id)
              .map((m, i, arr) => (
                <Box
                  key={mappingKey(m) + m.status}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                    px: 1.5,
                    py: 0.75,
                    borderBottom: i === arr.length - 1 ? 0 : 1,
                    borderColor: "divider",
                    opacity: m.status === "removed" ? 0.75 : 1,
                  }}
                >
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" sx={{ textDecoration: m.status === "removed" ? "line-through" : "none" }}>
                      {lineOf(m)}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {detailOf(m)}
                    </Typography>
                  </Box>
                  {m.status && STATUS_CHIP[m.status] && (
                    <Chip size="small" variant="outlined" color={STATUS_CHIP[m.status].color} label={STATUS_CHIP[m.status].label} />
                  )}
                </Box>
              ))}
          </Box>
        </Box>
      ))}
    </Box>
  );
}
