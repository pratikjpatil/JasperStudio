import { useCallback, useMemo } from "react";
import useApi from "../../../hooks/useApi";
import {
  CGL_SEARCH_ENDPOINT,
  TEMPLATE_MAPPING_API_BASE,
  unwrapList,
} from "./templateMappingConfig";

/**
 * All calls of the mapping feature.
 *  - targets / by-cgl come from the Template Configuration Service (it owns the template JSON)
 *  - CGL search reuses the existing common-master lookup
 */
export default function useTemplateMappingApi() {
  const { callApi } = useApi();

  /** Eligible Head/Variable targets of the active template of one report. */
  const fetchTargets = useCallback(
    async (reportId) =>
      unwrapList(await callApi(`${TEMPLATE_MAPPING_API_BASE}/targets`, { reportId }, "GET")),
    [callApi],
  );

  /** Current mappings of a CGL across all reports. */
  const fetchCglMappings = useCallback(
    async (cglNumber) =>
      unwrapList(
        await callApi(
          `${TEMPLATE_MAPPING_API_BASE}/by-cgl/${encodeURIComponent(cglNumber)}`,
          {},
          "GET",
        ),
      ),
    [callApi],
  );

  /** Search CGLs by number or description (min 3 characters, enforced by callers). */
  const searchCgls = useCallback(async (text) => {
    const res = await callApi(CGL_SEARCH_ENDPOINT, { cglCodeOrDesc: text }, "GET");
    return res?.data?.data || [];
  }, [callApi]);

  return useMemo(
    () => ({ fetchTargets, fetchCglMappings, searchCgls }),
    [fetchTargets, fetchCglMappings, searchCgls],
  );
}
