import React from "react";
import { Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Divider, IconButton, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import CglRequestMappingPanel from "./CglRequestMappingPanel";

/** Dialog around CglRequestMappingPanel for a row of the My Requests grid. */
export default function CglRequestMappingDialog({ open, onClose, request }) {
  if (!request) return null;
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle sx={{ pb: 1 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Box>
            <Typography variant="h6" color="primary">
              Template mapping · Request {request.id}
            </Typography>
            <Box sx={{ display: "flex", gap: 1, alignItems: "center", mt: 0.5 }}>
              <Typography variant="body2" color="text.secondary">
                CGL {request.cglNumber}
              </Typography>
              <Chip size="small" variant="outlined" label={request.changeType} />
              <Chip size="small" variant="outlined" label={request.reqStatus} />
            </Box>
          </Box>
          <IconButton onClick={onClose} aria-label="close">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      <Divider />
      <DialogContent sx={{ minHeight: 220 }}>
        <CglRequestMappingPanel
          cglNumber={request.cglNumber}
          changeType={request.changeType}
          reqStatus={request.reqStatus}
          mappings={request.templateMappings}
          executionRemarks={request.executionRemarks}
        />
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 1.5 }}>
        <Button onClick={onClose} variant="outlined" sx={{ "&:hover": { color: "#fff" } }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
