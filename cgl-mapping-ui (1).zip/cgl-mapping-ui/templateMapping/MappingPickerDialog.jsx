import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Badge,
  Box,
  Button,
  Checkbox,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControlLabel,
  IconButton,
  InputAdornment,
  MenuItem,
  Skeleton,
  Stack,
  Switch,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import RefreshIcon from "@mui/icons-material/Refresh";
import SearchOffIcon from "@mui/icons-material/SearchOff";
import useTemplateMappingApi from "./useTemplateMappingApi";
import { MAPPING_REPORTS, headLabel, mappingKey } from "./templateMappingConfig";

const ROWS_PER_PAGE = 25;

const haystack = (r) =>
  [r.headText, r.subHeadText, r.codeText, r.variableName, r.columnName, r.otherFilters]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

/**
 * Pick Heads + Variables from the 4 report templates.
 * Targets of a report are loaded the first time its tab is opened and filtered in the browser.
 * Nothing is applied to the CGL until the user presses "Apply".
 */
export default function MappingPickerDialog({ open, onClose, selected = [], onApply }) {
  const api = useTemplateMappingApi();

  const [tab, setTab] = useState(0);
  const [draft, setDraft] = useState(() => new Map());
  const [store, setStore] = useState({});
  const [search, setSearch] = useState("");
  const [column, setColumn] = useState("ALL");
  const [onlySelected, setOnlySelected] = useState(false);
  const [page, setPage] = useState(0);
  const inFlight = useRef(new Set());

  const reportId = MAPPING_REPORTS[tab].id;

  // fresh draft every time the dialog opens
  useEffect(() => {
    if (!open) return;
    setDraft(new Map(selected.map((m) => [mappingKey(m), m])));
    setStore({});
    setTab(0);
    setSearch("");
    setColumn("ALL");
    setOnlySelected(false);
    setPage(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const loadReport = useCallback(
    async (id) => {
      if (inFlight.current.has(id)) return;
      inFlight.current.add(id);
      setStore((p) => ({ ...p, [id]: { status: "loading", rows: [] } }));
      try {
        const rows = await api.fetchTargets(id);
        setStore((p) => ({ ...p, [id]: { status: "ready", rows } }));
      } catch (e) {
        setStore((p) => ({
          ...p,
          [id]: { status: "error", rows: [], error: e?.message || "Could not load this report" },
        }));
      } finally {
        inFlight.current.delete(id);
      }
    },
    [api],
  );

  // lazy load the active tab
  useEffect(() => {
    if (open && !store[reportId]) loadReport(reportId);
  }, [open, reportId, store, loadReport]);

  const current = store[reportId];
  const rows = current?.rows || [];

  const columns = useMemo(
    () => Array.from(new Set(rows.map((r) => r.columnName).filter(Boolean))),
    [rows],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = onlySelected
      ? Array.from(draft.values()).filter((d) => d.reportId === reportId)
      : rows;
    if (column !== "ALL") list = list.filter((r) => r.columnName === column);
    if (q) list = list.filter((r) => haystack(r).includes(q));
    return list;
  }, [rows, draft, search, column, onlySelected, reportId]);

  useEffect(() => setPage(0), [reportId, search, column, onlySelected]);

  const pageRows = filtered.slice(page * ROWS_PER_PAGE, page * ROWS_PER_PAGE + ROWS_PER_PAGE);

  const toggle = (row) =>
    setDraft((prev) => {
      const next = new Map(prev);
      const k = mappingKey(row);
      if (next.has(k)) next.delete(k);
      else next.set(k, { ...row });
      return next;
    });

  const countFor = (id) => Array.from(draft.values()).filter((d) => d.reportId === id).length;
  const reportsUsed = MAPPING_REPORTS.filter((r) => countFor(r.id) > 0).length;

  const clearReport = () =>
    setDraft((prev) => {
      const next = new Map(prev);
      Array.from(next.entries()).forEach(([k, v]) => v.reportId === reportId && next.delete(k));
      return next;
    });

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="lg" slotProps={{ paper: { sx: { height: "82vh" } } }}>
      <DialogTitle sx={{ pb: 1 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Box>
            <Typography variant="h6" color="primary">
              Select Heads &amp; Variables
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Tick every Head / Variable this CGL should be added to. You can use several reports.
            </Typography>
          </Box>
          <IconButton onClick={onClose} aria-label="close">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>

      <Tabs
        value={tab}
        onChange={(_, v) => {
          setTab(v);
          setColumn("ALL");
        }}
        variant="fullWidth"
        sx={{ borderBottom: 1, borderColor: "divider" }}
      >
        {MAPPING_REPORTS.map((r) => (
          <Tab
            key={r.id}
            label={
              <Badge color="primary" badgeContent={countFor(r.id)} sx={{ "& .MuiBadge-badge": { right: -14, top: 4 } }}>
                <span style={{ paddingRight: 8 }}>{r.label}</span>
              </Badge>
            }
          />
        ))}
      </Tabs>

      <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 2, overflow: "hidden" }}>
        <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} alignItems={{ md: "center" }}>
          <TextField
            size="small"
            autoFocus
            fullWidth
            placeholder="Search by code, head, sub head, column or variable"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            slotProps={{
              input: {
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" />
                  </InputAdornment>
                ),
              },
            }}
          />
          {columns.length > 1 && (
            <TextField
              select
              size="small"
              label="Column"
              value={column}
              onChange={(e) => setColumn(e.target.value)}
              sx={{ minWidth: 180 }}
            >
              <MenuItem value="ALL">All columns</MenuItem>
              {columns.map((c) => (
                <MenuItem key={c} value={c}>
                  {c}
                </MenuItem>
              ))}
            </TextField>
          )}
          <FormControlLabel
            sx={{ whiteSpace: "nowrap", m: 0 }}
            control={<Switch size="small" checked={onlySelected} onChange={(e) => setOnlySelected(e.target.checked)} />}
            label="Selected only"
          />
          <Button size="small" color="inherit" disabled={countFor(reportId) === 0} onClick={clearReport}>
            Clear {MAPPING_REPORTS[tab].label}
          </Button>
        </Stack>

        {columns.length > 1 && (
          <Alert severity="info" icon={false} sx={{ py: 0 }}>
            This report has {columns.length} value columns ({columns.join(", ")}). Each Head appears once per column, so to
            move a CGL to another Head, untick the old row and tick the new one.
          </Alert>
        )}

        <Box sx={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
          {current?.status === "error" ? (
            <Stack alignItems="center" justifyContent="center" spacing={1.5} sx={{ flex: 1 }}>
              <Alert severity="error">{current.error}</Alert>
              <Button startIcon={<RefreshIcon />} onClick={() => loadReport(reportId)}>
                Retry
              </Button>
            </Stack>
          ) : !current || current.status === "loading" ? (
            <Stack spacing={1} sx={{ p: 1 }}>
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} variant="rounded" height={38} />
              ))}
            </Stack>
          ) : filtered.length === 0 ? (
            <Stack alignItems="center" justifyContent="center" spacing={1} sx={{ flex: 1, color: "text.secondary" }}>
              <SearchOffIcon fontSize="large" />
              <Typography>
                {rows.length === 0
                  ? "This report has no Heads with a database variable."
                  : "Nothing matches your search or filters."}
              </Typography>
            </Stack>
          ) : (
            <>
              <TableContainer sx={{ flex: 1, border: 1, borderColor: "divider", borderRadius: 1 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell padding="checkbox" />
                      <TableCell sx={{ width: 110 }}>Code</TableCell>
                      <TableCell>Head / Sub head</TableCell>
                      <TableCell sx={{ width: 150 }}>Column</TableCell>
                      <TableCell sx={{ width: 160 }}>Variable</TableCell>
                      <TableCell sx={{ width: 220 }}>Details</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {pageRows.map((r) => {
                      const checked = draft.has(mappingKey(r));
                      return (
                        <TableRow
                          key={mappingKey(r)}
                          hover
                          selected={checked}
                          onClick={() => toggle(r)}
                          sx={{ cursor: "pointer" }}
                        >
                          <TableCell padding="checkbox">
                            <Checkbox
                              size="small"
                              checked={checked}
                              onClick={(e) => e.stopPropagation()}
                              onChange={() => toggle(r)}
                              slotProps={{ input: { "aria-label": `Select ${headLabel(r)}` } }}
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ fontFamily: "monospace" }}>
                              {r.codeText || "-"}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ fontWeight: 500 }}>
                              {r.headText || "-"}
                            </Typography>
                            {r.subHeadText && (
                              <Typography variant="caption" color="text.secondary">
                                {r.subHeadText}
                              </Typography>
                            )}
                          </TableCell>
                          <TableCell>{r.columnName ? <Chip size="small" variant="outlined" label={r.columnName} /> : "-"}</TableCell>
                          <TableCell>
                            <Typography variant="body2">{r.variableName || "(cell)"}</Typography>
                            <Typography variant="caption" color="text.secondary">
                              {r.variableType}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                              {r.otherFilters && <Chip size="small" color="info" variant="outlined" label={r.otherFilters} />}
                              <Typography variant="caption" color="text.secondary" sx={{ alignSelf: "center" }}>
                                {r.cglCount} CGL{r.cglCount === 1 ? "" : "s"} mapped
                              </Typography>
                            </Stack>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                component="div"
                count={filtered.length}
                page={page}
                onPageChange={(_, p) => setPage(p)}
                rowsPerPage={ROWS_PER_PAGE}
                rowsPerPageOptions={[ROWS_PER_PAGE]}
              />
            </>
          )}
        </Box>
      </DialogContent>

      <Divider />
      <DialogActions sx={{ px: 3, py: 1.5, justifyContent: "space-between" }}>
        <Typography variant="body2" color="text.secondary">
          {draft.size === 0
            ? "Nothing selected yet"
            : `${draft.size} selected in ${reportsUsed} report${reportsUsed > 1 ? "s" : ""}`}
        </Typography>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Button onClick={onClose} variant="outlined" sx={{ "&:hover": { color: "#fff" } }}>
            Cancel
          </Button>
          <Button variant="contained" onClick={() => onApply(Array.from(draft.values()))}>
            Apply selection
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
}
