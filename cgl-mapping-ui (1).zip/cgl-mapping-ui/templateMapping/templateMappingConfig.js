/**
 * CGL -> report template (Head / Variable) mapping: shared constants and helpers.
 * Everything that may differ per environment lives at the top of this file.
 */

/** Master switch. false = the CGL screens behave exactly as before. */
export const TEMPLATE_MAPPING_ENABLED = true;

/**
 * true = a CGL cannot be created / updated without at least one mapping.
 * Keep it equal to `cgl.mapping.enforced` on the Common Request Service.
 */
export const TEMPLATE_MAPPING_REQUIRED = true;

/** Account classifications that do not need a mapping, e.g. ["M"] if Memo CGLs are exempt. */
export const MAPPING_OPTIONAL_CLASSIFICATIONS = [];

/**
 * Gateway prefix that routes to the Template Configuration Service.
 * Same idea as "/CM" (common master) and "/CR" (common request); adjust to your gateway.
 */
export const TEMPLATE_MAPPING_API_BASE = "/TC/template-config/cgl-mappings";

/** Existing common-master endpoint used by the CGL lookup screen (search by number or description). */
export const CGL_SEARCH_ENDPOINT = "/CM/common-master/view-cgl";

export const MAPPING_REPORTS = [
  { id: "NWSA", label: "NWSA", description: "Weekly Statement of Affairs", color: "#1565c0" },
  { id: "YSA", label: "YSA", description: "YSA Statement", color: "#6a1b9a" },
  { id: "PNL", label: "PNL", description: "Profit & Loss", color: "#2e7d32" },
  { id: "PFORM", label: "PFORM", description: "P-Form", color: "#ef6c00" },
];

export const reportMeta = (id) =>
  MAPPING_REPORTS.find((r) => r.id === id) || { id, label: id, description: id, color: "#546e7a" };

/** Identity of one Head + Variable (same rule as the backend). */
export const mappingKey = (m) =>
  [m.reportId, m.rowId, m.cellId, m.variableName || ""].join("|");

/** Only what the backend needs, plus display fields (ignored by the backend if it does not store them). */
export const toPayloadMapping = (m) => ({
  reportId: m.reportId,
  rowId: m.rowId,
  cellId: m.cellId,
  variableName: m.variableName || "",
  baseVersion: m.baseVersion ?? null,
  fingerprint: m.fingerprint ?? null,
  headText: m.headText || "",
  subHeadText: m.subHeadText || "",
  codeText: m.codeText || "",
  columnName: m.columnName || "",
});

export const sameMappingSet = (a = [], b = []) => {
  if (a.length !== b.length) return false;
  const keys = new Set(a.map(mappingKey));
  return b.every((m) => keys.has(mappingKey(m)));
};

export const groupByReport = (list = []) => {
  const out = {};
  MAPPING_REPORTS.forEach((r) => (out[r.id] = []));
  list.forEach((m) => {
    (out[m.reportId] = out[m.reportId] || []).push(m);
  });
  return out;
};

/** Human label of the Head row of a target. */
export const headLabel = (m) => m.headText || m.codeText || m.rowId || "-";

/** One-line summary, e.g. "5 mappings (NWSA 2, PNL 3)". Works on saved request payloads too. */
export const summarizeMappings = (list = []) => {
  if (!list || list.length === 0) return "None";
  const grouped = groupByReport(list);
  const parts = Object.keys(grouped)
    .filter((id) => grouped[id].length > 0)
    .map((id) => `${id} ${grouped[id].length}`);
  return `${list.length} mapping${list.length > 1 ? "s" : ""} (${parts.join(", ")})`;
};

/** Multi-line description for read-only views (My Requests). Falls back to ids when no display text was saved. */
export const describeMappings = (list = []) => {
  if (!list || list.length === 0) return "None";
  return list
    .map((m) => {
      const head = m.headText || m.codeText || m.rowId;
      const col = m.columnName ? ` [${m.columnName}]` : "";
      const variable = m.variableName ? ` / ${m.variableName}` : "";
      return `${m.reportId}: ${head}${col}${variable}`;
    })
    .join("\n");
};

/** Server replies are wrapped as { status, message, data }. */
export const unwrapList = (resp) => {
  const d = resp?.data;
  if (Array.isArray(d)) return d;
  if (Array.isArray(d?.data)) return d.data;
  return [];
};
