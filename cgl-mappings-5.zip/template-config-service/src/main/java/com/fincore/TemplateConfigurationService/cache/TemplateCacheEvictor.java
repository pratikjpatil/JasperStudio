package com.fincore.TemplateConfigurationService.cache;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.HashSet;
import java.util.Set;

/**
 * Evicts Report Builder's Redis cache entries for a given templateId.
 *
 * This service does not own the CacheManager backing these entries - Report Builder does,
 * via its own Spring Cache config. So we can't use @CacheEvict here; instead we delete the
 * underlying Redis keys directly. These MUST mirror Report Builder's cache names and key
 * formats exactly, or eviction silently becomes a no-op:
 *   - "reportTemplates" cache, key = templateId               -> reportTemplates::<templateId>
 *   - "reportVariants" cache, key = templateId + ':' + variantCode -> reportVariants::<templateId>:<variantCode>
 *
 * If Report Builder ever changes its cache names, key format, or the Spring Data Redis
 * key separator, update the constants below to match.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class TemplateCacheEvictor {

    private final StringRedisTemplate redisTemplate;

    private static final String TEMPLATE_CACHE_PREFIX = "reportTemplates::";
    private static final String VARIANT_CACHE_PREFIX = "reportVariants::";

    /**
     * Evicts once the surrounding transaction has really committed (avoids the report builder re-caching the old
     * version between eviction and commit). Evicts immediately when no transaction is active.
     */
    public void evictAfterCommit(java.util.Collection<String> templateIds) {
        java.util.List<String> ids = new java.util.ArrayList<>(new java.util.LinkedHashSet<>(templateIds));
        if (org.springframework.transaction.support.TransactionSynchronizationManager.isSynchronizationActive()) {
            org.springframework.transaction.support.TransactionSynchronizationManager.registerSynchronization(
                    new org.springframework.transaction.support.TransactionSynchronization() {
                        @Override
                        public void afterCommit() {
                            ids.forEach(TemplateCacheEvictor.this::evictReportBuilderCache);
                        }
                    });
        } else {
            ids.forEach(this::evictReportBuilderCache);
        }
    }

    public void evictReportBuilderCache(String templateId) {
        if (!StringUtils.hasText(templateId)) {
            return;
        }

        try {
            redisTemplate.delete(TEMPLATE_CACHE_PREFIX + templateId);

            String variantKeyPattern = VARIANT_CACHE_PREFIX + templateId + ":*";
            Set<String> variantKeys = new HashSet<>();
            ScanOptions scanOptions = ScanOptions.scanOptions().match(variantKeyPattern).count(200).build();

            try (Cursor<byte[]> cursor = redisTemplate.getConnectionFactory()
                    .getConnection()
                    .keyCommands()
                    .scan(scanOptions)) {
                while (cursor.hasNext()) {
                    variantKeys.add(new String(cursor.next()));
                }
            }

            if (!variantKeys.isEmpty()) {
                redisTemplate.delete(variantKeys);
            }

            log.debug("Evicted Report Builder cache for templateId: {} ({} variant keys)",
                    templateId, variantKeys.size());
        } catch (Exception e) {
            // Never fail the calling transaction because cache eviction had trouble - log and move on.
            log.error("Failed to evict Report Builder cache for templateId: {}", templateId, e);
        }
    }
}