package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.dto.TemplateVersion;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ReportTemplateRepository extends JpaRepository<ReportTemplate, String> {
    Optional<ReportTemplate> findFirstByReportId(String reportId);

    Optional<ReportTemplate> findFirstByReportIdAndStatus(String reportId, String status);

    boolean existsByReportIdAndStatus(String reportId, String status);

    /**
     * Row lock (SELECT ... FOR UPDATE, 15s wait) used by every flow that rewrites template JSON, so a CGL
     * mapping change and a template maker-checker approval can never interleave on the same template.
     * Callers locking several templates must do so in ascending reportId order.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "15000"))
    @Query("select t from ReportTemplate t where t.reportId = :reportId")
    List<ReportTemplate> lockByReportId(@Param("reportId") String reportId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "15000"))
    @Query("select t from ReportTemplate t where t.reportId = :reportId and t.status = 'ACTIVE'")
    List<ReportTemplate> lockActiveByReportId(@Param("reportId") String reportId);
}
