package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.TemplateConfigurationService.response.ApiResponse;
import com.fincore.commonutilities.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * CGL mapping API. Responses use the same ApiResponse envelope as TemplateController ({status, message, data}).
 * Called by the Common Request Service with the checker's own JWT forwarded, so the existing authentication
 * filter and audit user resolution apply unchanged.
 */
@Slf4j
@RestController
@RequestMapping("/api/template-config/cgl-mappings")
@RequiredArgsConstructor
public class CglMappingController {

    private final CglMappingService service;
    private final JwtUtil jwtUtil;

    /** Picker for the maker: eligible Head/Variable targets of the ACTIVE template of a report. */
    @GetMapping("/targets")
    public ResponseEntity<ApiResponse> targets(@RequestParam String reportId,
                                               @RequestParam(required = false) String q,
                                               HttpServletRequest request) {
        return ok("Targets fetched", service.listTargets(reportId, q), request);
    }

    /** Dry run at maker submit. */
    @PostMapping("/validate")
    public ResponseEntity<ApiResponse> validate(@RequestBody ValidateRequest body, HttpServletRequest request) {
        return ok("Validated", service.validate(body), request);
    }

    /** Idempotent on commonReqId. Executes in one transaction across all affected templates. */
    @PostMapping("/apply")
    public ResponseEntity<ApiResponse> apply(@Valid @RequestBody ApplyRequest body,
                                             @RequestHeader("Authorization") String token,
                                             HttpServletRequest request) {
        String checkerId = jwtUtil.getUserIdFromToken(token);
        log.info("CGL mapping apply: cgl={}, commonReqId={}, checker={}", body.getCglNumber(),
                body.getCommonReqId(), checkerId);
        return ok("CGL mappings applied", service.apply(body, checkerId), request);
    }

    /** Current mappings of a CGL (pre-fills the CGL update screen). */
    @GetMapping("/by-cgl/{cglNumber}")
    public ResponseEntity<ApiResponse> byCgl(@PathVariable String cglNumber, HttpServletRequest request) {
        return ok("Mappings fetched", service.mappingsOfCgl(cglNumber), request);
    }

    /** Active CGLs that are not mapped anywhere yet (legacy gap list before enforcing mapping). */
    @GetMapping("/unmapped")
    public ResponseEntity<ApiResponse> unmapped(HttpServletRequest request) {
        return ok("Unmapped CGLs fetched", service.unmappedActiveCgls(), request);
    }

    private ResponseEntity<ApiResponse> ok(String message, Object data, HttpServletRequest request) {
        return ResponseEntity.ok(ApiResponse.builder()
                .status("SUCCESS")
                .message(message)
                .data(data)
                .timestamp(LocalDateTime.now())
                .path(request.getRequestURI())
                .build());
    }
}
