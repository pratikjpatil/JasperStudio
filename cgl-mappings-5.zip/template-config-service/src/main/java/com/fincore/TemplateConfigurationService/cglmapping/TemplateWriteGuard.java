package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Protects "every CGL has at least one mapping" against template writes that replace the whole JSON
 * (update, rollback, delete, re-create). If such a write would remove an ACTIVE CGL from this report and the CGL
 * is not mapped in any other configured report, the write is refused with the list of affected CGLs.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TemplateWriteGuard {

    private static final int IN_CHUNK = 500;

    private final JsonMapper jsonMapper;
    private final ReportTemplateRepository templateRepository;
    private final MappingTargetExtractor extractor;
    private final CglMappingProperties props;
    private final JdbcTemplate jdbcTemplate;

    /**
     * @param newJson the template JSON that will replace oldJson; null when the template is being deleted.
     */
    public void assertNoCglLosesAllMappings(String reportId, String oldJson, String newJson) {
        if (!props.isGuardEnabled() || props.rule(reportId).isEmpty() || oldJson == null) {
            return;
        }
        Set<String> before = cglsOf(reportId, oldJson);
        if (before.isEmpty()) {
            return;
        }
        Set<String> after = newJson == null ? Set.of() : cglsOf(reportId, newJson);

        Set<String> dropped = new TreeSet<>(before);
        dropped.removeAll(after);
        if (dropped.isEmpty()) {
            return;
        }

        Set<String> activeDropped = activeInMaster(dropped);
        if (activeDropped.isEmpty()) {
            return;
        }

        for (String other : props.getReports().keySet()) {
            if (other.equalsIgnoreCase(reportId)) {
                continue;
            }
            templateRepository.findFirstByReportIdAndStatus(other, "ACTIVE")
                    .map(ReportTemplate::getTemplateJson)
                    .ifPresent(json -> activeDropped.removeAll(cglsOf(other, json)));
            if (activeDropped.isEmpty()) {
                return;
            }
        }

        List<String> sample = new ArrayList<>(activeDropped).subList(0, Math.min(20, activeDropped.size()));
        throw new CglMappingException("CGL_WOULD_BE_UNMAPPED",
                activeDropped.size() + " active CGL(s) would be left without any report mapping by this change to "
                        + reportId + ": " + sample + (activeDropped.size() > 20 ? " ..." : "")
                        + ". Re-map them through CGL update first.");
    }

    /** All CGL values present in eligible carriers of the given template JSON. */
    public Set<String> cglsOf(String reportId, String json) {
        Set<String> out = new HashSet<>();
        JsonNode root = jsonMapper.readTree(json);
        var rule = props.rule(reportId).orElseThrow();
        for (Carrier c : extractor.extract(reportId, root)) {
            out.addAll(codecRead(c, rule));
        }
        return out;
    }

    private List<String> codecRead(Carrier c, CglMappingProperties.ReportRule rule) {
        // Reads through the codec so that every supported filter shape is understood.
        return codec.read(c.node(), rule);
    }

    private Set<String> activeInMaster(Set<String> cgls) {
        Set<String> active = new HashSet<>();
        List<String> all = new ArrayList<>(cgls);
        for (int i = 0; i < all.size(); i += IN_CHUNK) {
            List<String> chunk = all.subList(i, Math.min(all.size(), i + IN_CHUNK));
            String placeholders = String.join(",", java.util.Collections.nCopies(chunk.size(), "?"));
            active.addAll(jdbcTemplate.queryForList(
                    "SELECT CGL_NUMBER FROM CGL_MASTER WHERE STATUS = 1 AND CGL_NUMBER IN (" + placeholders + ")",
                    String.class, chunk.toArray()));
        }
        return active;
    }

    private final CglFilterCodec codec;
}
