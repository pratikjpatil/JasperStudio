package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cache.TemplateCacheEvictor;
import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.TemplateConfigurationService.cglmapping.CglMappingProperties.ReportRule;
import com.fincore.TemplateConfigurationService.cglmapping.MappingTargetExtractor.Carrier;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import com.fincore.TemplateConfigurationService.service.TemplateVersioningService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * Applies CGL -> Head/Variable mappings into template JSON.
 *
 * One call = one transaction across every affected template: each gets a new version (previous version goes to
 * RB_REPORT_TEMPLATE_HISTORY), and one accepted RB_TEMPLATE_REQUEST row (change type CGL_MAP) per template records
 * who/when/what, linked to the CGL request through SOURCE_REF. Template JSON stays the source of truth.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CglMappingService {

    public static final String STATE_APPLIED = "CGL_APPLIED";
    public static final String STATE_CONFIRMED = "CGL_CONFIRMED";
    public static final String STATE_REVERTED = "CGL_REVERTED";

    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final ReportTemplateRepository templateRepository;
    private final TemplateRequestRepository requestRepository;
    private final TemplateVersioningService versioning;
    private final MappingTargetExtractor extractor;
    private final CglFilterCodec codec;
    private final CglMappingProperties props;
    private final TemplateCacheEvictor cacheEvictor;
    private final JsonMapper jsonMapper;
    private final TemplateWriteGuard guard;
    private final org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

    // =====================================================================
    // Read side
    // =====================================================================

    @Transactional(readOnly = true)
    public List<Target> listTargets(String reportId, String q) {
        ReportRule rule = rule(reportId);
        ReportTemplate t = activeTemplate(reportId);
        JsonNode root = parse(t.getTemplateJson());
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<Target> out = new ArrayList<>();
        for (Carrier c : extractor.extract(reportId, root)) {
            if (!needle.isEmpty() && !(lower(c.headText()).contains(needle) || lower(c.codeText()).contains(needle)
                    || lower(c.subHeadText()).contains(needle) || lower(c.variableName()).contains(needle)
                    || lower(c.columnName()).contains(needle))) {
                continue;
            }
            out.add(toTarget(t, c, codec.read(c.node(), rule).size()));
        }
        return out;
    }

    /** Current mappings of a CGL across all configured reports (scans the active template JSONs). */
    @Transactional(readOnly = true)
    public List<Target> mappingsOfCgl(String cglNumber) {
        List<Target> out = new ArrayList<>();
        for (String reportId : props.getReports().keySet()) {
            Optional<ReportTemplate> t = templateRepository.findFirstByReportIdAndStatus(reportId, "ACTIVE");
            if (t.isEmpty()) {
                continue;
            }
            JsonNode root = parse(t.get().getTemplateJson());
            for (Carrier c : extractor.containing(reportId, root, cglNumber)) {
                out.add(toTarget(t.get(), c, codec.read(c.node(), rule(reportId)).size()));
            }
        }
        return out;
    }

    /**
     * Back-fill helper: ACTIVE CGLs in CGL_MASTER that appear in none of the configured reports' active templates.
     * Business must map these (through a CGL update) before mapping is enforced.
     */
    @Transactional(readOnly = true)
    public List<String> unmappedActiveCgls() {
        Set<String> mapped = new HashSet<>();
        for (String reportId : props.getReports().keySet()) {
            templateRepository.findFirstByReportIdAndStatus(reportId, "ACTIVE")
                    .ifPresent(t -> mapped.addAll(guard.cglsOf(reportId, t.getTemplateJson())));
        }
        List<String> all = new ArrayList<>(jdbcTemplate.queryForList(
                "SELECT CGL_NUMBER FROM CGL_MASTER WHERE STATUS = 1 ORDER BY CGL_NUMBER", String.class));
        all.removeAll(mapped);
        return all;
    }

    /** Dry run used at maker submit: resolves every pick against the active templates, no writes. */
    @Transactional(readOnly = true)
    public ValidateResponse validate(ValidateRequest req) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<Target> resolved = new ArrayList<>();

        if (req.isRequireMapping() && req.getMappings().isEmpty()) {
            errors.add("[MAPPING_REQUIRED] At least one Head/Variable mapping is required");
        }
        for (Map.Entry<String, List<MappingRef>> e : groupByReport(req.getMappings()).entrySet()) {
            String reportId = e.getKey();
            try {
                rule(reportId);
                ReportTemplate t = activeTemplate(reportId);
                List<Carrier> carriers = extractor.extract(reportId, parse(t.getTemplateJson()));
                Set<String> rows = new LinkedHashSet<>();
                Set<String> seen = new HashSet<>();
                for (MappingRef ref : e.getValue()) {
                    try {
                        Carrier c = resolve(carriers, ref, t);
                        if (!seen.add(c.key())) {
                            warnings.add(reportId + ": duplicate pick for " + c.headText() + " / " + c.variableName() + " ignored");
                            continue;
                        }
                        rows.add(c.rowId());
                        resolved.add(toTarget(t, c, 0));
                    } catch (CglMappingException ex) {
                        errors.add(reportId + ": " + ex.getMessage());
                    }
                }
                if (rows.size() > 1) {
                    warnings.add(reportId + ": CGL is mapped to " + rows.size()
                            + " different Heads (possible double counting)");
                }
            } catch (CglMappingException ex) {
                errors.add(reportId + ": " + ex.getMessage());
            }
        }
        return ValidateResponse.builder().valid(errors.isEmpty()).errors(errors).warnings(warnings).resolved(resolved).build();
    }

    // =====================================================================
    // Apply
    // =====================================================================

    @Transactional(rollbackFor = Exception.class)
    public ApplyResult apply(ApplyRequest req, String checkerId) {
        final String sourceRef = String.valueOf(req.getCommonReqId());

        List<TemplateRequest> existing = requestRepository.findBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP);
        if (!existing.isEmpty()) {
            return replay(req.getCommonReqId(), existing);
        }

        final String cgl = req.getCglNumber().trim();
        final String changeType = req.getChangeType().trim().toUpperCase(Locale.ROOT);
        if (!changeType.equals("ADD") && !changeType.equals("UPDATE")) {
            throw new CglMappingException("INVALID_CHANGE_TYPE", "changeType must be ADD or UPDATE");
        }
        Map<String, List<MappingRef>> desiredByReport = groupByReport(req.getMappings());
        if (req.isRequireMapping() && desiredByReport.isEmpty()) {
            throw new CglMappingException("MAPPING_REQUIRED", "At least one Head/Variable mapping is required for CGL " + cgl);
        }

        // Reports to touch: desired ones, plus (for UPDATE) reports where the CGL is currently mapped (removals).
        TreeSet<String> affected = new TreeSet<>(desiredByReport.keySet());
        if (changeType.equals("UPDATE")) {
            affected.addAll(reportsContaining(cgl));
        }

        LocalDateTime now = LocalDateTime.now(IST);
        List<ReportChange> changes = new ArrayList<>();
        List<String> touchedTemplateIds = new ArrayList<>();

        for (String reportId : affected) {                       // ascending order -> consistent lock order
            ReportRule rule = rule(reportId);
            ReportTemplate t = lockActive(reportId);
            JsonNode root = parse(t.getTemplateJson());
            List<Carrier> carriers = extractor.extract(reportId, root);

            Map<String, Carrier> current = new LinkedHashMap<>();
            for (Carrier c : carriers) {
                if (codec.read(c.node(), rule).contains(cgl)) {
                    current.put(c.key(), c);
                }
            }
            Map<String, Carrier> desired = new LinkedHashMap<>();
            for (MappingRef ref : desiredByReport.getOrDefault(reportId, List.of())) {
                Carrier c = resolve(carriers, ref, t);
                desired.put(c.key(), c);
            }

            List<Carrier> toAdd = new ArrayList<>();
            List<Carrier> toRemove = new ArrayList<>();
            desired.forEach((k, c) -> {
                if (!current.containsKey(k)) toAdd.add(c);
            });
            current.forEach((k, c) -> {
                if (!desired.containsKey(k)) toRemove.add(c);
            });
            if (toAdd.isEmpty() && toRemove.isEmpty()) {
                continue;
            }

            ArrayNode changeLog = jsonMapper.createArrayNode();
            for (Carrier c : toAdd) {
                changeLog.add(editAndDescribe(c, cgl, rule, true, false));
            }
            for (Carrier c : toRemove) {
                changeLog.add(editAndDescribe(c, cgl, rule, false, false));
            }

            ReportChange rc = persistNewVersion(t, root, changeLog, cgl, "CGL_CODE_" + changeType,
                    sourceRef, req.getCommonReqId(), req.getMakerId(), checkerId, now,
                    "Applied from CGL code " + changeType + " request #" + req.getCommonReqId());
            rc.setAdded(toAdd.size());
            rc.setRemoved(toRemove.size());
            changes.add(rc);
            touchedTemplateIds.add(t.getTemplateId());
        }

        cacheEvictor.evictAfterCommit(touchedTemplateIds);
        log.info("CGL mapping applied: cgl={}, commonReqId={}, changes={}", cgl, req.getCommonReqId(), changes);
        return ApplyResult.builder().commonReqId(req.getCommonReqId()).replay(false).changes(changes).build();
    }

    // =====================================================================
    // Confirm / revert (reconciler)
    // =====================================================================

    @Transactional
    public void confirm(String sourceRef) {
        for (TemplateRequest r : requestRepository.lockBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP)) {
            if (STATE_APPLIED.equals(r.getExecutorRemarks())) {
                r.setExecutorRemarks(STATE_CONFIRMED);
                requestRepository.save(r);
            }
        }
    }

    /**
     * Compensation: applies the inverse of the recorded changes as NEW versions (never restores snapshots,
     * so unrelated later changes survive) and writes its own CGL_MAP audit row with SOURCE_REF = "<ref>R".
     */
    @Transactional(rollbackFor = Exception.class)
    public void revert(String sourceRef, String actor, String reason) {
        List<TemplateRequest> rows = requestRepository.lockBySourceRefAndChangeType(sourceRef, ChangeType.CGL_MAP);
        LocalDateTime now = LocalDateTime.now(IST);
        List<String> touched = new ArrayList<>();

        for (TemplateRequest row : rows) {
            if (!STATE_APPLIED.equals(row.getExecutorRemarks())) {
                continue;
            }
            JsonNode audit = parse(row.getPayload());
            String reportId = audit.path("reportId").asString();
            String cgl = audit.path("cglNumber").asString();
            ReportRule rule = rule(reportId);

            Optional<ReportTemplate> lockedOpt = templateRepository.lockActiveByReportId(reportId).stream().findFirst();
            if (lockedOpt.isEmpty()) {
                row.setExecutorRemarks("CGL_REVERT_SKIPPED");
                requestRepository.save(row);
                log.warn("Revert skipped, no active template for report {} (ref {})", reportId, sourceRef);
                continue;
            }
            ReportTemplate t = lockedOpt.get();
            JsonNode root = parse(t.getTemplateJson());
            List<Carrier> carriers = extractor.extract(reportId, root);

            ArrayNode changeLog = jsonMapper.createArrayNode();
            for (JsonNode ch : audit.path("changes")) {
                String action = ch.path("action").asString();
                Carrier c = findByLocation(carriers, ch.path("rowId").asString(), ch.path("cellId").asString(),
                        ch.path("variableName").asString());
                if (c == null) {
                    log.warn("Revert: target gone ({} {}), skipped", ch.path("rowId").asString(), ch.path("cellId").asString());
                    continue;
                }
                boolean wasAdd = "ADD_MAPPING".equals(action);
                changeLog.add(editAndDescribe(c, cgl, rule, !wasAdd, true));
            }
            if (!changeLog.isEmpty()) {
                persistNewVersion(t, root, changeLog, cgl, "CGL_REVERT", sourceRef + "R" + row.getReqId(),
                        audit.path("commonReqId").asLong(), actor, actor, now,
                        "Reverted CGL request #" + sourceRef + ": " + reason);
                touched.add(t.getTemplateId());
            }
            // Free the reference: if the checker retries the approval later, apply() must run again,
            // not "replay" a change that has been reverted.
            row.setExecutorRemarks(STATE_REVERTED);
            row.setSourceRef(sourceRef + "X" + row.getReqId());
            requestRepository.save(row);
        }
        cacheEvictor.evictAfterCommit(touched);
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /** Edits the carrier (adds or removes the CGL) and returns the audit description of the change. */
    private ObjectNode editAndDescribe(Carrier c, String cgl, ReportRule rule, boolean add, boolean revert) {
        List<String> before = codec.read(c.node(), rule);
        if (add) {
            codec.add(c.node(), cgl, rule);
        } else {
            codec.remove(c.node(), cgl, rule, revert);
        }
        List<String> after = codec.read(c.node(), rule);

        ObjectNode o = jsonMapper.createObjectNode();
        o.put("action", revert ? (add ? "REVERT_REMOVE" : "REVERT_ADD") : (add ? "ADD_MAPPING" : "REMOVE_MAPPING"));
        o.put("rowId", c.rowId());
        o.put("cellId", c.cellId());
        o.put("columnName", c.columnName() == null ? "" : c.columnName());
        o.put("variableName", c.variableName() == null ? "" : c.variableName());
        o.put("headText", c.headText());
        o.put("codeText", c.codeText());
        ArrayNode b = o.putArray("oldCglList");
        before.forEach(b::add);
        ArrayNode a = o.putArray("newCglList");
        after.forEach(a::add);
        return o;
    }

    /**
     * Archives the current version, writes the edited JSON as the next version and records the audit row.
     * Order matters: archive -> next version -> audit row (gives REQ_ID) -> template save (links SOURCE_REQ_ID).
     */
    private ReportChange persistNewVersion(ReportTemplate t, JsonNode root, ArrayNode changeLog, String cgl,
                                           String source, String sourceRef, Long commonReqId, String makerId,
                                           String executorId, LocalDateTime now, String executionRemarks) {
        int from = t.getVersionNo();
        int to = versioning.archiveAndNextVersion(t, executorId, now);

        JsonNode meta = root.path("templateMeta");
        if (meta.isObject()) {
            ((ObjectNode) meta).put("version", String.valueOf(to));
        }

        ObjectNode payload = jsonMapper.createObjectNode();
        payload.put("source", source);
        payload.put("commonReqId", commonReqId == null ? 0L : commonReqId);
        payload.put("cglNumber", cgl);
        payload.put("reportId", t.getReportId());
        payload.put("templateId", t.getTemplateId());
        payload.put("fromVersion", from);
        payload.put("toVersion", to);
        payload.set("changes", changeLog);

        String remarks = "CGL " + cgl + " mapped via " + source + " request #" + commonReqId;
        TemplateRequest audit = TemplateRequest.builder()
                .changeType(ChangeType.CGL_MAP)
                .reqStatus(RequestStatus.ACCEPTED)
                .reqDate(now)
                .creatorId(makerId)
                .executionDate(now)
                .executorId(executorId)
                .executorRemarks(source.equals("CGL_REVERT") ? "CGL_REVERT_ROW" : STATE_APPLIED)
                .executionRemarks(executionRemarks + ": " + t.getReportId() + " v" + from + " -> v" + to)
                .payload(jsonMapper.writeValueAsString(payload))
                .targetId(t.getReportId())
                .remarks(remarks.length() > 500 ? remarks.substring(0, 500) : remarks)
                .sourceRef(sourceRef)
                .build();
        audit = requestRepository.save(audit);

        t.setTemplateJson(jsonMapper.writeValueAsString(root));
        t.setVersionNo(to);
        t.setUpdatedAt(now);
        t.setUpdatedBy(executorId);
        t.setRemarks(audit.getRemarks());
        t.setSourceReqId(audit.getReqId());
        templateRepository.save(t);

        return ReportChange.builder().reportId(t.getReportId()).templateId(t.getTemplateId())
                .fromVersion(from).toVersion(to).auditReqId(audit.getReqId()).build();
    }

    private ApplyResult replay(Long commonReqId, List<TemplateRequest> rows) {
        List<ReportChange> changes = new ArrayList<>();
        for (TemplateRequest r : rows) {
            JsonNode p = parse(r.getPayload());
            int n = p.path("changes").size();
            int added = 0;
            for (JsonNode ch : p.path("changes")) {
                if ("ADD_MAPPING".equals(ch.path("action").asString())) added++;
            }
            changes.add(ReportChange.builder().reportId(p.path("reportId").asString())
                    .templateId(p.path("templateId").asString())
                    .fromVersion(p.path("fromVersion").asInt()).toVersion(p.path("toVersion").asInt())
                    .added(added).removed(n - added).auditReqId(r.getReqId()).build());
        }
        return ApplyResult.builder().commonReqId(commonReqId).replay(true).changes(changes).build();
    }

    private Set<String> reportsContaining(String cgl) {
        Set<String> out = new TreeSet<>();
        for (String reportId : props.getReports().keySet()) {
            templateRepository.findFirstByReportIdAndStatus(reportId, "ACTIVE").ifPresent(t -> {
                if (!extractor.containing(reportId, parse(t.getTemplateJson()), cgl).isEmpty()) {
                    out.add(reportId);
                }
            });
        }
        return out;
    }

    private Carrier resolve(List<Carrier> carriers, MappingRef ref, ReportTemplate t) {
        Carrier c = findByLocation(carriers, ref.getRowId(), ref.getCellId(), ref.getVariableName());
        if (c == null) {
            throw new CglMappingException("TARGET_NOT_FOUND", "Head/Variable not found in " + t.getReportId()
                    + " v" + t.getVersionNo() + " (row " + ref.getRowId() + ", cell " + ref.getCellId()
                    + ", variable " + ref.getVariableName() + "). Re-select it.");
        }
        if (ref.getFingerprint() != null && !ref.getFingerprint().isBlank()) {
            if (!ref.getFingerprint().equals(c.fingerprint())) {
                throw new CglMappingException("TARGET_CHANGED", "Row " + ref.getRowId() + " of " + t.getReportId()
                        + " no longer matches what was selected (template changed). Re-select it.");
            }
        } else if (ref.getBaseVersion() != null && ref.getBaseVersion().intValue() != t.getVersionNo().intValue()) {
            throw new CglMappingException("TARGET_CHANGED", t.getReportId() + " moved from v" + ref.getBaseVersion()
                    + " to v" + t.getVersionNo() + " since selection. Re-select the target.");
        }
        return c;
    }

    private Carrier findByLocation(List<Carrier> carriers, String rowId, String cellId, String variableName) {
        String v = variableName == null ? "" : variableName;
        for (Carrier c : carriers) {
            if (c.rowId().equals(rowId) && c.cellId().equals(cellId) && (c.variableName() == null ? "" : c.variableName()).equals(v)) {
                return c;
            }
        }
        return null;
    }

    private Map<String, List<MappingRef>> groupByReport(List<MappingRef> refs) {
        Map<String, List<MappingRef>> m = new TreeMap<>();
        if (refs != null) {
            for (MappingRef r : refs) {
                m.computeIfAbsent(r.getReportId().trim().toUpperCase(Locale.ROOT), k -> new ArrayList<>()).add(r);
            }
        }
        return m;
    }

    private ReportRule rule(String reportId) {
        return props.rule(reportId).orElseThrow(() ->
                new CglMappingException("REPORT_NOT_CONFIGURED", "Report " + reportId + " is not enabled for CGL mapping"));
    }

    private ReportTemplate activeTemplate(String reportId) {
        return templateRepository.findFirstByReportIdAndStatus(reportId, "ACTIVE").orElseThrow(() ->
                new CglMappingException("TEMPLATE_NOT_ACTIVE", "No ACTIVE template for report " + reportId));
    }

    private ReportTemplate lockActive(String reportId) {
        return templateRepository.lockActiveByReportId(reportId).stream().findFirst().orElseThrow(() ->
                new CglMappingException("TEMPLATE_NOT_ACTIVE", "No ACTIVE template for report " + reportId));
    }

    private JsonNode parse(String json) {
        return jsonMapper.readTree(json);
    }

    private Target toTarget(ReportTemplate t, Carrier c, int cglCount) {
        return Target.builder().reportId(t.getReportId()).templateId(t.getTemplateId()).baseVersion(t.getVersionNo())
                .rowId(c.rowId()).cellId(c.cellId()).columnId(c.columnId()).columnName(c.columnName())
                .variableName(c.variableName()).carrier(c.kind())
                .variableType(c.variableType()).headText(c.headText()).codeText(c.codeText())
                .subHeadText(c.subHeadText()).otherFilters(c.otherFilters()).fingerprint(c.fingerprint())
                .cglCount(cglCount).build();
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }
}
