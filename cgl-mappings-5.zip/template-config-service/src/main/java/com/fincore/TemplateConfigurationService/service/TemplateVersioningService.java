package com.fincore.TemplateConfigurationService.service;

import com.fincore.TemplateConfigurationService.dto.FilterRuleDto;
import com.fincore.TemplateConfigurationService.dto.VariantDto;
import com.fincore.TemplateConfigurationService.dto.VariantParamDto;
import com.fincore.TemplateConfigurationService.entity.FilterRule;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.entity.ReportTemplateHistory;
import com.fincore.TemplateConfigurationService.entity.ReportVariant;
import com.fincore.TemplateConfigurationService.entity.VariantParamDef;
import com.fincore.TemplateConfigurationService.repository.FilterRuleRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateHistoryRepository;
import com.fincore.TemplateConfigurationService.repository.ReportVariantRepository;
import com.fincore.TemplateConfigurationService.repository.VariantParamDefRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Single place for "archive current version to history" and "compute next version", shared by the template
 * maker-checker flow and the CGL mapping flow so the rollback-aware versioning rule exists exactly once.
 * Methods join the caller's transaction.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TemplateVersioningService {

    private final ReportTemplateHistoryRepository historyRepository;
    private final ReportVariantRepository variantRepository;
    private final VariantParamDefRepository paramRepository;
    private final FilterRuleRepository filterRuleRepository;
    private final JsonMapper jsonMapper;

    /** Copies the current row (and its variants snapshot) to history unless that version is already archived. */
    public void archive(ReportTemplate template, String archivedBy, LocalDateTime archivedAt) {
        String variantsSnapshot = fetchVariantsAsJson(template.getTemplateId());
        if (historyRepository.findByTemplateIdAndVersionNo(template.getTemplateId(), template.getVersionNo()).isPresent()) {
            return;
        }
        ReportTemplateHistory history = ReportTemplateHistory.builder()
                .templateId(template.getTemplateId())
                .versionNo(template.getVersionNo())
                .reportId(template.getReportId())
                .templateName(template.getTemplateName())
                .description(template.getDescription())
                .status("INACTIVE")
                .templateJson(template.getTemplateJson())
                .variantsJson(variantsSnapshot)
                .createdBy(template.getCreatedBy())
                .createdAt(template.getCreatedAt())
                .archivedBy(archivedBy)
                .archivedAt(archivedAt)
                .remarks(template.getRemarks())
                .sourceReqId(template.getSourceReqId())
                .build();
        historyRepository.save(history);
    }

    /** Next version number. Call AFTER archive(): after a rollback the next version continues from the history maximum. */
    public int nextVersion(ReportTemplate template) {
        if (template.getCreatedFrom() != null) {
            return historyRepository.getLatestVersion(template.getTemplateId()).orElse(template.getVersionNo()) + 1;
        }
        return template.getVersionNo() + 1;
    }

    public int archiveAndNextVersion(ReportTemplate template, String archivedBy, LocalDateTime archivedAt) {
        archive(template, archivedBy, archivedAt);
        return nextVersion(template);
    }

    public List<VariantDto> fetchVariantsAsDtos(String templateId) {
        List<ReportVariant> variants = variantRepository.findByTemplateId(templateId);
        List<VariantDto> dtos = new ArrayList<>();
        for (ReportVariant variant : variants) {
            List<VariantParamDef> params = paramRepository.findByVariantIdIn(List.of(variant.getVariantId()));
            List<FilterRule> rules = filterRuleRepository.findByVariantIdIn(List.of(variant.getVariantId()));

            VariantDto dto = VariantDto.builder()
                    .variantCode(variant.getVariantCode())
                    .variantName(variant.getVariantName())
                    .description(variant.getDescription())
                    .status(variant.getStatus())
                    .params(params.stream().map(p -> VariantParamDto.builder()
                            .paramName(p.getParamName())
                            .label(p.getLabel())
                            .paramType(p.getParamType())
                            .required("Y".equalsIgnoreCase(p.getRequired()))
                            .multiValued("Y".equalsIgnoreCase(p.getMultiVal()))
                            .uiHint(p.getUiHint())
                            .validation(p.getValidation())
                            .build()).toList())
                    .filterRules(rules.stream().map(r -> FilterRuleDto.builder()
                            .dbColumn(r.getDbColumn())
                            .operator(r.getOperator())
                            .paramName(r.getParamName())
                            .scopeType(r.getScopeType())
                            .scopeValue(r.getScopeValue())
                            .build()).toList())
                    .build();
            dtos.add(dto);
        }
        return dtos;
    }

    public String fetchVariantsAsJson(String templateId) {
        try {
            return jsonMapper.writeValueAsString(fetchVariantsAsDtos(templateId));
        } catch (Exception ex) {
            log.error("Failed to fetch variants snapshot for templateId={}", templateId, ex);
            return "[]";
        }
    }
}
