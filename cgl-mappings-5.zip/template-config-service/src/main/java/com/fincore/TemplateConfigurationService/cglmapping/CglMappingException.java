package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.exception.BadRequestException;

/** Business error with a machine-readable code, rendered as "[CODE] message" (HTTP 400). */
public class CglMappingException extends BadRequestException {

    private final String code;

    public CglMappingException(String code, String message) {
        super("[" + code + "] " + message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
