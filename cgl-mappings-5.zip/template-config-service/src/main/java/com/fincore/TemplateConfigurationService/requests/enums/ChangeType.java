package com.fincore.TemplateConfigurationService.requests.enums;

public enum ChangeType {
    ADD("A"),
    UPDATE("U"),
    DELETE("D"),
    STATUS("S"),
    ROLLBACK("R"),
    /** Audit-only request written when a CGL approval changes CGL values inside template JSON. */
    CGL_MAP("CM");

    private final String code;

    ChangeType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}