package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingProperties.ReportRule;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Finds every place in a template JSON where a CGL list can live ("carriers") and resolves the Head / code /
 * sub-head text of the row, using the per-report rule (the Head column differs per report).
 *
 * Only cells with a DB-backed variable of an eligible type qualify. Formula-only cells and cells with
 * an empty {@code variables} map are never targets.
 */
@Component
@RequiredArgsConstructor
public class MappingTargetExtractor {

    private final CglFilterCodec codec;
    private final CglMappingProperties props;

    public static final String KIND_VARIABLE = "VARIABLE";
    public static final String KIND_CELL_SOURCE = "CELL_SOURCE";

    /** A concrete, editable location of a CGL list inside a parsed template tree. */
    public record Carrier(String reportId, String rowId, String cellId, String columnId, String columnName,
                          String variableName, String kind,
                          String variableType, String headText, String codeText, String subHeadText,
                          String otherFilters, ObjectNode node) {

        public String key() {
            return rowId + "|" + cellId + "|" + (variableName == null ? "" : variableName);
        }

        /** Hash of the row's identifying text; proves the row still means what the maker picked. */
        public String fingerprint() {
            String raw = norm(headText) + "|" + norm(codeText) + "|" + norm(subHeadText);
            try {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
                return HexFormat.of().formatHex(d, 0, 8);
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        private static String norm(String s) {
            return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
        }
    }

    public List<Carrier> extract(String reportId, JsonNode templateRoot) {
        ReportRule rule = props.rule(reportId).orElseThrow(() ->
                new CglMappingException("REPORT_NOT_CONFIGURED", "No mapping rule configured for report " + reportId));

        JsonNode reportData = templateRoot.path("reportData");
        JsonNode columns = reportData.path("columns");
        int headIdx = indexOf(columns, rule.getHeadColumn());
        int codeIdx = indexOf(columns, rule.getCodeColumn());
        int subIdx = indexOf(columns, rule.getSubHeadColumn());

        List<Carrier> out = new ArrayList<>();
        for (JsonNode row : reportData.path("rows")) {
            String rowId = text(row.path("id"));
            JsonNode cells = row.path("cells");
            String head = cellText(cells, headIdx);
            String code = cellText(cells, codeIdx);
            String sub = cellText(cells, subIdx);

            int j = 0;
            for (JsonNode cell : cells) {
                String columnId = text(columns.path(j).path("id"));
                String columnName = text(columns.path(j).path("name"));
                String cellId = text(cell.path("id"));
                if (cellId.isEmpty()) {
                    cellId = "cell_" + rowId + "_" + columnId;
                }
                String type = text(cell.path("type"));

                JsonNode variables = cell.path("variables");
                if (variables.isObject()) {
                    for (Map.Entry<String, JsonNode> e : variables.properties()) {
                        JsonNode def = e.getValue();
                        if (!def.isObject()) {
                            continue;
                        }
                        String vType = text(def.path("type"));
                        if (isEligible(rule, vType)) {
                            out.add(new Carrier(reportId, rowId, cellId, columnId, columnName, e.getKey(), KIND_VARIABLE, vType,
                                    head, code, sub, otherFilters(def.path("filters"), rule), (ObjectNode) def));
                        }
                    }
                }
                if (rule.isIncludeCellSource() && type.startsWith("DB_") && cell.path("source").isObject()
                        && isEligible(rule, type)) {
                    out.add(new Carrier(reportId, rowId, cellId, columnId, columnName, "", KIND_CELL_SOURCE, type, head, code, sub,
                            otherFilters(cell.path("source").path("filters"), rule), (ObjectNode) cell.path("source")));
                }
                j++;
            }
        }
        return out;
    }

    /** Carriers whose CGL list currently contains the given CGL. */
    public List<Carrier> containing(String reportId, JsonNode root, String cgl) {
        ReportRule rule = props.rule(reportId).orElseThrow();
        List<Carrier> out = new ArrayList<>();
        for (Carrier c : extract(reportId, root)) {
            if (codec.read(c.node(), rule).contains(cgl)) {
                out.add(c);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------

    private boolean isEligible(ReportRule rule, String type) {
        return rule.getEligibleTypes().stream().anyMatch(t -> t.equalsIgnoreCase(type));
    }

    private int indexOf(JsonNode columns, String name) {
        if (name == null || name.isBlank() || !columns.isArray()) {
            return -1;
        }
        int i = 0;
        for (JsonNode c : columns) {
            if (name.trim().equalsIgnoreCase(text(c.path("name")).trim())) {
                return i;
            }
            i++;
        }
        return -1;
    }

    private String cellText(JsonNode cells, int idx) {
        if (idx < 0 || !cells.isArray() || idx >= cells.size()) {
            return "";
        }
        return text(cells.get(idx).path("value"));
    }

    private String otherFilters(JsonNode filters, ReportRule rule) {
        if (!filters.isObject()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, JsonNode> e : filters.properties()) {
            if (e.getKey().equalsIgnoreCase(rule.getFilterKey())) {
                continue;
            }
            JsonNode f = e.getValue();
            List<JsonNode> list = new ArrayList<>();
            if (f.isArray()) {
                f.forEach(list::add);
            } else {
                list.add(f);
            }
            for (JsonNode one : list) {
                if (sb.length() > 0) {
                    sb.append("; ");
                }
                sb.append(e.getKey()).append(' ').append(text(one.path("op"))).append(' ')
                        .append(one.path("value").toString());
            }
        }
        return sb.length() > 1000 ? sb.substring(0, 1000) : sb.toString();
    }

    private static String text(JsonNode n) {
        return (n == null || n.isMissingNode() || n.isNull()) ? "" : n.asString();
    }
}
