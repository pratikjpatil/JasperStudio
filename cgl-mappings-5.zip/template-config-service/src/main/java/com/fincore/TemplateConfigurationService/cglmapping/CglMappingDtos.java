package com.fincore.TemplateConfigurationService.cglmapping;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Request/response models of the CGL mapping API. */
public final class CglMappingDtos {

    private CglMappingDtos() {
    }

    /** A Head + Variable chosen by the maker. rowId + cellId + variableName locate it inside the template JSON. */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MappingRef {
        @NotBlank
        private String reportId;
        @NotBlank
        private String rowId;
        @NotBlank
        private String cellId;
        /** Empty/null for DB_* cell 'source' carriers. */
        private String variableName;
        /** Template version the maker saw. */
        private Integer baseVersion;
        /** Fingerprint of the Head row text at pick time (from /targets). */
        private String fingerprint;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Target {
        private String reportId;
        private String templateId;
        /** Send back unchanged as 'baseVersion' in the CGL payload. */
        private Integer baseVersion;
        private String rowId;
        private String cellId;
        /** The report column this variable belongs to (e.g. the two amount columns of PNL). */
        private String columnId;
        private String columnName;
        private String variableName;
        private String carrier;
        private String variableType;
        private String headText;
        private String codeText;
        private String subHeadText;
        private String otherFilters;
        private String fingerprint;
        private int cglCount;
    }

    @Data
    @NoArgsConstructor
    public static class ValidateRequest {
        private String cglNumber;
        private boolean requireMapping;
        private List<MappingRef> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ValidateResponse {
        private boolean valid;
        @Builder.Default
        private List<String> errors = new ArrayList<>();
        @Builder.Default
        private List<String> warnings = new ArrayList<>();
        @Builder.Default
        private List<Target> resolved = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    public static class ApplyRequest {
        /** COMMON_REQ.REQ_ID: idempotency key and audit reference. */
        @NotNull
        private Long commonReqId;
        /** ADD or UPDATE (the CGL request's change type). */
        @NotBlank
        private String changeType;
        @NotBlank
        private String cglNumber;
        @NotBlank
        private String makerId;
        private boolean requireMapping;
        /** Complete desired set of mappings of this CGL after approval. */
        private List<MappingRef> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ReportChange {
        private String reportId;
        private String templateId;
        private int fromVersion;
        private int toVersion;
        private int added;
        private int removed;
        private Long auditReqId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ApplyResult {
        private Long commonReqId;
        private boolean replay;
        @Builder.Default
        private List<ReportChange> changes = new ArrayList<>();
    }
}
