package com.fincore.TemplateConfigurationService.requests.service;

import com.fincore.TemplateConfigurationService.cache.TemplateCacheEvictor;
import com.fincore.TemplateConfigurationService.cglmapping.CglMappingProperties;
import com.fincore.TemplateConfigurationService.cglmapping.TemplateWriteGuard;
import com.fincore.TemplateConfigurationService.service.TemplateVersioningService;
import com.fincore.TemplateConfigurationService.dto.FilterRuleDto;
import com.fincore.TemplateConfigurationService.dto.TemplatePayload;
import com.fincore.TemplateConfigurationService.dto.VariantDto;
import com.fincore.TemplateConfigurationService.dto.VariantParamDto;
import com.fincore.TemplateConfigurationService.dto.*;
import com.fincore.TemplateConfigurationService.requests.dto.*;
import com.fincore.TemplateConfigurationService.util.JsonCompareUtil;
import com.fincore.TemplateConfigurationService.entity.FilterRule;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.entity.ReportTemplateHistory;
import com.fincore.TemplateConfigurationService.entity.ReportVariant;
import com.fincore.TemplateConfigurationService.entity.VariantParamDef;
import com.fincore.TemplateConfigurationService.exception.BadRequestException;
import com.fincore.TemplateConfigurationService.exception.TemplateNotFoundException;
import com.fincore.TemplateConfigurationService.repository.FilterRuleRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateHistoryRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import com.fincore.TemplateConfigurationService.repository.ReportVariantRepository;
import com.fincore.TemplateConfigurationService.repository.VariantParamDefRepository;
import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import com.fincore.TemplateConfigurationService.requests.repository.TemplateRequestRepository;
import com.fincore.TemplateConfigurationService.requests.validation.TemplateRequestValidationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

@Service
@RequiredArgsConstructor
@Slf4j
public class TemplateRequestServiceImpl implements TemplateRequestService {

    private static final ZoneId IST_ZONE = ZoneId.of("Asia/Kolkata");

    private final TemplateRequestRepository templateRequestRepository;
    private final ReportTemplateRepository reportTemplateRepository;
    private final ReportTemplateHistoryRepository reportTemplateHistoryRepository;
    private final ReportVariantRepository variantRepository;
    private final VariantParamDefRepository paramRepository;
    private final FilterRuleRepository filterRuleRepository;
    private final TemplateRequestValidationService templateRequestValidationService;
    private final BusinessSecurityService businessSecurityService;
    private final JsonMapper jsonMapper;
    private final JsonCompareUtil jsonCompareUtil;
    private final TemplateCacheEvictor cacheEvictor;
    private final TemplateVersioningService versioning;
    private final TemplateWriteGuard writeGuard;
    private final CglMappingProperties cglMappingProperties;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TemplateRequest createRequest(CreateTemplateRequestDto dto, String creatorId, String token) throws JacksonException {
        businessSecurityService.validateUserAction(token, dto.getChangeType());
        templateRequestValidationService.validate(dto);

        String targetId = dto.getPayload().getTemplate().getReportMeta().getReportId();
        if (!StringUtils.hasText(targetId)) {
            throw new BadRequestException("reportId is required");
        }

        List<TemplateRequest> duplicates = templateRequestRepository.findByTargetIdAndReqStatus(targetId, RequestStatus.PENDING);
        if (!duplicates.isEmpty()) {
            throw new DataIntegrityViolationException("A pending request for this template already exists");
        }

        if (dto.getChangeType() == ChangeType.UPDATE) {
            ReportTemplate activeTemplate = reportTemplateRepository.findFirstByReportIdAndStatus(targetId, "ACTIVE").orElseThrow(() -> new BadRequestException("Active template not found for reportId: " + targetId));

            // Reconstruct the old active template payload
            TemplatePayload oldPayload = parseOldTemplate(activeTemplate.getTemplateJson());
            oldPayload.setVariants(fetchVariantsAsDtos(activeTemplate.getTemplateId()));

            // Capture the diffs into variables
            Map<String, Map<String, ValueDiff>> cellDiffs = jsonCompareUtil.compareCells(oldPayload, dto.getPayload());
            Map<String, Map<String, ValueDiff>> colDiffs = jsonCompareUtil.compareColumns(oldPayload, dto.getPayload());
            Map<String, Map<String, ValueDiff>> variantDiffs = jsonCompareUtil.compareVariants(oldPayload.getVariants(), dto.getPayload().getVariants());
            Map<String, Map<String, ValueDiff>> paramDiffs = jsonCompareUtil.compareGlobalParams(oldPayload.getTemplate().getGlobalParams(), dto.getPayload().getTemplate().getGlobalParams());
            Map<String, Map<String, ValueDiff>> metaAndRowDiffs = jsonCompareUtil.compareTemplateLevel(oldPayload, dto.getPayload());

            // LOG THE EXACT DIFFERENCES TO THE CONSOLE
            if (!cellDiffs.isEmpty()) log.info("DETECTED CELL CHANGES: {}", cellDiffs);
            if (!colDiffs.isEmpty()) log.info("DETECTED COLUMN CHANGES: {}", colDiffs);
            if (!variantDiffs.isEmpty()) log.info("DETECTED VARIANT CHANGES: {}", variantDiffs);
            if (!paramDiffs.isEmpty()) log.info("DETECTED PARAM CHANGES: {}", paramDiffs);
            if (!metaAndRowDiffs.isEmpty()) log.info("DETECTED META / ROW DIFFS CHANGES: {}", metaAndRowDiffs);

            boolean hasChanges = !cellDiffs.isEmpty() || !colDiffs.isEmpty() || !variantDiffs.isEmpty() || !paramDiffs.isEmpty() || !metaAndRowDiffs.isEmpty();

            // If everything is empty, there are no changes
            if (!hasChanges) {
                throw new BadRequestException("No changes detected. Update request cannot be saved.");
            }
        }

        TemplateRequest request = TemplateRequest.builder().creatorId(creatorId).changeType(dto.getChangeType()).reqStatus(RequestStatus.PENDING).reqDate(LocalDateTime.now(IST_ZONE)).payload(jsonMapper.writeValueAsString(dto.getPayload())).targetId(targetId).remarks(dto.getPayload().getRemarks()).build();

        return templateRequestRepository.save(request);
    }


    // NEW: Parses the DB JSON (which only stores the Template object) into a full TemplatePayload wrapper
    private TemplatePayload parseOldTemplate(String json) {
        try {
            TemplatePayload.Template template = jsonMapper.readValue(json, TemplatePayload.Template.class);
            return TemplatePayload.builder().template(template).variants(new ArrayList<>()).build();
        } catch (Exception e) {
            throw new IllegalStateException("Invalid active template JSON", e);
        }
    }


    private List<VariantDto> fetchVariantsAsDtos(String templateId) {
        return versioning.fetchVariantsAsDtos(templateId);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public TemplateRequest processRequest(ProcessTemplateRequestDto dto, String executorId) throws JacksonException {
        TemplateRequest request = templateRequestRepository.findById(dto.getRequestId()).orElseThrow(() -> new TemplateNotFoundException("Request not found: " + dto.getRequestId()));

        if (executorId.equals(request.getCreatorId())) {
            throw new IllegalStateException("Self-approval is not allowed");
        }

        if (request.getReqStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Request already processed");
        }

        if (dto.getStatus() != RequestStatus.ACCEPTED && dto.getStatus() != RequestStatus.REJECTED) {
            throw new IllegalArgumentException("Only ACCEPTED or REJECTED is allowed for processing");
        }

        request.setExecutorId(executorId);
        request.setExecutorRemarks(dto.getRemarks());
        request.setExecutionDate(LocalDateTime.now(IST_ZONE));
        request.setReqStatus(dto.getStatus());


        if (dto.getStatus() == RequestStatus.ACCEPTED) {
//            TemplatePayload payload = jsonMapper.readValue(request.getPayload(), TemplatePayload.class);
            List<String> affectedTemplateIds = switch (request.getChangeType()) {
                case ADD -> handleCreate(request);
                case UPDATE -> handleUpdate(request);
                case DELETE -> handleDelete(request);
                case STATUS -> handleStatusChange(request);
                case ROLLBACK -> handleRollback(request);
                default ->
                        throw new UnsupportedOperationException("Unsupported changeType: " + request.getChangeType());
            };
            // Evict Report Builder's Redis cache for every templateId touched by this approval,
            // only after this transaction has really committed.
            cacheEvictor.evictAfterCommit(affectedTemplateIds);
            request.setExecutionRemarks("Successfully processed approval.");
        } else {
            request.setExecutionRemarks("Request rejected.");
        }

        return templateRequestRepository.save(request);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public TemplateRequest cancelRequest(CancelTemplateRequestDto dto, String userId) {
        TemplateRequest request = templateRequestRepository.findById(dto.getRequestId()).orElseThrow(() -> new TemplateNotFoundException("Request not found: " + dto.getRequestId()));

        if (!request.getCreatorId().equals(userId)) {
            throw new AccessDeniedException("You can only cancel your own requests");
        }

        if (request.getReqStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Only pending requests can be cancelled");
        }

        request.setReqStatus(RequestStatus.CANCELLED);
        request.setExecutorId(userId);
        request.setExecutionDate(LocalDateTime.now(IST_ZONE));
        request.setExecutorRemarks("CANCELLED BY USER: " + (dto.getRemarks() != null ? dto.getRemarks() : "No remarks"));
        return templateRequestRepository.save(request);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TemplateRequest modifyRequest(TemplateRequestModifyDto dto, String userId) {
        TemplateRequest request = templateRequestRepository.findById(dto.getRequestId()).orElseThrow(() -> new TemplateNotFoundException("Request not found: " + dto.getRequestId()));

        if (!request.getCreatorId().equals(userId)) {
            throw new AccessDeniedException("You can only modify your own requests");
        }

        if (!(request.getReqStatus() == RequestStatus.PENDING || request.getReqStatus() == RequestStatus.REJECTED)) {
            throw new IllegalStateException("Only pending or rejected requests can be modified");
        }

        request.setPayload(jsonMapper.writeValueAsString(dto.getPayload()));
        Optional.ofNullable(dto.getPayload().getRemarks()).ifPresent(request::setRemarks);
        return request;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TemplateRequestSummaryDto> getMyRequests(String userId) {
        return templateRequestRepository.findByCreatorId(userId).stream().filter(r -> r.getChangeType() != ChangeType.CGL_MAP).map(this::mapToSummaryDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<TemplateRequestSummaryDto> getPendingRequests(String userId) {
        return templateRequestRepository.findByCreatorIdNotAndReqStatus(userId, RequestStatus.PENDING).stream().filter(r -> r.getChangeType() != ChangeType.CGL_MAP).map(this::mapToSummaryDto).toList();
    }

    private List<String> handleCreate(TemplateRequest request) {
        TemplatePayload payload = jsonMapper.readValue(request.getPayload(), TemplatePayload.class);
        LocalDateTime now = LocalDateTime.now(IST_ZONE);
        String reportId = payload.getTemplate().getReportMeta().getReportId();
        int incomingVersion = parseVersion(payload.getTemplate().getTemplateMeta().getVersion());
        String templateJson = serialize(payload.getTemplate());

        List<String> affectedTemplateIds = new ArrayList<>();

        reportTemplateRepository.lockActiveByReportId(reportId).stream().findFirst().ifPresent(existing -> {
            writeGuard.assertNoCglLosesAllMappings(reportId, existing.getTemplateJson(), templateJson);
            affectedTemplateIds.add(existing.getTemplateId());
            versioning.archive(existing, request.getExecutorId(), now);
            deleteVariants(existing.getTemplateId());
            reportTemplateRepository.delete(existing);
        });

        ReportTemplate template = ReportTemplate.builder().reportId(reportId).templateName(payload.getTemplate().getReportMeta().getReportName()).description(payload.getTemplate().getTemplateMeta().getDescription()).versionNo(incomingVersion).status("ACTIVE").templateJson(templateJson).createdAt(now).createdBy(request.getCreatorId()).updatedAt(now).updatedBy(request.getExecutorId()).remarks(request.getRemarks()).sourceReqId(request.getReqId()).build();

        ReportTemplate saved = reportTemplateRepository.save(template);
        saveVariants(payload, saved, request, now);

        affectedTemplateIds.add(saved.getTemplateId());
        return affectedTemplateIds;
    }

    private List<String> handleUpdate(TemplateRequest request) {
        TemplatePayload payload = jsonMapper.readValue(request.getPayload(), TemplatePayload.class);
        String targetId = request.getTargetId();
        if (!StringUtils.hasText(targetId)) {
            throw new BadRequestException("targetId required for UPDATE");
        }

        LocalDateTime now = LocalDateTime.now(IST_ZONE);

        ReportTemplate template = reportTemplateRepository.lockByReportId(targetId).stream().findFirst().orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + targetId));

        if (cglMappingProperties.isStaleGuardEnabled()) {
            int baseVersion = parseVersion(payload.getTemplate().getTemplateMeta().getVersion());
            if (baseVersion != template.getVersionNo()) {
                throw new BadRequestException("Template " + targetId + " is now at version " + template.getVersionNo()
                        + " but this request was prepared on version " + baseVersion
                        + " (changed by another approval, e.g. a CGL mapping). Modify the request on the latest version and resubmit.");
            }
        }
        writeGuard.assertNoCglLosesAllMappings(template.getReportId(), template.getTemplateJson(), serialize(payload.getTemplate()));

        versioning.archive(template, request.getExecutorId(), now);
        int newVersion = versioning.nextVersion(template);

        payload.getTemplate().getTemplateMeta().setVersion(String.valueOf(newVersion));
        template.setReportId(payload.getTemplate().getReportMeta().getReportId());
        template.setTemplateName(payload.getTemplate().getReportMeta().getReportName());
        template.setDescription(payload.getTemplate().getTemplateMeta().getDescription());
        template.setRemarks(payload.getRemarks());
        template.setTemplateJson(serialize(payload.getTemplate()));
        template.setVersionNo(newVersion);
        template.setUpdatedAt(now);
        template.setUpdatedBy(request.getExecutorId());
        template.setSourceReqId(request.getReqId());

        ReportTemplate savedTemplate = reportTemplateRepository.save(template);
        deleteVariants(savedTemplate.getTemplateId());
        saveVariants(payload, savedTemplate, request, now);

        return List.of(savedTemplate.getTemplateId());
    }

    @Transactional
    private List<String> handleRollback(TemplateRequest request) {
        TemplateRollbackRequestDto payload = jsonMapper.readValue(request.getPayload(), TemplateRollbackRequestDto.class);
        String targetId = request.getTargetId();
        if (!StringUtils.hasText(targetId)) {
            throw new BadRequestException("targetId required for UPDATE");
        }

        LocalDateTime now = LocalDateTime.now(IST_ZONE);
        ReportTemplate template = reportTemplateRepository.lockByReportId(targetId).stream().findFirst().orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + targetId));

        versioning.archive(template, request.getExecutorId(), now);
        log.info("Archived active template!");

        int version = Integer.parseInt(payload.getRollbackTo());
        JsonNode templateNode = payload.getTemplate();
        log.info(templateNode.toString());

        JsonNode templateIdNode = templateNode.path("templateMeta").path("templateId");
        if (templateIdNode.isMissingNode()) {
            log.info("Reverting changes!");
            throw new BadRequestException("Template ID not found in payload!");
        }
        ReportTemplateHistory templateHistory = (ReportTemplateHistory) reportTemplateHistoryRepository.findByTemplateIdAndVersionNo(templateIdNode.asString(), version).orElseThrow(() -> new TemplateNotFoundException(templateIdNode.asString()));
        String variants = templateHistory.getVariantsJson();
        writeGuard.assertNoCglLosesAllMappings(template.getReportId(), template.getTemplateJson(), templateHistory.getTemplateJson());

        ReportTemplate rollbackedTemplate = reportTemplateRepository.lockByReportId(targetId).stream().findFirst()
                .orElseThrow(() -> new TemplateNotFoundException(templateIdNode.asString()));
        rollbackedTemplate.setVersionNo(templateHistory.getVersionNo());
        rollbackedTemplate.setTemplateJson(templateHistory.getTemplateJson());
        rollbackedTemplate.setCreatedAt(templateHistory.getCreatedAt());
        rollbackedTemplate.setCreatedBy(templateHistory.getCreatedBy());
        rollbackedTemplate.setCreatedFrom(templateHistory.getVersionNo());
        rollbackedTemplate.setSourceReqId(request.getReqId());
        rollbackedTemplate.setRemarks(Optional.ofNullable(templateHistory.getRemarks()).orElse("")+ "[" + payload.getRemarks() + "]");

        deleteVariants(templateIdNode.asString());
        List<VariantDto> variantList = jsonMapper.readValue(variants, new TypeReference<ArrayList<VariantDto>>() {
        });

        saveVariants(templateIdNode.asString(), variantList, request, now);
        log.info("Rollbacked Template Successfully!");

        return List.of(rollbackedTemplate.getTemplateId());
    }


    private List<String> handleDelete(TemplateRequest request) {
        String targetId = request.getTargetId();
        if (!StringUtils.hasText(targetId)) {
            throw new BadRequestException("targetId required for DELETE");
        }

        LocalDateTime now = LocalDateTime.now(IST_ZONE);
        ReportTemplate template = reportTemplateRepository.lockByReportId(targetId).stream().findFirst().orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + targetId));

        String templateId = template.getTemplateId();
        writeGuard.assertNoCglLosesAllMappings(template.getReportId(), template.getTemplateJson(), null);

        versioning.archive(template, request.getExecutorId(), now);
        deleteVariants(templateId);
        reportTemplateRepository.delete(template);

        return List.of(templateId);
    }

    private List<String> handleStatusChange(TemplateRequest request) {
        TemplateStatusRequest payload = jsonMapper.readValue(request.getPayload(), TemplateStatusRequest.class);
        String targetId = request.getTargetId();
        if (!StringUtils.hasText(targetId)) {
            throw new BadRequestException("targetId required for DELETE");
        }

        LocalDateTime now = LocalDateTime.now(IST_ZONE);
        ReportTemplate template = reportTemplateRepository.lockByReportId(targetId).stream().findFirst().orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + targetId));
        template.setStatus(payload.getStatus().name());
        reportTemplateRepository.save(template);

        return List.of(template.getTemplateId());
    }

    private void saveVariants(TemplatePayload payload, ReportTemplate template, TemplateRequest request, LocalDateTime now) {
        if (payload.getVariants() == null) {
            return;
        }

        for (VariantDto variantDto : payload.getVariants()) {
            ReportVariant variant = ReportVariant.builder().templateId(template.getTemplateId()).variantCode(variantDto.getVariantCode()).variantName(variantDto.getVariantName()).description(variantDto.getDescription()).status(variantDto.getStatus()).createdAt(now).createdBy(request.getCreatorId()).updatedAt(now).updatedBy(request.getExecutorId()).build();

            ReportVariant savedVariant = variantRepository.saveAndFlush(variant);

            if (variantDto.getParams() != null) {
                for (VariantParamDto paramDto : variantDto.getParams()) {
                    VariantParamDef param = VariantParamDef.builder().reportVariant(savedVariant).paramName(paramDto.getParamName()).label(paramDto.getLabel()).paramType(paramDto.getParamType()).required(paramDto.isRequired() ? "Y" : "N").multiVal(paramDto.isMultiValued() ? "Y" : "N").uiHint(paramDto.getUiHint()).validation(paramDto.getValidation()).createdAt(now).build();
                    paramRepository.save(param);
                }
            }

            if (variantDto.getFilterRules() != null) {
                for (FilterRuleDto ruleDto : variantDto.getFilterRules()) {
                    FilterRule filterRule = FilterRule.builder().reportVariant(savedVariant).dbColumn(ruleDto.getDbColumn()).operator(ruleDto.getOperator()).paramName(ruleDto.getParamName()).scopeType(ruleDto.getScopeType()).scopeValue(ruleDto.getScopeValue()).createdAt(now).build();
                    filterRuleRepository.save(filterRule);
                }
            }
        }
    }

    private void saveVariants(String templateId, List<VariantDto> variants, TemplateRequest request, LocalDateTime now) {
        for (VariantDto variantDto : variants) {
            ReportVariant variant = ReportVariant.builder().templateId(templateId).variantCode(variantDto.getVariantCode()).variantName(variantDto.getVariantName()).description(variantDto.getDescription()).status(variantDto.getStatus()).createdAt(now).createdBy(request.getCreatorId()).updatedAt(now).updatedBy(request.getExecutorId()).build();

            ReportVariant savedVariant = variantRepository.saveAndFlush(variant);

            if (variantDto.getParams() != null) {
                for (VariantParamDto paramDto : variantDto.getParams()) {
                    VariantParamDef param = VariantParamDef.builder().reportVariant(savedVariant).paramName(paramDto.getParamName()).label(paramDto.getLabel()).paramType(paramDto.getParamType()).required(paramDto.isRequired() ? "Y" : "N").multiVal(paramDto.isMultiValued() ? "Y" : "N").uiHint(paramDto.getUiHint()).validation(paramDto.getValidation()).createdAt(now).build();
                    paramRepository.save(param);
                }
            }

            if (variantDto.getFilterRules() != null) {
                for (FilterRuleDto ruleDto : variantDto.getFilterRules()) {
                    FilterRule filterRule = FilterRule.builder().reportVariant(savedVariant).dbColumn(ruleDto.getDbColumn()).operator(ruleDto.getOperator()).paramName(ruleDto.getParamName()).scopeType(ruleDto.getScopeType()).scopeValue(ruleDto.getScopeValue()).createdAt(now).build();
                    filterRuleRepository.save(filterRule);
                }
            }
        }
    }


    private void deleteVariants(String templateId) {
        List<ReportVariant> variants = variantRepository.findByTemplateId(templateId);
        if (variants.isEmpty()) {
            return;
        }

        for (ReportVariant variant : variants) {
            Long variantId = variant.getVariantId();
            paramRepository.deleteByVariantId(variantId);
            filterRuleRepository.deleteByVariantId(variantId);
            variantRepository.delete(variant);
        }

        paramRepository.flush();
        filterRuleRepository.flush();
        variantRepository.flush();
    }

    private String serialize(Object obj) {
        try {
            return jsonMapper.writeValueAsString(obj);
        } catch (JacksonException e) {
            throw new BadRequestException("Failed to serialize template json");
        }
    }

    private TemplateRequestSummaryDto mapToSummaryDto(TemplateRequest request) {
        Map<String, String> summary = new HashMap<>();
        try {
            JsonNode root = jsonMapper.readTree(request.getPayload());
            JsonNode templateMeta = root.path("template").path("templateMeta");
            JsonNode reportMeta = root.path("template").path("reportMeta");
            summary.put("templateId", text(templateMeta, "templateId"));
            summary.put("reportId", text(reportMeta, "reportId"));
            summary.put("version", text(templateMeta, "version"));
            summary.put("reportName", text(reportMeta, "reportName"));
            summary.put("remarks", text(root, "remarks"));
            if (!text(root, "status").isEmpty()) {
                summary.put("newStatus", text(root, "status"));
            }
        } catch (Exception e) {
            log.warn("Unable to parse request payload for summary. reqId={}", request.getReqId(), e);
            summary = Map.of();
        }

        return TemplateRequestSummaryDto.builder().id(request.getReqId()).changeType(request.getChangeType()).reqStatus(request.getReqStatus()).reqDate(request.getReqDate()).creatorId(request.getCreatorId()).targetId(request.getTargetId()).remarks(request.getRemarks()).executionDate(request.getExecutionDate()).executorId(request.getExecutorId()).executorRemarks(request.getExecutorRemarks()).summary(summary).build();
    }

    private int parseVersion(String version) {
        if (!StringUtils.hasText(version)) {
            return 1;
        }
        try {
            return Integer.parseInt(version.trim());
        } catch (NumberFormatException ex) {
            return 1;
        }
    }

    private String text(JsonNode node, String field) {
        JsonNode val = node.path(field);
        return val.isMissingNode() || val.isNull() ? "" : val.asText("");
    }

    @Override
    @Transactional
    public TemplateRequest updateStatus(TemplateStatusRequest statusRequest, String token, String creatorId) {
        businessSecurityService.validateUserAction(token, ChangeType.UPDATE);
        String targetId = statusRequest.getTargetId();
        List<TemplateRequest> duplicates = templateRequestRepository.findByTargetIdAndReqStatusAndChangeType(targetId, RequestStatus.PENDING, ChangeType.STATUS);
        if (!duplicates.isEmpty()) {
            throw new DataIntegrityViolationException("A pending request for this template status change already exists.");
        }

        TemplateRequest newRequest = TemplateRequest.builder()
                .creatorId(creatorId)
                .changeType(ChangeType.STATUS)
                .reqStatus(RequestStatus.PENDING)
                .reqDate(LocalDateTime.now(IST_ZONE))
                .payload(jsonMapper.writeValueAsString(statusRequest))
                .targetId(targetId)
                .remarks(statusRequest.getRemarks()).
                build();
        return templateRequestRepository.save(newRequest);
    }


    @Override
    @Transactional
    public TemplateRequest rollbackTemplate(TemplateRollbackRequestDto request, String token, String creatorId) {
        businessSecurityService.validateUserAction(token, ChangeType.ROLLBACK);
        String targetId = request.getTargetId();
        List<TemplateRequest> duplicates = templateRequestRepository.findByTargetIdAndReqStatus(targetId, RequestStatus.PENDING);
        if (!duplicates.isEmpty()) {
            throw new DataIntegrityViolationException("A pending request for this template already exists.");
        }
        TemplateRequest newRequest = TemplateRequest.builder()
                .creatorId(creatorId)
                .changeType(ChangeType.ROLLBACK)
                .reqStatus(RequestStatus.PENDING)
                .reqDate(LocalDateTime.now(IST_ZONE))
                .payload(jsonMapper.writeValueAsString(request))
                .targetId(targetId)
                .remarks(request.getRemarks()).
                build();
        return templateRequestRepository.save(newRequest);
    }

    @Override
    public String getRequestTemplate(long requestId) {
        TemplateRequest request= templateRequestRepository.findById(requestId).get();
        return request.getPayload();
    }

//    @Override
//    @Transactional
//    public void cancelRequest(long requestId, String token, String executorId) {
//        businessSecurityService.validateUserAction(token, ChangeType.ROLLBACK);
//        TemplateRequest request= (TemplateRequest) templateRequestRepository.findById(requestId).orElseThrow();
//        if(!request.getCreatorId().equals(executorId)){
//          throw new BadRequestException("A user can't cancel another user's request!");
//        }
//        request.setReqStatus(RequestStatus.CANCELLED);
//    }


}