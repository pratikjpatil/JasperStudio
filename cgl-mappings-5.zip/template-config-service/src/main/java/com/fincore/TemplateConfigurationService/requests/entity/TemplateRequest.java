package com.fincore.TemplateConfigurationService.requests.entity;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "RB_TEMPLATE_REQUEST")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rb_template_request_seq_gen")
    @SequenceGenerator(name = "rb_template_request_seq_gen", sequenceName = "RB_TEMPLATE_REQUEST_SEQ", allocationSize = 1)
    @Column(name = "REQ_ID", nullable = false)
    private Long reqId;

    @Column(name = "CHANGE_TYPE", nullable = false, length = 2)
    private ChangeType changeType;

    @Column(name = "REQ_STATUS", nullable = false, length = 2)
    private RequestStatus reqStatus;

    @Column(name = "REQ_DATE", nullable = false)
    private LocalDateTime reqDate;

    @Column(name = "CREATOR_ID", nullable = false, length = 12)
    private String creatorId;

    @Column(name = "EXECUTION_DATE")
    private LocalDateTime executionDate;

    @Lob
    @Column(name = "EXECUTION_REMARKS")
    private String executionRemarks;

    @Column(name = "EXECUTOR_ID", length = 12)
    private String executorId;

    @Column(name = "EXECUTOR_REMARKS", length = 500)
    private String executorRemarks;

    @Lob
    @Column(name = "PAYLOAD", nullable = false)
    private String payload;

    @Column(name = "TARGET_ID", length = 4000)
    private String targetId;

    @Column(name = "REMARKS", length = 500)
    private String remarks;

    @JsonRawValue
    public String getPayload() {
        return payload;
    }

    /** External reference, e.g. COMMON_REQ.REQ_ID for CGL_MAP rows. Unique together with TARGET_ID when present. */
    @Column(name = "SOURCE_REF", length = 50)
    private String sourceRef;
}
