package com.fincore.TemplateConfigurationService.requests.repository;

import com.fincore.TemplateConfigurationService.requests.entity.TemplateRequest;
import com.fincore.TemplateConfigurationService.requests.enums.ChangeType;
import com.fincore.TemplateConfigurationService.requests.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;


import java.util.List;

public interface TemplateRequestRepository extends JpaRepository<TemplateRequest, Long> {

    List<TemplateRequest> findByCreatorId(String creatorId);

    List<TemplateRequest> findByCreatorIdNotAndReqStatus(String creatorId, RequestStatus status);

    List<TemplateRequest> findByTargetIdAndReqStatus(String targetId, RequestStatus status);

    List<TemplateRequest> findByTargetIdAndReqStatusAndChangeType(String targetId, RequestStatus status, ChangeType type);

    List<TemplateRequest> findBySourceRefAndChangeType(String sourceRef, ChangeType changeType);

    /** Row-locking variant: serialises concurrent confirm/revert of the same CGL request. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "15000"))
    @Query("select r from TemplateRequest r where r.sourceRef = :sourceRef and r.changeType = :changeType")
    List<TemplateRequest> lockBySourceRefAndChangeType(@Param("sourceRef") String sourceRef,
                                                       @Param("changeType") ChangeType changeType);

    List<TemplateRequest> findByChangeTypeAndReqStatusAndExecutorRemarksAndExecutionDateBetween(
            ChangeType changeType, RequestStatus reqStatus, String executorRemarks,
            LocalDateTime from, LocalDateTime to);
}
