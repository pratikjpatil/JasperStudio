package com.fincore.TemplateConfigurationService.cglmapping;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Configuration for the CGL -> template mapping feature (application.properties, prefix "cgl.mapping").
 * Per-report parsing rules live here (no DB table): which column is Head, which variable types are eligible, etc.
 * Override any default from properties, e.g.
 *   cgl.mapping.reports.PFORM.head-column=Particulars
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "cgl.mapping")
public class CglMappingProperties {

    /** Oracle limits IN lists to 1000 expressions (ORA-01795). */
    private int maxInValues = 1000;

    /**
     * What to do when removing a CGL would leave a variable with an empty CGL list.
     * BLOCK (default) refuses. ALLOW_EMPTY keeps the filter with an empty value list; choose it only after
     * confirming the report engine treats an empty IN list as no rows.
     */
    private String emptyListPolicy = "BLOCK";

    /** Block template update/rollback/delete that would leave an ACTIVE CGL without any mapping. */
    private boolean guardEnabled = false;

    /** Reject a template UPDATE approval whose base version differs from the current version. */
    private boolean staleGuardEnabled = false;

    private boolean reconcileEnabled = true;
    private long reconcileIntervalMs = 120_000L;
    /** Must be larger than the CRS transaction timeout. */
    private int reconcileGraceMinutes = 10;
    private int reconcileLookbackHours = 48;

    private Map<String, ReportRule> reports = defaultRules();

    public Optional<ReportRule> rule(String reportId) {
        if (reportId == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(reports.get(reportId.trim().toUpperCase()));
    }

    private static Map<String, ReportRule> defaultRules() {
        Map<String, ReportRule> m = new LinkedHashMap<>();
        m.put("NWSA", ReportRule.of("DESCRIPTION", "CODE NO.", null, "ARRAY", "DB_SUM"));
        m.put("YSA", ReportRule.of("NOMENCLATURE", "YSA CODE", null, "OBJECT", "DB_SUM"));
        m.put("PNL", ReportRule.of("Head", "Sr. no.", "Sub Head", "ARRAY", "DB_SUM", "DB_AVG"));
        // PFORM: no sample structure seen yet. Configure head-column / code-column before enabling.
        m.put("PFORM", ReportRule.of("Head", "Sr. no.", null, "ARRAY", "DB_SUM"));
        return m;
    }

    @Getter
    @Setter
    public static class ReportRule {
        /** Column NAME (not id) that holds the Head text. Matched case-insensitively against template columns. */
        private String headColumn;
        private String codeColumn;
        private String subHeadColumn;
        /** Variable types that can carry CGLs. Formula-only cells never qualify. */
        private List<String> eligibleTypes = new ArrayList<>(List.of("DB_SUM"));
        /** Shape used when the CGL filter does not exist yet: ARRAY = [{op,value}], OBJECT = {op,value}. */
        private String filterShape = "ARRAY";
        /** Also treat DB_* cells with a 'source' block as targets (variableName is empty for those). */
        private boolean includeCellSource = false;
        private String filterKey = "CGL";

        static ReportRule of(String head, String code, String sub, String shape, String... types) {
            ReportRule r = new ReportRule();
            r.headColumn = head;
            r.codeColumn = code;
            r.subHeadColumn = sub;
            r.filterShape = shape;
            r.eligibleTypes = new ArrayList<>(List.of(types));
            return r;
        }
    }
}
