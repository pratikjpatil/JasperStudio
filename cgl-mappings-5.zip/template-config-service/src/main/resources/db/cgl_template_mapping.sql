-- CGL -> template mapping: schema changes (columns only, no new tables)
-- Run once per environment before deploying template-config-service.

-- Version -> request link (which request produced this version)
ALTER TABLE RB_REPORT_TEMPLATE          ADD (SOURCE_REQ_ID NUMBER);
ALTER TABLE RB_REPORT_TEMPLATE_HISTORY  ADD (SOURCE_REQ_ID NUMBER);

-- External reference for audit rows written by the CGL flow (COMMON_REQ.REQ_ID) + idempotency
ALTER TABLE RB_TEMPLATE_REQUEST         ADD (SOURCE_REF VARCHAR2(50));

-- One audit row per (CGL request, report). Function-based so NULL SOURCE_REF rows are unconstrained.
-- CGL revert rows use SOURCE_REF = '<reqId>R'.
CREATE UNIQUE INDEX UX_TPL_REQ_SOURCE_REF
    ON RB_TEMPLATE_REQUEST (CASE WHEN SOURCE_REF IS NOT NULL THEN SOURCE_REF || '|' || SUBSTR(TARGET_ID, 1, 200) END);

-- Fast lookup for the reconciler
CREATE INDEX IX_TPL_REQ_CHANGE_STATUS ON RB_TEMPLATE_REQUEST (CHANGE_TYPE, REQ_STATUS, EXECUTION_DATE);

-- CHANGE_TYPE is VARCHAR2(2); the new value 'CM' (CGL_MAP) fits. No constraint change needed
-- unless a CHECK constraint exists on CHANGE_TYPE: in that case add 'CM' to it.
