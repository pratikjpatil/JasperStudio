package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingProperties.ReportRule;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads and edits the CGL IN-filter of a "carrier" node (a variable definition, or a DB_* cell 'source').
 *
 * Handles the shapes seen in real templates:
 *   filters.CGL = [ { "op":"IN", "value":[...] } ]     (array of filters: NWSA, PNL)
 *   filters.CGL =   { "op":"IN", "value":[...] }       (single object:    YSA)
 *   filters.CGL absent                                  (created in the report's native shape)
 * Every other filter (e.g. CURRENCY) is left untouched. Unknown shapes are refused, never rewritten.
 */
@Component
@RequiredArgsConstructor
public class CglFilterCodec {

    private final JsonMapper jsonMapper;
    private final CglMappingProperties props;

    /** CGL values currently in the IN filter; empty when absent or when the shape is not supported. */
    public List<String> read(ObjectNode carrier, ReportRule rule) {
        try {
            ObjectNode in = findInFilter(carrier.get("filters"), rule.getFilterKey());
            if (in == null) {
                return List.of();
            }
            return valuesAsList(in.get("value"));
        } catch (CglMappingException e) {
            return List.of();
        }
    }

    /** Adds the CGL. Returns false when it was already present. */
    public boolean add(ObjectNode carrier, String cgl, ReportRule rule) {
        String key = rule.getFilterKey();
        JsonNode existingFilters = carrier.get("filters");
        ObjectNode filters;
        if (existingFilters == null || existingFilters.isNull()) {
            filters = carrier.putObject("filters");
        } else if (existingFilters.isObject()) {
            filters = (ObjectNode) existingFilters;
        } else {
            throw new CglMappingException("UNSUPPORTED_FILTER_SHAPE", "'filters' is not an object");
        }

        ObjectNode in = findInFilter(filters, key);
        if (in == null) {
            ObjectNode created = jsonMapper.createObjectNode();
            created.put("op", "IN");
            ArrayNode values = jsonMapper.createArrayNode();
            values.add(cgl);
            created.set("value", values);

            JsonNode current = filters.get(key);
            if (current != null && current.isArray()) {
                ((ArrayNode) current).add(created);
            } else if ("OBJECT".equalsIgnoreCase(rule.getFilterShape())) {
                filters.set(key, created);
            } else {
                ArrayNode wrapper = jsonMapper.createArrayNode();
                wrapper.add(created);
                filters.set(key, wrapper);
            }
            return true;
        }

        ArrayNode values = valuesAsArray(in);
        for (JsonNode v : values) {
            if (cgl.equals(v.asString())) {
                return false;
            }
        }
        if (values.size() >= props.getMaxInValues()) {
            throw new CglMappingException("IN_LIST_LIMIT",
                    "CGL list would exceed " + props.getMaxInValues() + " values (Oracle IN-list limit)");
        }
        values.add(cgl);
        return true;
    }

    /**
     * Removes the CGL. Returns false when it was not present.
     * When the list would become empty: refused (EMPTY_IN_LIST) unless allowEmpty, in which case the
     * whole CGL filter is dropped (used when reverting a filter this feature created).
     */
    public boolean remove(ObjectNode carrier, String cgl, ReportRule rule, boolean allowEmpty) {
        String key = rule.getFilterKey();
        JsonNode filters = carrier.get("filters");
        ObjectNode in = findInFilter(filters, key);
        if (in == null) {
            return false;
        }
        ArrayNode values = valuesAsArray(in);
        boolean removed = false;
        for (int i = values.size() - 1; i >= 0; i--) {
            if (cgl.equals(values.get(i).asString())) {
                values.remove(i);
                removed = true;
            }
        }
        if (!removed) {
            return false;
        }
        if (values.isEmpty()) {
            if (!allowEmpty) {
                throw new CglMappingException("EMPTY_IN_LIST",
                        "Removing CGL " + cgl + " would leave an empty CGL list on this variable");
            }
            ((ObjectNode) filters).remove(key);
        }
        return true;
    }

    // ------------------------------------------------------------------

    private ObjectNode findInFilter(JsonNode filters, String key) {
        if (filters == null || !filters.isObject()) {
            return null;
        }
        JsonNode f = filters.get(key);
        if (f == null || f.isNull()) {
            return null;
        }
        if (f.isObject()) {
            if (isIn(f)) {
                return (ObjectNode) f;
            }
            throw new CglMappingException("UNSUPPORTED_FILTER_SHAPE", key + " filter is not an IN filter");
        }
        if (f.isArray()) {
            ObjectNode found = null;
            for (JsonNode el : f) {
                if (el.isObject() && isIn(el)) {
                    if (found != null) {
                        throw new CglMappingException("UNSUPPORTED_FILTER_SHAPE", "multiple IN filters on " + key);
                    }
                    found = (ObjectNode) el;
                } else {
                    throw new CglMappingException("UNSUPPORTED_FILTER_SHAPE", key + " has a non-IN filter entry");
                }
            }
            return found;
        }
        throw new CglMappingException("UNSUPPORTED_FILTER_SHAPE", key + " filter has unexpected type");
    }

    private boolean isIn(JsonNode filter) {
        JsonNode op = filter.get("op");
        return op != null && "IN".equalsIgnoreCase(op.asString());
    }

    private List<String> valuesAsList(JsonNode value) {
        List<String> out = new ArrayList<>();
        if (value == null || value.isNull()) {
            return out;
        }
        if (value.isArray()) {
            for (JsonNode v : value) {
                out.add(v.asString());
            }
        } else {
            out.add(value.asString());
        }
        return out;
    }

    /** Returns the 'value' array of an IN filter, converting a scalar value to a one-element array in place. */
    private ArrayNode valuesAsArray(ObjectNode in) {
        JsonNode value = in.get("value");
        if (value != null && value.isArray()) {
            return (ArrayNode) value;
        }
        ArrayNode arr = jsonMapper.createArrayNode();
        if (value != null && !value.isNull()) {
            arr.add(value.asString());
        }
        in.set("value", arr);
        return arr;
    }
}
