package com.fincore.TemplateConfigurationService.cglmapping;

import com.fincore.TemplateConfigurationService.cglmapping.CglMappingDtos.*;
import com.fincore.commonutilities.jwt.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * CGL mapping API. Called by the Common Request Service with the checker's own JWT forwarded,
 * so the existing authentication filter and audit user resolution apply unchanged.
 */
@Slf4j
@RestController
@RequestMapping("/api/template-config/cgl-mappings")
@RequiredArgsConstructor
public class CglMappingController {

    private final CglMappingService service;
    private final JwtUtil jwtUtil;

    /** Picker for the maker: eligible Head/Variable targets of the ACTIVE template of a report. */
    @GetMapping("/targets")
    public List<Target> targets(@RequestParam String reportId, @RequestParam(required = false) String q) {
        return service.listTargets(reportId, q);
    }

    /** Dry run at maker submit. */
    @PostMapping("/validate")
    public ValidateResponse validate(@RequestBody ValidateRequest request) {
        return service.validate(request);
    }

    /** Idempotent on commonReqId. Executes in one transaction across all affected templates. */
    @PostMapping("/apply")
    public ApplyResult apply(@Valid @RequestBody ApplyRequest request,
                             @RequestHeader("Authorization") String token) {
        String checkerId = jwtUtil.getUserIdFromToken(token);
        log.info("CGL mapping apply: cgl={}, commonReqId={}, checker={}", request.getCglNumber(),
                request.getCommonReqId(), checkerId);
        return service.apply(request, checkerId);
    }

    /** Active CGLs that are not mapped anywhere yet (legacy gap list before enforcing mapping). */
    @GetMapping("/unmapped")
    public List<String> unmapped() {
        return service.unmappedActiveCgls();
    }

    /** Current mappings of a CGL (pre-fills the CGL update screen). */
    @GetMapping("/by-cgl/{cglNumber}")
    public List<Target> byCgl(@PathVariable String cglNumber) {
        return service.mappingsOfCgl(cglNumber);
    }
}
