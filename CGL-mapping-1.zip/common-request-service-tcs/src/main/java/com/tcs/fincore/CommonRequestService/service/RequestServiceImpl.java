package com.tcs.fincore.CommonRequestService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.fincore.CommonRequestService.dto.*;
import com.tcs.fincore.CommonRequestService.dto.payload.KeyablePayload;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import com.tcs.fincore.CommonRequestService.exception.ResourceNotFoundException;
import com.tcs.fincore.CommonRequestService.model.CGLMaster;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.ChangeType;
import com.tcs.fincore.CommonRequestService.model.enums.RequestStatus;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;
import com.tcs.fincore.CommonRequestService.repository.CommonRequestRepository;
import com.tcs.fincore.CommonRequestService.service.strategy.RequestStrategyFactory;
//import com.tcs.fincore.CommonRequestService.service.strategy.RequestTypeStrategy;
//import com.tcs.fincore.CommonRequestService.service.strategy.RequestTypeStrategyResolver;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class RequestServiceImpl implements RequestService {

    private static final String EVENT_SOURCE = "CommonRequestService";
    private final CommonRequestRepository commonRequestRepository;
    private final RequestStrategyFactory strategyFactory;
    private final ObjectMapper objectMapper;
    private final NotificationWriterService notificationWriterService;
    private final PermissionConfigService permissionConfigService;
    private final BusinessSecurityService businessSecurityService;
    //private final RequestTypeStrategyResolver requestTypeStrategyResolver;

    @Override
    @Transactional(rollbackOn = Exception.class) // Ensure rollback on any exception
    public CommonReq createRequest(
            CreateRequestDto dto,
            String creatorId,
            String token
    ) throws JsonProcessingException {


        // --- LAYER 2 SECURITY CHECK --- (rbac) <-------- 1st check in filter [shubhankar]
        // Validate that the user is allowed to perform this SPECIFIC ChangeType (e.g. BLOCK)
        businessSecurityService.validateUserAction(token, dto.getRequestType(), dto.getChangeType());

        // --- STRATEGIC VALIDATION -  VALIDATE MASTER DATA BEFORE PROCEEDING ---
        strategyFactory.getStrategy(dto.getRequestType()).validateRequest(dto, token);

        KeyablePayload payload = (KeyablePayload) dto.getPayload();

        // --- PRE CHECKS ---
        String targetId = payload.getKey();
        if (targetId == null || targetId.isBlank()) {
            throw new IllegalArgumentException("Could not determine targetId from payload.");
        }
        log.info("Determined targetId for new request as: {}", targetId);

        List<CommonReq> existingRequests = commonRequestRepository.findByTargetIdAndReqStatus(targetId,
                RequestStatus.PENDING);

        if (!existingRequests.isEmpty()) {
            log.warn("Attempted to create a duplicate request for targetId {} which already has a {} request.",
                    targetId, existingRequests.get(0).getReqStatus());
            throw new DataIntegrityViolationException(
                    "An active or pending request for '" + targetId + "' already exists.");
        }
        log.info("Uniqueness check passed for targetId: {}", targetId);

        // --- CREATE AND SAVE REQUEST ---
        CommonReq request = new CommonReq();
        request.setCreatorId(creatorId);
        request.setReqType(dto.getRequestType());
        request.setChangeType(dto.getChangeType());
        request.setPayload(objectMapper.writeValueAsString(payload));
        request.setTargetId(targetId);
        request.setReqStatus(RequestStatus.PENDING);
        // set correct time date
        request.setReqDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));


        log.info("Saving new, validated request for targetId {}", targetId);
        CommonReq savedRequest = commonRequestRepository.save(request);

        try {
            // --- NOTIFICATION LOGIC ---

            // 1. Fetch Config from CACHE (Fast)
            String requestTypeKey = dto.getRequestType().name(); // e.g., "SEGMENT_CODE"
            log.info("Request Type String to fetch role ids from PERMISSIONS: {}", requestTypeKey);
            NotificationConfigDto config = permissionConfigService.getConfig(requestTypeKey);

            // 2. Customize Message
            String action = request.getChangeType().name(); // ADD/ DELETE/ UPDATE / BLOCK

            // Validate payload to detect "Block", "UNBLOCK action
            if (request.getChangeType() == ChangeType.BLOCK || request.getChangeType() == ChangeType.UNBLOCK) {
                // Parse payload to check if status is 0 (Blocked)
                CGLMaster payload2 = objectMapper.readValue(request.getPayload(), CGLMaster.class);
                if (payload2.getStatus() == 0) {
                    action = "BLOCK"; // Override action name for the message
                } else if (payload2.getStatus() == 1) {
                    action = "UNBLOCK"; // Override action name for the message
                }
            }
            String message = "New " + action + " request (" + targetId + ") pending for " + dto.getRequestType();

            // 3. Send to Group (1-to-Many via Outbox)
            notificationWriterService.createNotification(
                    creatorId,                  // USER ID TO EXCLUDE FROM ROLES, IN THIS CASE ROLE WILL BE USED TO TARGET USER
                    config.getTargetRoles(),    // Group to SEND TO "51,55" (Fetched from Cache/DB)
                    message,
                    config.getTargetUrl(),      // "/segment-requests" (Fetched from Cache/DB)
                    savedRequest.getId().toString(),
                    EVENT_SOURCE
            );

        } catch (Exception e) {
            // Log the error and re-throw as a RuntimeException to force a rollback.
            log.error("CRITICAL: Failed to create 'pending' notification for request: {}. Rolling back transaction.", savedRequest.getId(), e);
            throw new RuntimeException("Failed to create notification event, rolling back request creation.", e);
        }
        return savedRequest;
    }

    @Override
    @Transactional(rollbackOn = Exception.class) // Ensure rollback on any exception
    public Optional<CommonReq> updateRequestStatus(
            ProcessRequestDto dto,
            String executorId,
            String token
    ) throws JsonProcessingException {

        Long requestId = dto.getRequestId();
        log.info("Attempting to update status for request ID: {} by executor: {}", requestId, executorId);

        CommonReq request = commonRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request with ID " + requestId + " not found."));

        // SELF-APPROVAL CHECK
        if (executorId.equals(request.getCreatorId())) {
            log.warn("SECURITY VIOLATION: User {} attempted to approve their own request (ID: {}).", executorId,
                    requestId);
            throw new IllegalStateException("User cannot approve or reject their own request.");
        }

        if (request.getReqStatus() != RequestStatus.PENDING) {
            log.warn("Attempted to modify an already processed request. ID: {}, Current Status: {}", dto.getRequestId(),
                    request.getReqStatus());
            throw new IllegalStateException("Request has already been processed and cannot be modified.");
        }

        // --- UPDATE REQUEST STATE ---
        request.setExecutorId(executorId);
        request.setExecutorRemarks(dto.getRemarks());
        request.setExecutionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
        request.setReqStatus(dto.getStatus());

        // --- PROCESS BUSINESS LOGIC (STRATEGY) & PREPARE NOTIFICATION 1: TO MAKER (1-to-1) ---
        // This is a 1-to-1, so USER_ID is the recipient, TARGET_ROLE is null.
        if (RequestStatus.ACCEPTED.equals(dto.getStatus())) {
            log.info("Request {} ACCEPTED. Applying strategy for type {}", dto.getRequestId(), request.getReqType());
            // 1. Execute the business logic (e.g., save to master table)
            strategyFactory.getStrategy(request.getReqType()).processApproval(request);

            // Notify Maker: Approved
            notificationWriterService.createRequestApprovedNotification(request, executorId);
            request.setExecutionRemarks("Successfully processed approval.");

        } else {
            log.info("Request {} REJECTED.", dto.getRequestId());

            // Notify Maker: Rejected
            notificationWriterService.createRequestRejectedNotification(request, executorId, dto.getRemarks());
            request.setExecutionRemarks("Request rejected by user.");
        }

        // --- NOTIFICATION 2: CLOSURE (1-to-Many, Filtered) ---
        // We wrap this in Try/Catch because if this fails, we do NOT want to roll back the actual Approval.
        // The approval is critical data; the "FYI" notification to the group is secondary.
        try {
            // A. Get Group Config from Cache (Zero DB Cost)
            NotificationConfigDto config = permissionConfigService.getConfig(request.getReqType().name());

            // B. Prepare Message
            String action = dto.getStatus().equals(RequestStatus.ACCEPTED) ? "Approved" : "Rejected";
            String closureMessage = "CLOSURE: Request " + request.getTargetId() + " was " + action + " by " + executorId;

            // C. Send to Group (1-to-Many)
            // Pass the CHECKER'S ID as the exclusion ID.
            notificationWriterService.createNotification(
                    executorId,                 // User to EXCLUDE
                    config.getTargetRoles(),    // // Group to SEND TO -> The same roles that received the Pending alert excluding the executor
                    closureMessage,
                    config.getTargetUrl(),      // Link to history
                    request.getId().toString(),
                    "CommonRequestService"
            );
            log.info("Sent closure notification to group for Request ID: {}", requestId);

        } catch (Exception e) {
            // Log error but allow transaction to commit
            log.error("Failed to send closure notification for Request ID: {}", requestId, e);
        }

        // --- SAVE THE UPDATED REQUEST ---
        CommonReq updatedRequest = commonRequestRepository.saveAndFlush(request);

        // --- LAST STEP BEFORE COMMIT: cross-service work (e.g. CGL -> template mapping) ---
        // Everything local is already written and flushed. If this throws, the whole approval rolls back.
        if (RequestStatus.ACCEPTED.equals(dto.getStatus())) {
            strategyFactory.getStrategy(updatedRequest.getReqType()).afterApprovalFlushed(updatedRequest, token);
        }

        return Optional.of(updatedRequest);
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public CommonReq cancelRequest(CancelRequestDto dto, String userId) {

        Long requestId = dto.getRequestId();
        log.info("Attempting to cancel request ID: {} by user: {}", requestId, userId);

        // 1. Fetch Request
        CommonReq request = commonRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request with ID " + requestId + " not found."));

        // 2. Security Check: Only the CREATOR can cancel
        if (!request.getCreatorId().equals(userId)) {
            log.warn("SECURITY VIOLATION: User {} attempted to cancel request {} owned by {}",
                    userId, requestId, request.getCreatorId());
            throw new AccessDeniedException("You are not authorized to cancel this request.");
        }

        // 3. State Check: Must be PENDING
        if (request.getReqStatus() != RequestStatus.PENDING) {
            log.warn("Attempted to cancel a processed request. ID: {}, Status: {}", requestId, request.getReqStatus());
            throw new IllegalStateException("Only pending requests can be cancelled. Current status: " + request.getReqStatus());
        }

        // 4. Update State
        request.setReqStatus(RequestStatus.CANCELLED);

        // We use Executor fields to track who cancelled it (the creator themselves)
        request.setExecutorId(userId);
        request.setExecutionDate(LocalDateTime.now());
        request.setExecutorRemarks("CANCELLED BY USER: " + (dto.getRemarks() != null ? dto.getRemarks() : "No remarks"));

        // 5. Save & Return
        CommonReq updatedRequest = commonRequestRepository.save(request);
        log.info("Request {} successfully cancelled by user.", requestId);

        return updatedRequest;
    }

    @Override
    public List<CommonReq> getMyRequests(
            String userId,
            RequestType requestType
    ) {
        if (requestType == null) {
            log.info("Request type is missing, Please provide correct request type to fetch requests for user : {}",
                    userId);
            throw new IllegalArgumentException(
                    "Request type is missing, Please provide correct request type to fetch requests.");
        }
        log.info("Fetching my requests for user {} with type {}", userId, requestType);

        List<CommonReq> requests = commonRequestRepository.findByCreatorIdAndReqType(userId, requestType);

        try{
            return strategyFactory.getStrategy(requestType).filterResponse(userId, requests);
        } catch (JsonProcessingException e) {
            log.error("Error while filtering response for requestType={}", requestType, e);
            return requests;
        }
        //return commonRequestRepository.findByCreatorIdAndReqType(userId, requestType);
    }

    @Override
    public List<CommonReq> getPendingRequests(
            String userId,
            RequestType requestType
    ) {
        if (requestType == null) {
            log.info("Request type is missing, Please provide correct request type to fetch pending requests.");
            throw new IllegalArgumentException(
                    "Request type is missing, Please provide correct request type to fetch pending requests."
            );
        }
        log.info("Fetching pending requests for user :  {} with type : {}",userId, requestType);

        List<CommonReq> requests = commonRequestRepository.findByCreatorIdNotAndReqStatusAndReqType(userId, RequestStatus.PENDING, requestType);

        try{
            return strategyFactory.getStrategy(requestType).filterResponse(userId, requests);
        } catch (JsonProcessingException e) {
            log.error("Error while filtering response for requestType={}", requestType, e);
            return requests;
        }
    }


    @Override
    public List<CommonReq> getAllRequests(
    ) {
        return commonRequestRepository.findAll();
    }

}