package com.tcs.fincore.CommonRequestService.service.strategy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;

import java.util.List;

/**
 * Strategy interface to handle the processing of different request types.
 */
public interface RequestTypeStrategy {
    /**
     * Processes the request upon approval. This typically involves saving the
     * payload data to the relevant master table.
     *
     * @param request The common request object containing the payload.
     * @throws JsonProcessingException if there is an error processing the JSON payload.
     */
    void processApproval(CommonReq request) throws JsonProcessingException;

    RequestType getRequestType();

    /**
     * Validates the payload BEFORE creating the Pending Request.
     * Default implementation does nothing (hook for strategies to override).
     */
    default void validateRequest(CreateRequestDto requestDto) throws JsonProcessingException {
        // Default: No validation. Override in specific strategies.
    }

    /**
     * Variant of {@link #validateRequest(CreateRequestDto)} that also receives the caller's JWT, for strategies
     * that must call another service during validation. Defaults to the token-less variant.
     */
    default void validateRequest(CreateRequestDto requestDto, String token) throws JsonProcessingException {
        validateRequest(requestDto);
    }

    /**
     * Called after an ACCEPTED request has been fully written and flushed in the approval transaction, as the
     * last step before commit. Strategies that must touch another service do it here: if it throws, the whole
     * approval rolls back. Default: nothing.
     */
    default void afterApprovalFlushed(CommonReq request, String token) throws JsonProcessingException {
        // Default: nothing to do.
    }

    default List<CommonReq> filterResponse(String userId, List<CommonReq> requests) throws JsonProcessingException {
        return requests;
    }
}