package com.tcs.fincore.CommonRequestService.service.strategy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingClient;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos;
import com.tcs.fincore.CommonRequestService.dto.CglPayloadDto;
import com.tcs.fincore.CommonRequestService.dto.CglTemplateMappingDto;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import com.tcs.fincore.CommonRequestService.model.enums.ChangeType;
import org.springframework.beans.factory.annotation.Value;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import com.tcs.fincore.CommonRequestService.exception.ResourceNotFoundException;
import com.tcs.fincore.CommonRequestService.model.CGLMaster;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;
import com.tcs.fincore.CommonRequestService.repository.CGLMasterRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class CglCodeStrategy implements RequestTypeStrategy {

    private final CGLMasterRepository cglMasterRepository;
    private final ObjectMapper objectMapper;
    private final TemplateBindingClient templateBindingClient;
    private static final Integer STATUS_BLOCKED = 0;

    /** When true, every CGL create / non-block update must carry at least one Head/Variable mapping. */
    @Value("${cgl.mapping.enforced:false}")
    private boolean mappingEnforced;

    @Override
    public RequestType getRequestType() {
        return RequestType.CGL_CODE;
    }

    @Override
    public void processApproval(CommonReq request) throws JsonProcessingException {
        switch (request.getChangeType()) {
            case ADD:
                handleAdd(request);
                break;
            case UPDATE:
                handleUpdate(request);
                break;
            case BLOCK:
                handleStatusChange(request, 0); // 0 = Inactive/Blocked
                break;
            case UNBLOCK:
                handleStatusChange(request, 1); // 1 = Active
                break;
            default:
                throw new UnsupportedOperationException(
                        "Change type " + request.getChangeType() + " is not supported.");
        }
    }

    private void handleAdd(CommonReq request) throws JsonProcessingException {
        CGLMaster newCgl = readMaster(request.getPayload());

        // Although the DB computes the final CGL_NUMBER, we also construct it here for
        // uniqueness
        String potentialCglNumber = newCgl.getComp1() + newCgl.getSegmentCode() + newCgl.getComp2();
        log.info("Performing uniqueness check for potential CGL Number: {}", potentialCglNumber);

        if (cglMasterRepository.existsById(potentialCglNumber)) {
            log.error("Attempted to add a CGL that already exists: {}", potentialCglNumber);
            throw new DataIntegrityViolationException("CGL Code '" + potentialCglNumber + "' already exists.");
        }

        CGLMaster savedCgl = cglMasterRepository.save(newCgl);
        log.info("Successfully added new CGL with ID: {}", savedCgl.getCglNumber());
    }

    private void handleUpdate(CommonReq request) throws JsonProcessingException {
        String targetId = request.getTargetId();
        if (targetId == null || targetId.isBlank()) {
            throw new IllegalArgumentException("Target ID is required for an UPDATE operation.");
        }

        log.info("Fetching existing CGL with ID: {} for update.", targetId);
        CGLMaster existingCgl = cglMasterRepository.findById(targetId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "CGL Code with ID '" + targetId + "' not found for update."));

        // Deserialize the payload containing the changes
        CGLMaster updates = readMaster(request.getPayload());

        if (updates.getStatus().equals(STATUS_BLOCKED)) {

            // CASE 1: BLOCKING ACTION
            // We ONLY update the status. We intentionally IGNORE description/flags
            // to prevent "Edit + Block" ambiguity.
            log.info("Operation identified as BLOCK for CGL {}. Ignoring other field updates.", targetId);
            existingCgl.setStatus(updates.getStatus());
            existingCgl.setCloseDate(LocalDate.now());
        } else {
            // CASE 2: NORMAL UPDATE
            // Apply the updates to the existing entity all fields
            // We only update fields that are allowed to change.
            existingCgl.setDescription(updates.getDescription());
            existingCgl.setAcClassification(updates.getAcClassification());
            existingCgl.setBalFwd(updates.getBalFwd());
            existingCgl.setDefBalType(updates.getDefBalType());
            existingCgl.setStatus(updates.getStatus());
            existingCgl.setBalCompare(updates.getBalCompare());
            existingCgl.setManualPosting(updates.getManualPosting());
            // We do not update comp1, comp2, segmentCode as they form the primary key.

        }
        cglMasterRepository.save(existingCgl);
        log.info("Successfully processed CGL update/block with ID: {}", targetId);
    }

    /**
     * Logic to Block or Unblock a CGL
     */
    private void handleStatusChange(CommonReq request, Integer newStatus) {
        String targetId = request.getTargetId();
        log.info("Processing Status Change ({}) for CGL ID: {}", newStatus, targetId);

        CGLMaster existingCgl = cglMasterRepository.findById(targetId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "CGL Code with ID '" + targetId + "' not found for status update."));

        // Update the status
        existingCgl.setStatus(newStatus);

        cglMasterRepository.save(existingCgl);
        log.info("Successfully updated CGL Status to {} for ID: {}", newStatus, targetId);
    }

    // =====================================================================
    // CGL -> report template (Head/Variable) mapping
    // =====================================================================

    /** The payload also carries templateMappings, which is not part of the CGL master entity. */
    private CGLMaster readMaster(String payload) throws JsonProcessingException {
        JsonNode tree = objectMapper.readTree(payload);
        if (tree instanceof ObjectNode obj) {
            obj.remove("templateMappings");
        }
        return objectMapper.treeToValue(tree, CGLMaster.class);
    }

    /**
     * Maker submit: mappings must be present when enforced, and are dry-run validated against the active
     * templates (targets exist, still match what was picked). Nothing is written.
     */
    @Override
    public void validateRequest(CreateRequestDto dto, String token) throws JsonProcessingException {
        if (!(dto.getPayload() instanceof CglPayloadDto payload)) {
            return;
        }
        ChangeType changeType = dto.getChangeType();
        if (changeType != ChangeType.ADD && changeType != ChangeType.UPDATE) {
            return;
        }
        if (changeType == ChangeType.UPDATE && STATUS_BLOCKED.equals(payload.getStatus())) {
            return; // blocking through update: templates are left unchanged
        }
        List<CglTemplateMappingDto> mappings = payload.getTemplateMappings();
        if (mappingEnforced && (mappings == null || mappings.isEmpty())) {
            throw new BusinessRuleViolationException(
                    "At least one Head/Variable mapping in the NWSA / YSA / PNL / PFORM templates is required for a CGL.");
        }
        if (mappings == null) {
            return; // legacy client, not enforced
        }
        TemplateBindingDtos.ValidateResponse result = templateBindingClient.validate(
                new TemplateBindingDtos.ValidateRequest(payload.getKey(), mappingEnforced, mappings), token);
        if (!result.isValid()) {
            throw new BusinessRuleViolationException(String.join("; ", result.getErrors()));
        }
    }

    /**
     * Last step of the approval transaction (CGL master, notifications and request status are already flushed):
     * tells the Template service to write the CGL into the chosen Head/Variable filters, version the templates
     * and audit it. Any failure throws and rolls the whole approval back. Idempotent on the request id.
     */
    @Override
    public void afterApprovalFlushed(CommonReq request, String token) throws JsonProcessingException {
        ChangeType changeType = request.getChangeType();
        if (changeType != ChangeType.ADD && changeType != ChangeType.UPDATE) {
            return; // BLOCK / UNBLOCK: templates are left unchanged
        }
        JsonNode tree = objectMapper.readTree(request.getPayload());
        if (changeType == ChangeType.UPDATE && tree.path("status").asInt(1) == STATUS_BLOCKED) {
            return; // blocking through update
        }

        JsonNode mappingNode = tree.path("templateMappings");
        boolean provided = !mappingNode.isMissingNode() && !mappingNode.isNull();
        if (!provided) {
            if (mappingEnforced) {
                throw new BusinessRuleViolationException("CGL request has no template mappings; approval is not possible.");
            }
            return; // legacy request created before this feature
        }
        List<CglTemplateMappingDto> mappings = objectMapper.convertValue(mappingNode,
                new TypeReference<List<CglTemplateMappingDto>>() {
                });
        if (mappings.isEmpty() && (mappingEnforced || changeType == ChangeType.ADD)) {
            if (mappingEnforced) {
                throw new BusinessRuleViolationException("At least one Head/Variable mapping is required for a CGL.");
            }
            return;
        }

        TemplateBindingDtos.ApplyRequest apply = new TemplateBindingDtos.ApplyRequest();
        apply.setCommonReqId(request.getId());
        apply.setChangeType(changeType.name());
        apply.setCglNumber(tree.path("comp1").asText() + tree.path("segmentCode").asText() + tree.path("comp2").asText());
        apply.setMakerId(request.getCreatorId());
        apply.setRequireMapping(mappingEnforced);
        apply.setMappings(mappings);

        TemplateBindingDtos.ApplyResult result = templateBindingClient.apply(apply, token);

        String summary = result.getChanges().isEmpty()
                ? "No template change needed."
                : result.getChanges().stream()
                        .map(c -> c.getReportId() + " v" + c.getFromVersion() + "->v" + c.getToVersion())
                        .collect(Collectors.joining(", "));
        request.setExecutionRemarks("Successfully processed approval. Template mappings: " + summary);
        log.info("CGL {} mapped in templates for request {}: {}", apply.getCglNumber(), request.getId(), summary);
    }
}
