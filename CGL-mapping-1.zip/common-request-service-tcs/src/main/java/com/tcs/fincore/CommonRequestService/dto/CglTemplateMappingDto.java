package com.tcs.fincore.CommonRequestService.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * One Head + Variable the maker mapped the CGL to. Values come from the Template service picker
 * (GET /api/template-config/cgl-mappings/targets) and are sent back unchanged.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CglTemplateMappingDto {

    @NotBlank(message = "reportId is required for a template mapping")
    private String reportId;

    @NotBlank(message = "rowId is required for a template mapping")
    private String rowId;

    @NotBlank(message = "cellId is required for a template mapping")
    private String cellId;

    /** Empty for mappings on a DB_* cell source. */
    private String variableName;

    /** Template version the maker saw. */
    private Integer baseVersion;

    /** Fingerprint of the Head row at pick time. */
    private String fingerprint;
}
