package com.tcs.fincore.CommonRequestService.service.strategy;

import tools.jackson.core.JacksonException;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.RequestStatus;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;

import java.util.List;

/**
 * Strategy interface to handle the processing of different request types.
 */
public interface RequestTypeStrategy {
    /**
     * Processes the request upon approval. This typically involves saving the
     * payload data to the relevant master table.
     *
     * @param request The common request object containing the payload.
     * @throws JacksonException if there is an error processing the JSON payload.
     */
    void processApproval(CommonReq request) throws JacksonException;


    /**
     * Validates the payload BEFORE creating the Pending Request.
     * Default implementation does nothing (hook for strategies to override).
     */
    default void validateRequest(CreateRequestDto requestDto) throws JacksonException {
        // Default: No validation. Override in specific strategies.
    }


    /**
     * Same as {@link #validateRequest(CreateRequestDto)} but also receives the caller's JWT, for strategies that
     * must call another service while validating. Default: delegates to the token-less variant.
     */
    default void validateRequest(CreateRequestDto requestDto, String token) throws JacksonException {
        validateRequest(requestDto);
    }

    /**
     * Called for an ACCEPTED request after processApproval, the notifications and the request itself have been
     * written and flushed, as the very last step before the approval transaction commits. A strategy that has to
     * touch another service does it here: if this throws, the whole approval rolls back. Default: nothing.
     */
    default void afterApprovalFlushed(CommonReq request, String token) throws JacksonException {
        // Default: nothing to do.
    }

    RequestType getRequestType();

    /**
     * Handle Rejection ---
     * Default does nothing. Specific strategies can override to truncate tables, etc.
     * @param request The common request object containing the payload.
     */
    default void processRejection(CommonReq request) {
        // No operation by default
    }

    /**
     * Define what "Pending" means
     * Default returns only PENDING. Specific strategies can return PENDING and QUEUED.
     */
    default List<RequestStatus> getActionableStatuses() {
        return List.of(RequestStatus.PENDING);
    }
}