package com.tcs.fincore.CommonRequestService.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * One Head + Variable of a report template (NWSA, YSA, PNL, PFORM) that a CGL is mapped to.
 * The values come from the Template Configuration Service picker
 * (GET /api/template-config/cgl-mappings/targets) and are sent back unchanged by the UI.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CglTemplateMappingDto {

    @NotBlank(message = "reportId is required for a template mapping")
    private String reportId;

    @NotBlank(message = "rowId is required for a template mapping")
    private String rowId;

    @NotBlank(message = "cellId is required for a template mapping")
    private String cellId;

    /** Empty for mappings on a DB_* cell source. */
    private String variableName;

    /** Template version the maker saw (picker field "baseVersion"). */
    private Integer baseVersion;

    /** Fingerprint of the Head row at pick time (picker field "fingerprint"). */
    private String fingerprint;
}
