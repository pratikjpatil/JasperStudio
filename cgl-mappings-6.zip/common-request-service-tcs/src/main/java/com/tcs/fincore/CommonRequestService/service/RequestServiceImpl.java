package com.tcs.fincore.CommonRequestService.service;

import tools.jackson.databind.ObjectMapper;
import tools.jackson.core.JacksonException;
import com.tcs.fincore.CommonRequestService.dto.CancelRequestDto;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.dto.NotificationConfigDto;
import com.tcs.fincore.CommonRequestService.dto.ProcessRequestDto;
import com.tcs.fincore.CommonRequestService.dto.payload.KeyablePayload;
import com.tcs.fincore.CommonRequestService.exception.ResourceNotFoundException;
import com.tcs.fincore.CommonRequestService.model.CGLMaster;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.ChangeType;
import com.tcs.fincore.CommonRequestService.model.enums.RequestStatus;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;
import com.tcs.fincore.CommonRequestService.repository.CommonRequestRepository;
import com.tcs.fincore.CommonRequestService.service.strategy.RequestStrategyFactory;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

/**
 * - Handle all requests for different business objects [CGL, SEGMENT, CURRENCY]
 * - Handle creator/executor scenarios
 * - Used strategy design patter to differentiate different business objects
 * - Injected NotificationWriterService and PermissionConfigService for notification
 * - Injected BusinessSecurityService for second level RBAC authentication to check BLOCK/UNBLOCK/CREATE permissions
 *
 * @version 1.1
 * @since 2025-12-11
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RequestServiceImpl implements RequestService {

    private static final String EVENT_SOURCE = "CommonRequestService";
    private final CommonRequestRepository commonRequestRepository;
    private final RequestStrategyFactory strategyFactory;
    private final ObjectMapper objectMapper;
    private final NotificationWriterService notificationWriterService;
    private final PermissionConfigService permissionConfigService;
    private final BusinessSecurityService businessSecurityService;

    @Override
    @Transactional(rollbackOn = Exception.class) // Ensure rollback on any exception
    public CommonReq createRequest(
            CreateRequestDto dto,
            String creatorId,
            String token
    ) throws JacksonException {

        // --- LAYER 2 SECURITY CHECK --- (rbac) <-------- 1st check in filter [shubhankar]
        // Validate that the user is allowed to perform this SPECIFIC ChangeType (e.g. BLOCK)
        businessSecurityService.validateUserAction(token, dto.getRequestType(), dto.getChangeType());

        // --- STRATEGIC VALIDATION -  VALIDATE MASTER DATA BEFORE PROCEEDING ---
        strategyFactory.getStrategy(dto.getRequestType()).validateRequest(dto, token);

        KeyablePayload payload = (KeyablePayload) dto.getPayload();

        // --- PRE CHECKS ---
        String targetId = payload.getKey();
        if (targetId == null || targetId.isBlank()) {
            throw new IllegalArgumentException("Could not determine targetId from payload.");
        }
        log.info("Determined targetId for new request as: {}", targetId);

        List<CommonReq> existingRequests = commonRequestRepository.findByTargetIdAndReqStatus(targetId,
                RequestStatus.PENDING);

        if (!existingRequests.isEmpty()) {
            log.warn("Attempted to create a duplicate request for targetId {} which already has a {} request.",
                    targetId, existingRequests.get(0).getReqStatus());
            throw new DataIntegrityViolationException(
                    "An active or pending request for '" + targetId + "' already exists.");
        }
        log.info("Uniqueness check passed for targetId: {}", targetId);

        // --- CREATE AND SAVE REQUEST ---
        CommonReq request = new CommonReq();
        request.setCreatorId(creatorId);
        request.setReqType(dto.getRequestType());
        request.setChangeType(dto.getChangeType());
        request.setPayload(objectMapper.writeValueAsString(payload));
        request.setTargetId(targetId);
        request.setReqStatus(RequestStatus.PENDING);
        // set correct time date
        request.setReqDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));


        log.info("Saving new, validated request for targetId {}", targetId);
        CommonReq savedRequest = commonRequestRepository.save(request);

        try {
            // --- NOTIFICATION LOGIC ---

            // 1. Fetch Config from CACHE (Fast)
            String requestTypeKey = dto.getRequestType().name(); // e.g., "SEGMENT_CODE"
            log.info("Request Type String to fetch role ids from PERMISSIONS: {}", requestTypeKey);
            NotificationConfigDto config = permissionConfigService.getConfig(requestTypeKey);

            // 2. Customize Message
            String action = request.getChangeType().name(); // ADD/ DELETE/ UPDATE / BLOCK

            // Validate payload to detect "Block", "UNBLOCK action
            if (request.getChangeType() == ChangeType.BLOCK || request.getChangeType() == ChangeType.UNBLOCK) {
                // Parse payload to check if status is 0 (Blocked)
                CGLMaster payload2 = objectMapper.readValue(request.getPayload(), CGLMaster.class);
                if (payload2.getStatus() == 0) {
                    action = "BLOCK"; // Override action name for the message
                } else if (payload2.getStatus() == 1) {
                    action = "UNBLOCK"; // Override action name for the message
                }
            }
            String message = "New " + action + " request (" + targetId + ") pending for " + dto.getRequestType();

            // 3. Send to Group (1-to-Many via Outbox)
            notificationWriterService.createNotification(
                    creatorId,                  // USER ID TO EXCLUDE FROM ROLES, IN THIS CASE ROLE WILL BE USED TO TARGET USER
                    config.getTargetRoles(),    // Group to SEND TO "51,55" (Fetched from Cache/DB)
                    message,
                    config.getTargetUrl(),      // "/segment-requests" (Fetched from Cache/DB)
                    savedRequest.getId().toString(),
                    EVENT_SOURCE
            );

        } catch (JacksonException e) {
            // Catch JSON specific errors
            log.error("CRITICAL: Failed to parse payload to determine BLOCK/UNBLOCK status for Request ID: {}", savedRequest.getId(), e);
            throw new IllegalArgumentException("Invalid payload structure for Notification processing", e);

        } catch (DataAccessException e) {
            // Catch Spring Database specific errors
            log.error("CRITICAL: Database error while creating 'pending' notification for Request ID: {}.", savedRequest.getId(), e);
            throw new IllegalStateException("Database transaction failed during notification creation.", e);

        } catch (ResourceNotFoundException e) {
            // Catch configuration missing errors
            log.error("CRITICAL: Missing notification configuration for Request Type: {}", dto.getRequestType(), e);
            throw new IllegalStateException("Notification configuration missing. Cannot proceed.", e);
        }
        return savedRequest;
    }

    @Override
    @Transactional(rollbackOn = Exception.class) // Ensure rollback on any exception
    public Optional<CommonReq> updateRequestStatus(
            ProcessRequestDto dto,
            String executorId,
            String token
    ) throws JacksonException {

        Long requestId = dto.getRequestId();
        log.info("Attempting to update status for request ID: {} by executor: {}", requestId, executorId);

        CommonReq request = commonRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request with ID " + requestId + " not found."));

        // SELF-APPROVAL CHECK
        if (executorId.equals(request.getCreatorId())) {
            log.warn("SECURITY VIOLATION: User {} attempted to approve their own request (ID: {}).", executorId,
                    requestId);
            throw new IllegalStateException("User cannot approve or reject their own request.");
        }

        if (request.getReqStatus() != RequestStatus.PENDING) {
            log.warn("Attempted to modify an already processed request. ID: {}, Current Status: {}", dto.getRequestId(),
                    request.getReqStatus());
            throw new IllegalStateException("Request has already been processed and cannot be modified.");
        }

        // --- UPDATE REQUEST STATE ---
        request.setExecutorId(executorId);
        request.setExecutorRemarks(dto.getRemarks());
        request.setExecutionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
        request.setReqStatus(dto.getStatus());

        // --- PROCESS BUSINESS LOGIC (STRATEGY) & PREPARE NOTIFICATION 1: TO MAKER (1-to-1) ---
        // This is a 1-to-1, so USER_ID is the recipient, TARGET_ROLE is null.
        if (RequestStatus.ACCEPTED.equals(dto.getStatus())) {
            log.info("Request {} ACCEPTED. Applying strategy for type {}", dto.getRequestId(), request.getReqType());
            // 1. Execute the business logic (e.g., save to master table)
            strategyFactory.getStrategy(request.getReqType()).processApproval(request);

            // Notify Maker: Approved
            notificationWriterService.createRequestApprovedNotification(request, executorId);
            request.setExecutionRemarks("Successfully processed approval.");

        } else {
            // REJECTION LOGIC TRIGGER
            log.info("Request {} REJECTED. Triggering rejection strategy for type {}", dto.getRequestId(), request.getReqType());
            // Calls the strategy. For CGL/Branch this does nothing. For the specific screen, it applies logic.
            strategyFactory.getStrategy(request.getReqType()).processRejection(request);
            notificationWriterService.createRequestRejectedNotification(request, executorId, dto.getRemarks());
            request.setExecutionRemarks("Request rejected by user.");
        }

        // --- NOTIFICATION 2: CLOSURE (1-to-Many, Filtered) ---
        // We wrap this in Try/Catch because if this fails, we do NOT want to roll back the actual Approval.
        // The approval is critical data; the "FYI" notification to the group is secondary.
        try {
            // A. Get Group Config from Cache (Zero DB Cost)
            NotificationConfigDto config = permissionConfigService.getConfig(request.getReqType().name());

            // B. Prepare Message
            String action = dto.getStatus().equals(RequestStatus.ACCEPTED) ? "Approved" : "Rejected";
            String closureMessage = "Request " + request.getTargetId() + " was " + action + " by " + executorId;

            // C. Send to Group (1-to-Many)
            // Pass the CHECKER'S ID as the exclusion ID.
            notificationWriterService.createNotification(
                    executorId,                 // User to EXCLUDE
                    config.getTargetRoles(),    // // Group to SEND TO -> The same roles that received the Pending alert excluding the executor
                    closureMessage,
                    config.getTargetUrl(),      // Link to history
                    request.getId().toString(),
                    "CommonRequestService"
            );
            log.info("Sent closure notification to group for Request ID: {}", requestId);

        } catch (DataAccessException | ResourceNotFoundException e) {
            log.error("Failed to send closure notification for Request ID: {}. Reason: {}", requestId, e.getMessage());
        }

        // --- SAVE THE UPDATED REQUEST ---
        CommonReq updatedRequest = commonRequestRepository.saveAndFlush(request);

        // --- LAST STEP BEFORE COMMIT: cross-service work of an approved request (e.g. CGL -> template mapping) ---
        // Everything local is already written and flushed; if this throws, the whole approval rolls back.
        // Default no-op for every request type except those that override it.
        if (RequestStatus.ACCEPTED.equals(dto.getStatus())) {
            strategyFactory.getStrategy(updatedRequest.getReqType()).afterApprovalFlushed(updatedRequest, token);
        }

        return Optional.of(updatedRequest);
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public CommonReq cancelRequest(CancelRequestDto dto, String userId) {

        Long requestId = dto.getRequestId();
        log.info("Attempting to cancel request ID: {} by user: {}", requestId, userId);

        // 1. Fetch Request
        CommonReq request = commonRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request with ID " + requestId + " not found."));

        // 2. Security Check: Only the CREATOR can cancel
        if (!request.getCreatorId().equals(userId)) {
            log.warn("SECURITY VIOLATION: User {} attempted to cancel request {} owned by {}",
                    userId, requestId, request.getCreatorId());
            throw new AccessDeniedException("You are not authorized to cancel this request.");
        }

        // 3. State Check: Must be PENDING
        if (request.getReqStatus() != RequestStatus.PENDING) {
            log.warn("Attempted to cancel a processed request. ID: {}, Status: {}", requestId, request.getReqStatus());
            throw new IllegalStateException("Only pending requests can be cancelled. Current status: " + request.getReqStatus());
        }

        // 4. Update State
        request.setReqStatus(RequestStatus.CANCELLED);

        // We use Executor fields to track who cancelled it (the creator themselves)
        request.setExecutorId(userId);
        request.setExecutionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
        request.setExecutorRemarks("CANCELLED BY USER: " + (dto.getRemarks() != null ? dto.getRemarks() : "No remarks"));
        log.info("execution date before save :  {}", request.getExecutionDate());
        // 5. Save & Return
        CommonReq updatedRequest = commonRequestRepository.save(request);
        log.info("Request {} successfully cancelled by user.", updatedRequest.getExecutionDate());

        return updatedRequest;
    }

    @Override
    public List<CommonReq> getMyRequests(
            String userId,
            RequestType requestType
    ) {
        if (requestType == null) {
            log.info("Request type is missing, Please provide correct request type to fetch requests for user : {}",
                    userId);
            throw new IllegalArgumentException(
                    "Request type is missing, Please provide correct request type to fetch requests.");
        }
        log.info("Fetching my requests for user {} with type {}", userId, requestType);
        return commonRequestRepository.findByCreatorIdAndReqType(userId, requestType);
    }

    @Override
    public List<CommonReq> getPendingRequests(
            String userId,
            RequestType requestType
    ) {
        if (requestType == null) {
            log.error("Request type is missing. Cannot fetch pending requests for user: {}", userId);
            throw new IllegalArgumentException(
                    "Request type is missing, Please provide correct request type to fetch pending requests."
            );
        }
        log.info("Fetching pending requests for user: {} with type: {}", userId, requestType);

        List<RequestStatus> targetStatuses;

        // Smart Routing: Only LHO gets both P and Q. Everything else stays exactly as it was.
        if (requestType == RequestType.YEAR_END_PROFIT_TRANSFER) {
            targetStatuses = List.of(RequestStatus.PENDING, RequestStatus.QUEUE);
        } else {
            targetStatuses = List.of(RequestStatus.PENDING);
        }

        // Call the updated repository method
        return commonRequestRepository.findByCreatorIdNotAndReqStatusInAndReqType(
                userId,
                targetStatuses,
                requestType
        );
    }

    @Override
    public List<CommonReq> getAllRequests(
    ) {
        return commonRequestRepository.findAll();
    }

    @Override
    public List<CommonReq> getActiveApproverAndHistoryRequests(
            String userId, RequestType requestType
    ) {
        if (requestType == null || userId == null || userId.isBlank()) {
            log.warn("Request type or User ID is missing. Cannot fetch active Approver/history requests.");
            throw new IllegalArgumentException("Request type and User ID are mandatory.");
        }

        log.info("Fetching Approver dashboard & history requests for user: {} with type: {}", userId, requestType);
        // 1. Get what this specific screen considers "Pending" (e.g., [PENDING] or [PENDING, QUEUED])
        List<RequestStatus> actionableStatuses = strategyFactory.getStrategy(requestType).getActionableStatuses();
        // 2. Execute the query
        return commonRequestRepository.findCheckerAndHistoryRequests(
                requestType,
                userId,
                RequestStatus.ACCEPTED,
                actionableStatuses
        );
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public int cancelAllActionableRequests(RequestType requestType, String userId, String remarks) {
        log.info("Initiating BULK CANCEL for all actionable requests of type {} by user {}", requestType, userId);

        // 1. Get actionable statuses (e.g., [PENDING] or [PENDING, QUEUED]) from the Strategy
        List<RequestStatus> targetStatuses = strategyFactory.getStrategy(requestType).getActionableStatuses();

        // 2. Format remarks and date
        String finalRemarks = "BULK CANCELLED BY USER "+ userId + " : " + (remarks != null ? remarks : "No remarks provided");
        LocalDateTime executionDate = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));

        // 3. Execute bulk update in the database
        int updatedCount = commonRequestRepository.bulkCancelRequests(
                requestType,
                targetStatuses,
                RequestStatus.CANCELLED,
                userId,
                executionDate,
                finalRemarks
        );

        log.info("Successfully bulk cancelled {} requests for type {}", updatedCount, requestType);
        return updatedCount;
    }
}