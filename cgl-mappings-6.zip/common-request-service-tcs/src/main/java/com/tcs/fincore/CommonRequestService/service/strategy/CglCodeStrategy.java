package com.tcs.fincore.CommonRequestService.service.strategy;

import tools.jackson.databind.ObjectMapper;
import tools.jackson.core.JacksonException;
import com.tcs.fincore.CommonRequestService.dto.CglPayloadDto;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import com.tcs.fincore.CommonRequestService.model.enums.ChangeType;
import com.tcs.fincore.CommonRequestService.repository.SegmentCodeMasterRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import com.tcs.fincore.CommonRequestService.exception.ResourceNotFoundException;
import com.tcs.fincore.CommonRequestService.model.CGLMaster;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;
import com.tcs.fincore.CommonRequestService.repository.CGLMasterRepository;

import com.tcs.fincore.CommonRequestService.client.TemplateBindingClient;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos;
import com.tcs.fincore.CommonRequestService.dto.CglTemplateMappingDto;
import org.springframework.beans.factory.annotation.Value;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class CglCodeStrategy implements RequestTypeStrategy {

    private final CGLMasterRepository cglMasterRepository;
    private final ObjectMapper objectMapper;
    private final RedisTemplate<String, String> redisTemplate;
    private static final String CGL_KEY = "CACHE::GL_INVALID::CGLS";
    // @Autowired
    // private Validator validator;
    private final SegmentCodeMasterRepository segmentCodeMasterRepository;
    private final TemplateBindingClient templateBindingClient;
    private static final Integer STATUS_BLOCKED = 0;

    /** When true, every CGL create / non-block update must carry at least one Head/Variable mapping. */
    @Value("${cgl.mapping.enforced:false}")
    private boolean mappingEnforced;

    @Override
    public RequestType getRequestType() {
        return RequestType.CGL_CODE;
    }

    @Override
    public void processApproval(CommonReq request) throws JacksonException {
        switch (request.getChangeType()) {
            case ADD:
                handleAdd(request);
                break;
            case UPDATE:
                handleUpdate(request);
                break;
            case BLOCK:
                handleStatusChange(request, 0); // 0 = Inactive/Blocked
                break;
            case UNBLOCK:
                handleStatusChange(request, 1); // 1 = Active
                break;
            default:
                throw new UnsupportedOperationException(
                        "Change type " + request.getChangeType() + " is not supported.");
        }
    }

    /**
     * CORE VALIDATION LOGIC
     * Runs before the CommonReq is created.
     * 
     *     */
    @Override
    public void validateRequest(CreateRequestDto requestDto) throws JacksonException {

        // Convert Payload to DTO
        CglPayloadDto payload = objectMapper.convertValue(requestDto.getPayload(), CglPayloadDto.class);

        String comp1 = payload.getComp1();
        String comp2 = payload.getComp2();
        String segmentCode = payload.getSegmentCode();

        String compositeKey = payload.getKey();
        /*
         * ---------------------------------------------------------
         * Rule 1: Validation for All Fields
         * ---------------------------------------------------------
         */
        if (comp1 == null || !comp1.matches("^\\d{2,4}$")) {
            throw new BusinessRuleViolationException(
                    "Comp1 code must only digits and must be between 2 and 4 characters..");
        }
        if (comp2 == null || !comp2.matches("^\\d+$")) {
            throw new BusinessRuleViolationException("Comp2 code must only digits..");
        }
        if (segmentCode == null || !segmentCode.matches("^[A-Za-z0-9]{4}$")) {
            throw new BusinessRuleViolationException("Segment Code must be exactly 4 alphanumeric characters..");
        }
        if (payload.getAcClassification() == null || !payload.getAcClassification().matches("^[A-Za-z]$")) {
            throw new BusinessRuleViolationException("AcClassification code must be single character..");
        }
        if (payload.getBalCompare() == null || !(payload.getBalCompare() == 0 || payload.getBalCompare() == 1)) {
            throw new BusinessRuleViolationException("BalCompare must be either 0 or 1.");
        }
        if (payload.getBalFwd() == null || !(payload.getBalFwd() == 0 || payload.getBalFwd() == 1)) {
            throw new BusinessRuleViolationException("BalFwd code must be either 0 or 1");
        }
        if (payload.getDefBalType() == null || !payload.getDefBalType().matches("^[A-Za-z]$")) {
            throw new BusinessRuleViolationException("DefBalType code must be single character..");
        }
        if (payload.getManualPosting() == null
                || !(payload.getManualPosting() == 0 || payload.getManualPosting() == 1)) {
            throw new BusinessRuleViolationException("Manual Posting must be either 0 or 1");
        }

        /*
         * ---------------------------------------------------------
         * Rule 2: Duplicate Check (Only for ADD)
         * ---------------------------------------------------------
         */
        if (requestDto.getChangeType() == ChangeType.ADD) {
            if (cglMasterRepository.existsById(compositeKey)) {
                throw new BusinessRuleViolationException(
                        "CGL Code combination already exists for key: " + compositeKey);
            }
        }

        /*
         * ---------------------------------------------------------
         * Rule 3: Existence Check (MODIFY / DELETE)
         * ---------------------------------------------------------
         */
        if (requestDto.getChangeType() == ChangeType.UPDATE ||
                requestDto.getChangeType() == ChangeType.DELETE) {

            if (!cglMasterRepository.existsById(compositeKey)) {
                throw new BusinessRuleViolationException(
                        "CGL Code combination does not exist for key: " + compositeKey);
            }
        }

        /*
         * ---------------------------------------------------------
         * Rule 4: Segment Code Validation
         * Must exist in Segment Master
         * ---------------------------------------------------------
         */
        if (!segmentCodeMasterRepository.existsById(payload.getSegmentCode())) {
            throw new BusinessRuleViolationException(
                    "Invalid Segment Code: " + payload.getSegmentCode() +
                            ". Segment does not exist in Segment Master.");
        }

        /*
         * ---------------------------------------------------------
         * Rule 5: balFwd Flag Validation (Must be 0 or 1)
         * ---------------------------------------------------------
         */
        if (!(payload.getBalFwd() == 0 || payload.getBalFwd() == 1)) {
            throw new BusinessRuleViolationException(
                    "Balance Forward (balFwd) must be either 0 or 1.");
        }

        /*
         * ---------------------------------------------------------
         * Rule 6: Status Validation (0 = Inactive, 1 = Active)
         * ---------------------------------------------------------
         */
        if (!(payload.getStatus() == 0 || payload.getStatus() == 1)) {
            throw new BusinessRuleViolationException(
                    "Status must be either 0 (Inactive) or 1 (Active).");
        }

        /*
         * ---------------------------------------------------------
         * Rule 7: balCompare Flag Validation (0 or 1)
         * ---------------------------------------------------------
         */
        if (!(payload.getBalCompare() == 0 || payload.getBalCompare() == 1)) {
            throw new BusinessRuleViolationException(
                    "Balance Compare (balCompare) must be either 0 or 1.");
        }

        /*
         * ---------------------------------------------------------
         * Rule 8: manualPosting Flag Validation (0 or 1)
         * ---------------------------------------------------------
         */
        if (!(payload.getManualPosting() == 0 || payload.getManualPosting() == 1)) {
            throw new BusinessRuleViolationException(
                    "Manual Posting flag must be either 0 or 1.");
        }

        /*
         * ---------------------------------------------------------
         * Rule 9: Logical Accounting Validation
         * ---------------------------------------------------------
         */

        String classification = payload.getAcClassification();
        String defaultBalType = payload.getDefBalType();

        // Asset & Expense -> Normally Debit
        if (("A".equals(classification) || "E".equals(classification))
                && !"D".equals(defaultBalType)) {

            throw new BusinessRuleViolationException(
                    "For Account Classification '" + classification +
                            "', Default Balance Type must be 'D'.");
        }

        // Liability, Income -> Normally Credit
        if (("L".equals(classification) || "I".equals(classification))
                && !"C".equals(defaultBalType)) {

            throw new BusinessRuleViolationException(
                    "For Account Classification '" + classification +
                            "', Default Balance Type must be 'C'.");
        }

        // Memo accounts – allow both, but must not have balance forward
        if ("M".equals(classification) && payload.getBalFwd() == 1) {
            throw new BusinessRuleViolationException(
                    "Memo accounts cannot have Balance Forward enabled.");
        }

    }

    private void handleAdd(CommonReq request) throws JacksonException {
        CGLMaster newCgl = readMaster(request.getPayload());

        // Although the DB computes the final CGL_NUMBER, we also construct it here for
        // uniqueness
        String potentialCglNumber = newCgl.getComp1() + newCgl.getSegmentCode() + newCgl.getComp2();
        log.info("Performing uniqueness check for potential CGL Number: {}", potentialCglNumber);

        if (cglMasterRepository.existsById(potentialCglNumber)) {
            log.error("Attempted to add a CGL that already exists: {}", potentialCglNumber);
            throw new DataIntegrityViolationException("CGL Code '" + potentialCglNumber + "' already exists.");
        }

        CGLMaster savedCgl = cglMasterRepository.save(newCgl);
        log.info("Successfully added new CGL with ID: {}", savedCgl.getCglNumber());
        redisTemplate.delete(CGL_KEY);
    }

    private void handleUpdate(CommonReq request) throws JacksonException {
        String targetId = request.getTargetId();
        if (targetId == null || targetId.isBlank()) {
            throw new IllegalArgumentException("Target ID is required for an UPDATE operation.");
        }

        log.info("Fetching existing CGL with ID: {} for update.", targetId);
        CGLMaster existingCgl = cglMasterRepository.findById(targetId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "CGL Code with ID '" + targetId + "' not found for update."));

        // Deserialize the payload containing the changes
        CGLMaster updates = readMaster(request.getPayload());

        if (updates.getStatus().equals(STATUS_BLOCKED)) {

            // CASE 1: BLOCKING ACTION
            // We ONLY update the status. We intentionally IGNORE description/flags
            // to prevent "Edit + Block" ambiguity.
            log.info("Operation identified as BLOCK for CGL {}. Ignoring other field updates.", targetId);
            existingCgl.setStatus(updates.getStatus());
            existingCgl.setCloseDate(LocalDate.now());
        } else {
            // CASE 2: NORMAL UPDATE
            // Apply the updates to the existing entity all fields
            // We only update fields that are allowed to change.
            existingCgl.setDescription(updates.getDescription());
            existingCgl.setAcClassification(updates.getAcClassification());
            existingCgl.setBalFwd(updates.getBalFwd());
            existingCgl.setDefBalType(updates.getDefBalType());
            existingCgl.setStatus(updates.getStatus());
            existingCgl.setBalCompare(updates.getBalCompare());
            existingCgl.setManualPosting(updates.getManualPosting());
            // We do not update comp1, comp2, segmentCode as they form the primary key.

        }
        cglMasterRepository.save(existingCgl);
        log.info("Successfully processed CGL update/block with ID: {}", targetId);
        redisTemplate.delete(CGL_KEY);
    }

    /**
     * Logic to Block or Unblock a CGL
     */
    private void handleStatusChange(CommonReq request, Integer newStatus) {
        String targetId = request.getTargetId();
        log.info("Processing Status Change ({}) for CGL ID: {}", newStatus, targetId);

        CGLMaster existingCgl = cglMasterRepository.findById(targetId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "CGL Code with ID '" + targetId + "' not found for status update."));

        // Update the status
        existingCgl.setStatus(newStatus);

        cglMasterRepository.save(existingCgl);
        log.info("Successfully updated CGL Status to {} for ID: {}", newStatus, targetId);
    }

    // =====================================================================
    // CGL -> report template (Head/Variable) mapping
    // =====================================================================

    /** The stored payload may also carry templateMappings, which is not part of the CGL master entity. */
    private CGLMaster readMaster(String payload) throws JacksonException {
        JsonNode tree = objectMapper.readTree(payload);
        if (tree instanceof ObjectNode obj) {
            obj.remove("templateMappings");
        }
        return objectMapper.treeToValue(tree, CGLMaster.class);
    }

    /**
     * Maker submit: the existing CGL rules run first (unchanged), then the Head/Variable mappings are checked:
     * present when enforced, and dry-run validated against the active templates. Nothing is written.
     */
    @Override
    public void validateRequest(CreateRequestDto requestDto, String token) throws JacksonException {
        validateRequest(requestDto);

        ChangeType changeType = requestDto.getChangeType();
        if (changeType != ChangeType.ADD && changeType != ChangeType.UPDATE) {
            return; // BLOCK / UNBLOCK do not touch templates
        }
        CglPayloadDto payload = objectMapper.convertValue(requestDto.getPayload(), CglPayloadDto.class);
        if (changeType == ChangeType.UPDATE && STATUS_BLOCKED.equals(payload.getStatus())) {
            return; // blocking through update: templates are left unchanged
        }
        List<CglTemplateMappingDto> mappings = payload.getTemplateMappings();
        if (mappingEnforced && (mappings == null || mappings.isEmpty())) {
            throw new BusinessRuleViolationException(
                    "At least one Head/Variable mapping in the NWSA / YSA / PNL / PFORM templates is required for a CGL.");
        }
        if (mappings == null) {
            return; // request without mappings (mapping not enforced): behaves exactly as before
        }
        TemplateBindingDtos.ValidateResponse result = templateBindingClient.validate(
                new TemplateBindingDtos.ValidateRequest(payload.getKey(), mappingEnforced, mappings), token);
        if (!result.isValid()) {
            throw new BusinessRuleViolationException(String.join("; ", result.getErrors()));
        }
    }

    /**
     * Last step of the approval transaction: tells the Template service to write the CGL into the chosen
     * Head/Variable filters, version the templates and audit it. Throws on any failure, which rolls the whole
     * approval back (the request stays PENDING). Idempotent on the request id, so the checker can retry.
     */
    @Override
    public void afterApprovalFlushed(CommonReq request, String token) throws JacksonException {
        ChangeType changeType = request.getChangeType();
        if (changeType != ChangeType.ADD && changeType != ChangeType.UPDATE) {
            return; // BLOCK / UNBLOCK
        }
        JsonNode tree = objectMapper.readTree(request.getPayload());
        if (changeType == ChangeType.UPDATE && tree.path("status").asInt(1) == STATUS_BLOCKED) {
            return; // blocking through update
        }

        JsonNode mappingNode = tree.path("templateMappings");
        boolean provided = !mappingNode.isMissingNode() && !mappingNode.isNull();
        if (!provided) {
            if (mappingEnforced) {
                throw new BusinessRuleViolationException("This CGL request has no template mappings; it cannot be approved.");
            }
            return; // request created without mappings: behaves exactly as before
        }
        List<CglTemplateMappingDto> mappings = objectMapper.convertValue(mappingNode,
                new TypeReference<List<CglTemplateMappingDto>>() {
                });
        if (mappings.isEmpty()) {
            if (mappingEnforced) {
                throw new BusinessRuleViolationException("At least one Head/Variable mapping is required for a CGL.");
            }
            if (changeType == ChangeType.ADD) {
                return; // nothing to map
            }
        }

        TemplateBindingDtos.ApplyRequest apply = new TemplateBindingDtos.ApplyRequest();
        apply.setCommonReqId(request.getId());
        apply.setChangeType(changeType.name());
        apply.setCglNumber(request.getTargetId());
        apply.setMakerId(request.getCreatorId());
        apply.setRequireMapping(mappingEnforced);
        apply.setMappings(mappings);

        TemplateBindingDtos.ApplyResult result = templateBindingClient.apply(apply, token);

        String summary = result.getChanges().isEmpty()
                ? "No template change needed."
                : result.getChanges().stream()
                        .map(c -> c.getReportId() + " v" + c.getFromVersion() + "->v" + c.getToVersion())
                        .collect(Collectors.joining(", "));
        request.setExecutionRemarks("Successfully processed approval. Template mappings: " + summary);
        log.info("CGL {} mapped in templates for request {}: {}", apply.getCglNumber(), request.getId(), summary);
    }
}
