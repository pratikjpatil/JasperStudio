package com.tcs.fincore.CommonRequestService.service;

import tools.jackson.core.JacksonException;
import com.tcs.fincore.CommonRequestService.dto.CancelRequestDto;
import com.tcs.fincore.CommonRequestService.dto.CreateRequestDto;
import com.tcs.fincore.CommonRequestService.dto.ProcessRequestDto;
import com.tcs.fincore.CommonRequestService.model.CommonReq;
import com.tcs.fincore.CommonRequestService.model.enums.RequestType;

import java.util.List;
import java.util.Optional;

public interface RequestService {

    /**
     * Creates a new request.
     *
     * @param createRequestDto DTO containing request details.
     * @param creatorId        The ID of the user creating the request.
     * @return The saved request entity.
     */
    CommonReq createRequest(CreateRequestDto createRequestDto, String creatorId, String token) throws JacksonException;

    /**
     * Retrieves all requests created by a specific user (Maker).
     *
     * @param userId The user's ID and requestType like : SegmentCode, CGL
     * @return A list of their requests.
     */
    List<CommonReq> getMyRequests(String userId, RequestType requestType);

    /**
     * Retrieves all pending requests for Checkers.
     *
     * @return A list of pending requests.
     */
    List<CommonReq> getPendingRequests(String userId, RequestType requestType);


    /**
     * Retrieves all requests for Checkers (Pending, Accepted, Rejected).
     *
     * @return A list of all requests.
     */
    List<CommonReq> getAllRequests();

    /**
     * Updates the status of a request (Accept/Reject).
     *
     * @param processRequestDto DTO containing the request id, new status and
     *                          executor remarks.
     * @param executorId        The ID of the user performing the action.
     * @return The updated request entity.
     */
    Optional<CommonReq> updateRequestStatus(ProcessRequestDto processRequestDto, String executorId, String token) throws JacksonException;


    /**
     * Process a cancel request
     */
    CommonReq cancelRequest(CancelRequestDto cancelRequestDto, String userId);

    /**
     * Returns all active requests of all time which are not in cancelled/rejected state.
     */
    List<CommonReq> getActiveApproverAndHistoryRequests(String userId, RequestType requestType);

    /**
     * Cancel all requests
     * @return count of requests which are cancelled
     */
    int cancelAllActionableRequests(RequestType requestType, String userId, String remarks);
}