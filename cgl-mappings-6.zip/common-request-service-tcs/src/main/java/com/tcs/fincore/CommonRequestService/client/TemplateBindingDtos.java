package com.tcs.fincore.CommonRequestService.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.tcs.fincore.CommonRequestService.dto.CglTemplateMappingDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Wire models of the Template Configuration Service CGL mapping API (it answers in its ApiResponse envelope). */
public final class TemplateBindingDtos {

    private TemplateBindingDtos() {
    }

    @Data
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ValidateEnvelope {
        private String status;
        private String message;
        private ValidateResponse data;
    }

    @Data
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ApplyEnvelope {
        private String status;
        private String message;
        private ApplyResult data;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ValidateRequest {
        private String cglNumber;
        private boolean requireMapping;
        private List<CglTemplateMappingDto> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ValidateResponse {
        private boolean valid;
        private List<String> errors = new ArrayList<>();
        private List<String> warnings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    public static class ApplyRequest {
        /** COMMON_REQ.REQ_ID: idempotency key and audit reference on the Template service side. */
        private Long commonReqId;
        private String changeType;
        private String cglNumber;
        private String makerId;
        private boolean requireMapping;
        private List<CglTemplateMappingDto> mappings = new ArrayList<>();
    }

    @Data
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ReportChange {
        private String reportId;
        private String templateId;
        private int fromVersion;
        private int toVersion;
        private int added;
        private int removed;
        private Long auditReqId;
    }

    @Data
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ApplyResult {
        private Long commonReqId;
        private boolean replay;
        private List<ReportChange> changes = new ArrayList<>();
    }
}
