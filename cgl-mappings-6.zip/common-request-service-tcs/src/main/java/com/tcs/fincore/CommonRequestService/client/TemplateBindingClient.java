package com.tcs.fincore.CommonRequestService.client;

import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ApplyEnvelope;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ApplyRequest;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ApplyResult;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ValidateEnvelope;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ValidateRequest;
import com.tcs.fincore.CommonRequestService.client.TemplateBindingDtos.ValidateResponse;
import com.tcs.fincore.CommonRequestService.exception.BusinessRuleViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.net.http.HttpClient;
import java.time.Duration;

/**
 * Calls the Template Configuration Service. The caller's own JWT is forwarded so that service authenticates and
 * audits the real user.
 *
 * 4xx answers become BusinessRuleViolationException carrying the Template service's message (HTTP 400 to the UI).
 * Anything else (5xx, timeout, I/O) becomes IllegalStateException, which rolls back the CGL approval so nothing is
 * half-applied. The apply call is idempotent on the request id, so the checker can simply retry.
 */
@Slf4j
@Component
public class TemplateBindingClient {

    private static final String BASE = "/api/template-config/cgl-mappings";

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    public TemplateBindingClient(
            ObjectMapper objectMapper,
            @Value("${template.service.base-url}") String baseUrl,
            @Value("${template.service.connect-timeout-ms:3000}") int connectTimeoutMs,
            @Value("${template.service.read-timeout-ms:30000}") int readTimeoutMs) {
        this.objectMapper = objectMapper;
        HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(connectTimeoutMs)).build();
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpClient);
        factory.setReadTimeout(Duration.ofMillis(readTimeoutMs));
        this.restClient = RestClient.builder().baseUrl(baseUrl).requestFactory(factory).build();
    }

    public ValidateResponse validate(ValidateRequest request, String token) {
        ValidateEnvelope env = post(BASE + "/validate", request, token, ValidateEnvelope.class);
        if (env == null || env.getData() == null) {
            throw new IllegalStateException("Template service returned an empty validation response.");
        }
        return env.getData();
    }

    public ApplyResult apply(ApplyRequest request, String token) {
        ApplyEnvelope env = post(BASE + "/apply", request, token, ApplyEnvelope.class);
        if (env == null || env.getData() == null) {
            throw new IllegalStateException("Template service returned an empty apply response; the approval was not completed.");
        }
        return env.getData();
    }

    private <T> T post(String path, Object body, String token, Class<T> type) {
        try {
            return restClient.post()
                    .uri(path)
                    .header(HttpHeaders.AUTHORIZATION, token)
                    .body(body)
                    .retrieve()
                    .onStatus(HttpStatusCode::is4xxClientError, (req, res) -> {
                        throw new BusinessRuleViolationException(
                                extractMessage(res.getBody().readAllBytes(), res.getStatusCode().value()));
                    })
                    .body(type);
        } catch (BusinessRuleViolationException e) {
            throw e;
        } catch (RestClientException e) {
            log.error("Template service call failed: {}", path, e);
            throw new IllegalStateException("Template service is unavailable or failed; the request was not processed. "
                    + "Please retry. (" + e.getMessage() + ")", e);
        }
    }

    private String extractMessage(byte[] body, int status) {
        try {
            JsonNode n = objectMapper.readTree(body);
            if (n.hasNonNull("message")) {
                return n.get("message").asString();
            }
        } catch (Exception ignored) {
            // fall through
        }
        return "Template service rejected the CGL mapping (HTTP " + status + ")";
    }
}
