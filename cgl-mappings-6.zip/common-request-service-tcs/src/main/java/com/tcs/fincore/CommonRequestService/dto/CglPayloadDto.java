package com.tcs.fincore.CommonRequestService.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.tcs.fincore.CommonRequestService.dto.payload.KeyablePayload;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

/**
 * Data Transfer Object (DTO) for handling Chart of Accounts (CGL_CODE) related
 * requests.
 * This class uses Project Lombok's {@code @Data} annotation to automatically
 * generate
 * boilerplate code like getters, setters, {@code toString()}, {@code equals()},
 * and {@code hashCode()}.
 * It also implements the {@code KeyablePayload} interface to provide a
 * composite key
 * for unique identification within the system, specifically when processing
 * common requests.
 */
@Data
@JsonTypeName("CGL_CODE") // This must match the RequestType enum name used for processing this payload
                          // type
public class CglPayloadDto implements KeyablePayload {

    /**
     * Represents the first component of the General Ledger (GL) code combination.
     * This field is mandatory.
     */
    // Change from Short to String to preserve "08"
    @Pattern(regexp = "\\d+", message = "Comp1 must be numeric")
    @Size(min = 2, max = 4, message = "Comp1 must be exactly 4 digits")
    @NotNull(message = "Component 1 (comp1) cannot be null.")
    private String comp1;

    /**
     * Represents the segment code within the GL code combination.
     * This field is mandatory and has a size constraint.
     */
    @NotNull(message = "Segment Code cannot be null.")
    @Size(min = 1, max = 4, message = "Segment Code must be between 1 and 4 characters.")
    private String segmentCode;

    /**
     * Represents the second component of the GL code combination.
     * This field is mandatory.
     * Change from Short to String
     */
    @Pattern(regexp = "\\d+", message = "Comp2 must be numeric")
    @NotNull(message = "Component 2 (comp2) cannot be null.")
    private String comp2;

    /**
     * A human-readable description for the GL code combination.
     * This field is mandatory and has a size constraint.
     */
    @NotNull(message = "Description cannot be null.")
    @Size(min = 1, max = 100, message = "Description must be between 1 and 100 characters.")
    private String description;

    /**
     * The classification of the account (A, L, I, E, M for Asset, Liability,
     * Income, Expense, Memo).
     * This field is mandatory and has a strict pattern constraint.
     */
    @NotNull(message = "A/C Classification cannot be null.")
    @Pattern(regexp = "[ALIEM]", message = "A/C Classification must be one of: A, L, I, E, M.")
    private String acClassification;

    /**
     * Flag indicating whether balance forwarding is enabled (e.g., 0 for No, 1 for
     * Yes).
     * This field is mandatory.
     */
    @NotNull(message = "Balance Forward (balFwd) flag cannot be null.")
    private Integer balFwd;

    /**
     * The default balance type for the account ('C' for Credit, 'D' for Debit).
     * This field is mandatory and has a strict pattern constraint.
     */
    @NotNull(message = "Default Balance Type cannot be null.")
    @Pattern(regexp = "[CMD]", message = "Default Balance Type must be 'C' or 'D'or 'M'.")
    private String defBalType;

    /**
     * The status of the GL code (e.g., 0 for Inactive, 1 for Active).
     * This field is mandatory.
     */
    @NotNull(message = "Status cannot be null.")
    private Integer status;

    /**
     * Flag indicating if the balance is used for comparison purposes (e.g., 0 for
     * No, 1 for Yes).
     * This field is mandatory.
     */
    @NotNull(message = "Balance Compare (balCompare) flag cannot be null.")
    private Integer balCompare;

    /**
     * Flag indicating if manual posting is allowed for this GL code (e.g., 0 for
     * No, 1 for Yes).
     * This field is mandatory.
     */
    @NotNull(message = "Manual Posting flag cannot be null.")
    private Integer manualPosting;

    /**
     * Head + Variable combinations of the report templates (NWSA, YSA, PNL, PFORM) this CGL is mapped to.
     * Desired state: the complete set the CGL should have after approval.
     * {@code null} = mappings not touched by this request; empty = remove all (rejected when mapping is enforced).
     * Omitted from the stored payload when null, so existing CGL requests are unchanged.
     */
    @Valid
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<CglTemplateMappingDto> templateMappings;

    /**
     * Constructs and returns the composite primary key for this DTO.
     * The key is used for data identification and integrity checks within the
     * service layer.
     *
     * @return A string representing the concatenated composite primary key (comp1 +
     *         segmentCode + comp2).
     */
    @Override
    @JsonIgnore // Ensures this method's output is not included during JSON serialization of the
                // DTO
    public String getKey() {
        // Construct the composite primary key
        return "" + comp1 + segmentCode + comp2;
    }
}