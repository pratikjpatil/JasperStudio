/**
 * -------------------------------------------------------------
 * Common Request Screen Configurations
 * -------------------------------------------------------------
 *
 * Backend sends only `screenId`.
 * This file resolves:
 *
 * screenId -> screenName -> screenConfig
 *
 * Developers maintain configs using readable screen names.
 *
 * Example:
 *
 * const config = COMMON_REQ_SCREEN_CONFIGS[screenId];
 *
 * Internally:
 *
 * 10 -> BRANCH -> branchConfig
 *
 * -------------------------------------------------------------
 */

import { currencyFormatterWith6Decimals } from "../../utils/NumberFormat";
// CGL -> report template mapping: column, details block and approval note for the CGL_CODE screen.
// Adjust the folder to where the `templateMapping` folder lives (next to the CGL components).
// Empty (no effect on the screen) when TEMPLATE_MAPPING_ENABLED is false.
import { CGL_REQUEST_SCREEN_EXTENSION } from "../cgl/templateMapping/cglRequestScreenExtension";

/**
 * -------------------------------------------------------------
 * LOOKUP CONSTANTS
 * -------------------------------------------------------------
 */
const ACCOUNT_CLASSIFICATIONS = [
  { value: "A", label: "Asset" },
  { value: "L", label: "Liability" },
  { value: "I", label: "Income" },
  { value: "E", label: "Expense" },
  { value: "M", label: "Memo A/c" },
];

/**
 * -------------------------------------------------------------
 * SCREEN ID → SCREEN NAME MAP
 * -------------------------------------------------------------
 *
 * Maps backend screen IDs to readable screen names.
 */

export const SCREEN_ID_NAME_MAP = {
  2: "CIRCLE",
  6: "CGL_CODE",
  8: "SEGMENT_CODE",
  10: "BRANCH",
  15: "CALENDER",
  17: "STATE",
  19: "CURRENCY",
  21: "CURRENCY_RATE_CHANGE",
  41: "FILE_TYPE_MASTER",
  42: "YEAR_END_PROFIT_TRANSFER",
  43: "YEAR_END_PROFIT_TRANSFER",
  45: "MAIN_DATA_PARAMETERS",
};

/**
 * -------------------------------------------------------------
 * SCREEN CONFIGS (DEFINED USING SCREEN NAMES)
 * -------------------------------------------------------------
 */

export const SCREEN_CONFIGS_BY_NAME = {
  /**
   * -------------------------------------------------------------
   * CIRCLE SCREEN
   * -------------------------------------------------------------
   */
  CIRCLE: {
    columns: [
      {
        field: "circleCode",
        headerName: "Circle Code",
        flex: 0.5,
        minWidth: 130,
      },
      {
        field: "circleName",
        headerName: "Circle Name",
        flex: 1.2,
        minWidth: 220,
      },
      {
        field: "zoneDescription",
        headerName: "Zone",
        flex: 0.8,
        minWidth: 160,
      },
    ],

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      return {
        ...data,
        payload: {
          circleCode: data.circleCode,
          circleName: data.circleName,
          zone: data.zoneDescription,
        },
      };
    },
  },

  /**
   * -------------------------------------------------------------
   * CGL CODE SCREEN
   * -------------------------------------------------------------
   *
   * CGL_REQUEST_SCREEN_EXTENSION adds (only for this screen):
   *  - screenProps.ViewExtras      : requested template mapping in the details dialog
   *  - screenProps.getApprovalNote : note in the approve dialog
   *  - columns                     : "Template Mapping" count column
   */
  CGL_CODE: {
    ...CGL_REQUEST_SCREEN_EXTENSION.screenProps,

    columns: [
      { field: "cglCode", headerName: "CGL Code", flex: 0.5, minWidth: 140 },
      {
        field: "description",
        headerName: "CGL Description",
        flex: 1.3,
        minWidth: 250,
      },
      ...CGL_REQUEST_SCREEN_EXTENSION.columns,
    ],

    transformData: (data) =>
      data.map((row) => {
        const parsed = row.payload || {};

        return {
          ...row,
          ...parsed,
          cglCode: `${parsed.comp1 || ""}${parsed.segmentCode || ""}${parsed.comp2 || ""}`,
        };
      }),

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      const {
        comp1 = "",
        segmentCode = "",
        comp2 = "",
        description = "",
        acClassification = "",
        balFwd = "",
        balCompare = "",
        manualPosting = "",
        status = "",
      } = data;

      const accountClassificationLabel =
        ACCOUNT_CLASSIFICATIONS.find((x) => x.value === acClassification)
          ?.label || "N/A";

      const yesNo = (val) => (val == "1" ? "Yes" : "No");
      const includeExclude = (val) => (val == "1" ? "Include" : "Exclude");
      const cglStatus = status == "1" ? "Active" : "Inactive";

      return {
        ...data,
        payload: {
          comp1,
          segmentCode,
          comp2,
          "CGL Code": [comp1, segmentCode, comp2].filter(Boolean).join(""),
          Description: description || "-",
          "Account Classification": accountClassificationLabel,
          "CGL Status": cglStatus,
          "Balance Carry Forward": yesNo(balFwd),
          "Balance Compare": includeExclude(balCompare),
          "Manual Posting Allowed": yesNo(manualPosting),
        },
      };
    },

    processSummaryData: (data) => data,
  },

  /**
   * -------------------------------------------------------------
   * SEGMENT CODE
   * -------------------------------------------------------------
   */
  SEGMENT_CODE: {
    columns: [
      {
        field: "segmentCode",
        headerName: "Segment Code",
        flex: 0.5,
        minWidth: 140,
      },
      {
        field: "description",
        headerName: "Segment Description",
        flex: 1.2,
        minWidth: 250,
      },
    ],
  },

  /**
   * -------------------------------------------------------------
   * BRANCH
   * -------------------------------------------------------------
   */
  BRANCH: {
    columns: [
      { field: "code", headerName: "Branch Code", flex: 0.5, minWidth: 140 },
      { field: "name", headerName: "Branch Name", flex: 1.2, minWidth: 220 },
    ],

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      const {
        code = "",
        name = "",
        circleCode = "",
        circleName = "",
        stateName = "",
        city = "",
        address = "",
        pinCode = "",
        phoneNumber = "",
        emailId = "",
        nmrCode = "",
        status = "",
        openDate = "",
        closeDate = "",
        mergeDate = "",
        mergedWithBranch = "",
        cpcFlag = "",
        foodCreditFlag = "",
        currChestFlag = "",
        branchType = "",
      } = data;

      return {
        ...data,
        payload: {
          branchCode: code,
          branchName: name,
          circle: `${circleCode} - ${circleName}`,
          state: stateName,
          city,
          address,
          pinCode,
          phoneNumber,
          emailId,
          networkModuleRegion: nmrCode,
          BranchStatusAsPerCBS: status ? "Live" : "Closed",
          openDate,
          closeDate,
          mergeDate,
          mergedWithBranch,
          "CPC (centralized processing cell)": cpcFlag
            ? "Allowed"
            : "Not Allowed",
          foodCredit: foodCreditFlag ? "Allowed" : "Not Allowed",
          currencyChest: currChestFlag ? "Allowed" : "Not Allowed",
          branchType: branchType === "A" ? "Automated" : "Manual",
        },
      };
    },
  },

  /**
   * -------------------------------------------------------------
   * STATE
   * -------------------------------------------------------------
   */
  STATE: {
    columns: [
      {
        field: "stateCode",
        headerName: "State Code",
        flex: 0.5,
        minWidth: 130,
      },
      {
        field: "stateName",
        headerName: "State Name",
        flex: 1.2,
        minWidth: 200,
      },
    ],
  },

  /**
   * -------------------------------------------------------------
   * CURRENCY
   * -------------------------------------------------------------
   */
  CURRENCY: {
    columns: [
      {
        field: "currencyCode",
        headerName: "Currency Code",
        flex: 0.5,
        minWidth: 130,
      },
      {
        field: "currencyName",
        headerName: "Currency Name",
        flex: 1,
        minWidth: 180,
      },
      {
        field: "currencyRate",
        headerName: "Currency Rate",
        flex: 1,
        minWidth: 150,
        align: "right",
        headerAlign: "right",
        sortable: true,
        renderCell: (params) =>
          currencyFormatterWith6Decimals("INR").format(params.value),
      },
    ],

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      return {
        ...data,
        payload: {
          currencyCode: data.currencyCode,
          currencyName: data.currencyName,
          currencyRate:
            data.currencyRate !== null && data.currencyRate !== undefined
              ? currencyFormatterWith6Decimals("INR").format(data.currencyRate)
              : "",
        },
      };
    },
  },

  /**
   * -------------------------------------------------------------
   * CURRENCY RATE CHANGE
   * -------------------------------------------------------------
   */
  CURRENCY_RATE_CHANGE: {
    columns: [
      {
        field: "currencyCode",
        headerName: "Currency Code",
        flex: 0.5,
        minWidth: 140,
      },
      {
        field: "currencyRate",
        headerName: "Currency Rate",
        flex: 1,
        minWidth: 160,
        align: "right",
        headerAlign: "right",
        sortable: true,
        renderCell: (params) =>
          currencyFormatterWith6Decimals("INR").format(params.value),
      },
    ],

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      return {
        ...data,
        payload: {
          currencyCode: data.currencyCode,
          existingCurrencyRate:
            data.currencyRate !== null && data.currencyRate !== undefined
              ? currencyFormatterWith6Decimals("INR").format(
                  data.existingCurrencyRate || 0,
                )
              : "",
          updatedCurrencyRate:
            data.currencyRate !== null && data.currencyRate !== undefined
              ? currencyFormatterWith6Decimals("INR").format(
                  data.currencyRate || 0,
                )
              : "",
        },
      };
    },
  },

  /**
   * -------------------------------------------------------------
   * CALENDER
   * -------------------------------------------------------------
   */
  CALENDER: {
    columns: [
      {
        field: "yearStartDate",
        headerName: "Year Start Date",
        flex: 0.5,
        minWidth: 150,
      },
      {
        field: "yearEndDate",
        headerName: "Year End Date",
        flex: 0.5,
        minWidth: 150,
      },
      { field: "remarks", headerName: "Remarks", flex: 0.8, minWidth: 200 },
    ],
  },

  /**
   * -------------------------------------------------------------
   * FILE TYPE MASTER
   * -------------------------------------------------------------
   */
  FILE_TYPE_MASTER: {
    showDeleteRequest: true,
    columns: [
      { field: "type", headerName: "File Type", flex: 0.5, minWidth: 150 },
      {
        field: "filePattern",
        headerName: "File Name",
        flex: 0.5,
        minWidth: 200,
      },
      { field: "includeFile", headerName: "Include", flex: 0.8, minWidth: 130 },
    ],

    transformData: (data) =>
      data.map((row) => {
        const parsed = row.payload || {};
        return {
          ...row,
          ...parsed,
          includeFile: parsed.includeFile === "Y" ? "YES" : "NO",
        };
      }),
  },

  /**
   * -------------------------------------------------------------
   * YEAR END PROFIT TRANSFER
   * -------------------------------------------------------------
   */
  YEAR_END_PROFIT_TRANSFER: {
    patchUrl: "/CR/update-request",

    columns: [
      {
        field: "year",
        headerName: "Process Name",
        flex: 0.6,
        minWidth: 220,
        renderCell: () => "Year End Profit Transfer",
      },
    ],

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      const { circleWiseDetails = [] } = data;

      return {
        ...data,
        reportType: "profit_transactions",
        payload: {
          ShowCustomTable: true,
          ShowDownload: true,
          summaryData: {
            header: "Year End Profit Transfer",
            data: circleWiseDetails,
          },
        },
      };
    },
  },

  /**
   * -------------------------------------------------------------
   * MAIN DATA PARAMETERS
   * -------------------------------------------------------------
   */
  MAIN_DATA_PARAMETERS: {
    columns: [
      { field: "fileType", headerName: "File Type", flex: 0.6, minWidth: 200 },
      { field: "rowCount", headerName: "Rows", flex: 0.4, minWidth: 100 },
    ],

    transformData: (data) => {
      return data.map((row) => {
        const parsed = row.payload || {};
        const rows = parsed.rows || [];

        return {
          ...row,
          ...parsed,
          fileType: parsed.fileType || row.targetId,
          rowCount: rows.length,
        };
      });
    },

    processViewData: (data) => {
      if (!data || typeof data !== "object") return data;

      const { fileType = "", rows = [] } = data;

      /* -------- Transform Rows -------- */

      const formattedRows = (rows || []).map((r, index) => ({
        "Sr No": index + 1,
        "Column Name": r.columnName,
        "Start Position": r.startValue,
        "End Position": r.endValue,
        "Save to Database": r.toBeIncluded === "true" ? "Yes" : "No",
        "Data Type": r.dataType,
        "Decimal Count": r.dataType === "AMOUNT" ? (r.decimalCount ?? 0) : "-",
      }));

      /* -------- Final View Payload -------- */

      const viewPayload = {
        ShowCustomTable: true,
        summaryData: {
          data: formattedRows || [],
          header: fileType + " File Definition:",
        },
      };

      return {
        ...data,
        payload: viewPayload,
      };
    },
  },
};

/**
 * -------------------------------------------------------------
 * MAIN EXPORT
 * -------------------------------------------------------------
 *
 * Automatically resolves:
 *
 * screenId -> screenName -> config
 */

export const COMMON_REQ_SCREEN_CONFIGS = new Proxy(
  {},
  {
    get(_, screenId) {
      const screenName = SCREEN_ID_NAME_MAP[screenId];
      return SCREEN_CONFIGS_BY_NAME[screenName] || {};
    },
  },
);
