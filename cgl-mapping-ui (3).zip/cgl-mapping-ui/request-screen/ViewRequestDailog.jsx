/**
 * ViewRequestDialog
 *
 * This dialog displays the details of a request dynamically.
 * It renders:
 * 1. Request metadata (creator, status, request type, etc.)
 * 2. Dynamic payload fields
 * 3. Optional dynamic table
 * 4. Optional per-screen extras (screenConfig.ViewExtras, e.g. CGL template mapping)
 * 5. Optional download action
 *
 * The dialog can be dragged using the header.
 */

import React, { useRef, useState, useEffect } from "react";

import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Grid,
  Box,
  Divider,
  IconButton,
  Stack,
} from "@mui/material";

import CloseIcon from "@mui/icons-material/Close";

import {
  timeStampFormatter,
  toPascalKebabCase,
  formatKeyForDisplay,
} from "../../utils/CommonUtilities";

import { ViewCommonDynamicTable } from "./ViewCommonDynamicTable";

const ViewRequestDialog = ({
  open,
  handleClose,
  data,
  screenConfig,
  handleDownload,
}) => {
  /* ==========================================================
     Dragging State
     ========================================================== */

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);

  const dragRef = useRef({
    pointerId: null,
    startX: 0,
    startY: 0,
    startPositionX: 0,
    startPositionY: 0,
    width: 0,
    height: 0,
    initialLeft: 0,
    initialTop: 0,
  });

  /* ==========================================================
     Start Drag
     ========================================================== */

  const handleDragStart = (event) => {
    // Only allow primary/left mouse button
    if (event.pointerType === "mouse" && event.button !== 0) {
      return;
    }

    // Do not start dragging when clicking a button
    if (event.target.closest("button")) {
      return;
    }

    const paper = event.currentTarget.closest(".MuiDialog-paper");

    if (!paper) {
      return;
    }

    const rect = paper.getBoundingClientRect();

    event.preventDefault();

    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startPositionX: position.x,
      startPositionY: position.y,

      width: rect.width,
      height: rect.height,

      initialLeft: rect.left,
      initialTop: rect.top,
    };

    setDragging(true);

    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  /* ==========================================================
     Handle Drag Movement
     ========================================================== */

  useEffect(() => {
    if (!dragging) {
      return;
    }

    const handlePointerMove = (event) => {
      const {
        startX,
        startY,
        startPositionX,
        startPositionY,
        width,
        height,
        initialLeft,
        initialTop,
      } = dragRef.current;

      const deltaX = event.clientX - startX;
      const deltaY = event.clientY - startY;

      let newX = startPositionX + deltaX;
      let newY = startPositionY + deltaY;

      /*
       * Keep at least 30px of the dialog visible.
       */
      const margin = 30;

      /*
       * Calculate the allowed translation.
       *
       * initialLeft / initialTop are the dialog's original
       * viewport coordinates when dragging started.
       */
      const minX =
        margin - initialLeft + startPositionX;

      const maxX =
        window.innerWidth -
        margin -
        width -
        initialLeft +
        startPositionX;

      const minY =
        margin - initialTop + startPositionY;

      const maxY =
        window.innerHeight -
        margin -
        height -
        initialTop +
        startPositionY;

      newX = Math.max(minX, Math.min(newX, maxX));
      newY = Math.max(minY, Math.min(newY, maxY));

      setPosition({
        x: newX,
        y: newY,
      });
    };

    const handlePointerUp = () => {
      setDragging(false);
      dragRef.current.pointerId = null;
    };

    document.addEventListener("pointermove", handlePointerMove);
    document.addEventListener("pointerup", handlePointerUp);

    return () => {
      document.removeEventListener("pointermove", handlePointerMove);
      document.removeEventListener("pointerup", handlePointerUp);
    };
  }, [dragging]);

  /* ==========================================================
     Reset Position Whenever Dialog Opens
     ========================================================== */

  useEffect(() => {
    if (open) {
      setPosition({ x: 0, y: 0 });
      setDragging(false);
    }
  }, [open]);

  /**
   * If no data or payload exists,
   * do not render dialog.
   */
  if (!data || !data.payload) {
    return null;
  }

  const { payload = {} } = data;

  /**
   * Extract table column configuration
   * from screenConfig safely
   */
  const tableColumns = screenConfig?.columns || [];

  /**
   * ==========================================================
   * Request Metadata
   * ==========================================================
   */

  const mainDetails = [
    {
      label: "Creator ID",
      value: data.creatorId,
      size: 2.5,
    },
    {
      label: "Request Type",
      value: data.changeType === "ADD" ? "Added" : "Modified",
      size: 2.5,
    },
    {
      label: "Request Status",
      value:
        data.reqStatus === "QUEUE"
          ? "In Queue"
          : toPascalKebabCase(data.reqStatus),
      size: 2.5,
    },
    {
      label: "Requested Date",
      value: timeStampFormatter(data.reqDate),
      size: 4.5,
    },
  ];

  /**
   * ==========================================================
   * Dynamic Payload Fields
   * ==========================================================
   */

  const dynamicFields = Object.entries(payload).filter(
    ([key]) =>
      !["ShowCustomTable", "summaryData", "ShowDownload"].includes(key),
  );

  /**
   * ==========================================================
   * Conditional Rendering Flags
   * ==========================================================
   */

  const showTable =
    payload?.ShowCustomTable &&
    (tableColumns.length > 0 ||
      payload?.summaryData?.data?.length > 0);

  const showDownload = payload?.ShowDownload;

  const showActions = showDownload;

  /**
   * Optional per-screen component (currently only CGL_CODE defines one).
   * Undefined for every other screen, in which case nothing extra is rendered.
   */
  const ViewExtras = screenConfig?.ViewExtras;

  /**
   * ==========================================================
   * Component Render
   * ==========================================================
   */

  return (
    <Dialog
      open={open}
      onClose={(event, reason) => {
        /*
         * IMPORTANT:
         * Clicking/touching outside the dialog will NOT close it.
         */
        if (reason === "backdropClick") {
          return;
        }

        handleClose();
      }}
      maxWidth="md"
      fullWidth
      slotProps={{
        paper: {
          sx: {
            transform: `translate(${position.x}px, ${position.y}px)`,

            /*
             * Don't animate while dragging.
             * Small animation when released/reset.
             */
            transition: dragging
              ? "none"
              : "transform 0.15s ease",

            /*
             * Keep large dialogs inside the viewport.
             */
            maxHeight: "90vh",

            /*
             * IMPORTANT:
             * Do NOT put touchAction: "none" here.
             * The dialog content should remain scrollable.
             */
          },
        },
      }}
    >
      {/* ======================================================
          Dialog Header
         ====================================================== */}

      <DialogTitle
        onPointerDown={handleDragStart}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pr: 1,

          /*
           * Makes it obvious that the header is draggable.
           */
          cursor: dragging ? "grabbing" : "grab",

          userSelect: "none",

          /*
           * Touch dragging is enabled on the header.
           */
          touchAction: "none",

          "&:active": {
            cursor: "grabbing",
          },
        }}
      >
        <Typography variant="h6" fontWeight={700}>
          Request Details — <b>ID: {data.id}</b>
        </Typography>

        {/* Close Button */}

        <IconButton
          onPointerDown={(event) => {
            /*
             * Prevent close button from starting a drag.
             */
            event.stopPropagation();
          }}
          onClick={handleClose}
          size="small"
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <Divider />

      {/* ======================================================
          Dialog Content
         ====================================================== */}

      <DialogContent
        sx={{
          pt: 3,

          /*
           * Content scrolls independently if it becomes tall.
           */
          overflowY: "auto",
        }}
      >
        {/* =============================
            Request Metadata Section
           ============================= */}

        <Grid container spacing={2}>
          {mainDetails.map((item) => (
            <Grid
              size={{ xs: 12, sm: item.size }}
              key={item.label}
            >
              <Stack spacing={0.5}>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 700,
                    color: "text.secondary",
                  }}
                >
                  {item.label}
                </Typography>

                <Typography variant="body1">
                  {item.value ?? "N/A"}
                </Typography>
              </Stack>
            </Grid>
          ))}
        </Grid>

        {/* Divider shown only if dynamic fields exist */}

        {dynamicFields.length > 0 && (
          <Divider sx={{ my: 2 }} />
        )}

        {/* =============================
            Dynamic Payload Fields
           ============================= */}

        {dynamicFields.length > 0 && (
          <Grid container spacing={2}>
            {dynamicFields.map(([key, value]) => (
              <Grid
                size={{ xs: 12, sm: 4 }}
                key={key}
              >
                <Box>
                  {/* Field label */}

                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 700,
                      color: "text.secondary",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {formatKeyForDisplay(key)}
                  </Typography>

                  {/* Field value */}

                  <Typography
                    variant="body1"
                    sx={{
                      wordBreak: "break-word",
                    }}
                  >
                    {String(value ?? "N/A")}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        )}

        {/* =============================
            Dynamic Table Section
           ============================= */}

        {showTable && (
          <>
            <Divider sx={{ my: 2 }} />

            <ViewCommonDynamicTable data={payload} />
          </>
        )}

        {/* =============================
            Optional per-screen extras
            (CGL: requested template mapping)
           ============================= */}

        {ViewExtras && (
          <>
            <Divider sx={{ my: 2 }} />

            <ViewExtras data={data} />
          </>
        )}
      </DialogContent>

      {/* ======================================================
          Dialog Actions
         ====================================================== */}

      {showActions && (
        <>
          <Divider />

          <DialogActions
            sx={{
              justifyContent: "center",
              p: 2,
            }}
          >
            {showDownload && (
              <Button
                onClick={handleDownload}
                variant="contained"
                sx={{
                  textTransform: "none",
                  borderRadius: 2,
                  px: 3,
                }}
              >
                Download
              </Button>
            )}
          </DialogActions>
        </>
      )}
    </Dialog>
  );
};

export default ViewRequestDialog;
