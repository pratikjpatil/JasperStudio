import { Check, Clear, Visibility } from "@mui/icons-material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import AddBoxIcon from "@mui/icons-material/AddBox";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AutoDeleteIcon from "@mui/icons-material/AutoDelete";
import EditDocumentIcon from "@mui/icons-material/EditDocument";
import HourglassBottomIcon from "@mui/icons-material/HourglassBottom";
import InfoIcon from "@mui/icons-material/Info";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import {
  Alert, // CGL mapping: used for the optional approval note
  Box,
  Button,
  Card, // Imported Card
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import useApi from "../../hooks/useApi";
import { timeStampFormatter } from "../../utils/CommonUtilities";
import CustomChip from "../../utils/CustomChip";
import downloadFile from "../../utils/DownloadUtils";
import LoadingOverlay from "../../utils/LoadingOverlay";
import useCustomSnackbar from "../../utils/useCustomSnackbar";
import { COMMON_REQ_SCREEN_CONFIGS } from "../common/CommonConstants";
import { styles } from "./CommonRequestScreenStyles";
import RequestAnalytics from "./RequestAnalytics";
import ViewRequestDialog from "./ViewRequestDailog";

const REMARKS_REGEX = /^(?!.* {2})[a-zA-Z0-9\s/&(),.-]*$/;
const PENDING_REQUESTS_URL = "/CR/pending-requests";
const PATCH_URL = "/CR/update-request";
const DOWNLOAD_URL = "/RS/reports/generate/base64";
const ACTIVE_DOWNLOAD_URL = "/CR/active-requests";

export default function CommonRequestScreen() {
  const selectedMenuItem = useSelector((s) => s.menus.selectedMenuItem);
  const requestType = selectedMenuItem?.requestType || "";
  const navigate = useNavigate();
  const { callApi } = useApi();
  const showSnackBar = useCustomSnackbar();

  const screenConfig = COMMON_REQ_SCREEN_CONFIGS[selectedMenuItem?.id];
  const {
    columns,
    transformData,
    processViewData,
    requestsUrl,
    patchUrl,
    downloadUrl,
    showDeleteRequest = false,
    // Optional per-screen hook (currently only CGL_CODE defines it): note shown in the approve dialog.
    getApprovalNote,
  } = screenConfig || {};

  const [loading, setLoading] = useState(false);
  const [dataGridLoading, setDataGridLoading] = useState(true);
  const [rows, setRows] = useState([]);
  const [remarks, setRemarks] = useState("");
  const [viewOpen, setViewOpen] = useState(false);
  const [viewData, setViewData] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [selectedRequestId, setSelectedRequestId] = useState(null);

  const exemptions = ["YEAR_END_PROFIT_TRANSFER"];

  const fetchData = useCallback(async () => {
    if (!requestType) return;
    try {
      let url = requestsUrl ? requestsUrl : PENDING_REQUESTS_URL;
      const payload = { requestType };

      if (exemptions.includes(requestType)) {
        url = ACTIVE_DOWNLOAD_URL;
      }

      const response = await callApi(url, payload, "POST");
      const result = response?.data || [];

      const data = result.map((row) => ({
        ...row,
        ...(typeof row.payload === "object" ? row.payload : {}),
      }));

      setRows(transformData ? transformData(data) : data);
    } catch (err) {
      console.error(err);
      showSnackBar("Error fetching data", "error");
    } finally {
      setRemarks("");
      setDataGridLoading(false);
      setConfirmDialog(false);
    }
  }, [requestType, requestsUrl, callApi, transformData, showSnackBar]);

  useEffect(() => {
    if (!screenConfig || !requestType) {
      return;
    }
    setRows([]);
    setRemarks("");
    setConfirmDialog(false);
    fetchData();
  }, [selectedMenuItem?.id, fetchData, screenConfig, requestType, navigate]);

  const closeConfirmDialog = useCallback(() => {
    setRemarks("");
    setConfirmDialog(false);
  }, []);

  const handleConfirm = async () => {
    if (selectedType === "reject" && remarks.trim().length < 5) {
      showSnackBar(
        "Please provide minimum 5 characters remarks before rejecting",
        "warning",
      );
      return;
    }
    setLoading(true);

    try {
      const payload = {
        requestId: selectedRequestId,
        status: selectedType === "reject" ? "REJECTED" : "ACCEPTED",
        remarks: selectedType === "reject" ? remarks : "No Remarks",
      };
      const url = patchUrl ? patchUrl : PATCH_URL;
      const res = await callApi(url, payload, "PATCH");

      if (res?.success || res) {
        showSnackBar(
          selectedType === "accept"
            ? `Request Id ${selectedRequestId} Approved Successfully`
            : `Request Id ${selectedRequestId} Rejected Successfully`,
          "success",
        );
        fetchData();
      } else {
        showSnackBar("Failed to process request: " + res?.message, "error");
      }
    } catch (err) {
      console.error(err);
      showSnackBar(err.message || "Error while processing request", "error");
    } finally {
      closeConfirmDialog();
      setLoading(false);
    }
  };

  const handleViewClick = useCallback(
    (data) => {
      const view = processViewData ? processViewData(data) : data;
      setViewData(view);
      setViewOpen(true);
    },
    [processViewData],
  );

  const openConfirmDialog = useCallback((type, id) => {
    setConfirmDialog(true);
    setSelectedType(type);
    setSelectedRequestId(id);
  }, []);

  const handleRemarksChange = useCallback(
    (e) => {
      const value = e.target.value;

      if (value && !/^[A-Za-z0-9]$/.test(value[0])) {
        showSnackBar("Should not start with a special character", "error");
        return;
      }

      const error = REMARKS_REGEX.test(value)
        ? ""
        : "Invalid Format. Only alphabets, numbers, spaces (single spaces between words), and ,()&/-. are allowed!";

      if (error) {
        showSnackBar(error, "warning");
        return;
      }

      setRemarks(value);
    },
    [showSnackBar],
  );

  const handleDownload = async () => {
    setLoading(true);
    try {
      const url = downloadUrl ? downloadUrl : DOWNLOAD_URL;
      const date = viewData.payload.date || viewData.reportDate;
      let reportType = viewData.reportType;

      if (requestType === "YEAR_END_PROFIT_TRANSFER") {
        if (
          viewData.reqStatus === "PENDING" ||
          viewData.reqStatus === "QUEUED"
        ) {
          reportType = "profit_transfer_report";
        }
      }

      const payload = { requestType, reportType, date };
      const responseData = await callApi(url, payload, "POST");
      const { reportName, reportDate, pdfBase64, excelBase64 } = responseData;

      let fileName = `${reportName}_${reportDate}`;

      if (!excelBase64) {
        showSnackBar("Failed to download file", "error");
        setLoading(false);
        return;
      }

      if (
        reportType === "profit_transactions" ||
        reportType === "profit_transfer_report"
      ) {
        downloadFile(responseData?.excelBase64, "excel", fileName, true);
        showSnackBar("File downloaded successfully", "success");
        return;
      } else if (!pdfBase64) {
        showSnackBar("Failed to download file", "error");
        setLoading(false);
        return;
      }

      downloadFile(responseData?.pdfBase64, "pdf", fileName, true);
      downloadFile(responseData?.excelBase64, "excel", fileName, true);
      showSnackBar("Files downloaded successfully", "success");
    } catch (err) {
      console.error(err);
      showSnackBar("Error while processing request", "error");
    } finally {
      setLoading(false);
    }
  };

  const allColumns = useMemo(() => {
    return [
      { field: "id", headerName: "Request Id", flex: 0.5, minWidth: 130 },

      // Dynamic columns from configs are injected here
      ...(columns || []),

      ...(selectedMenuItem?.id === 43
        ? [
            {
              field: "reqStatus",
              headerName: "Status",
              flex: 0.6,
              minWidth: 140,
              align: "center",
              headerAlign: "center",
              filterable: false,
              sortable: false,
              disableColumnMenu: true,
              renderCell: (p) => {
                const val = p.value;
                return (
                  <CustomChip
                    icon={
                      val === "QUEUE" ? (
                        <HourglassBottomIcon />
                      ) : val === "ACCEPTED" ? (
                        <CheckCircleIcon />
                      ) : (
                        <PendingActionsIcon />
                      )
                    }
                    label={
                      val === "QUEUE"
                        ? "In Queue"
                        : val === "ACCEPTED"
                          ? "Accepted"
                          : "Pending"
                    }
                    color={
                      val === "QUEUE"
                        ? "error"
                        : val === "ACCEPTED"
                          ? "success"
                          : "warning"
                    }
                    size="small"
                    variant="outlined"
                  />
                );
              },
            },
          ]
        : []),

      {
        field: "changeType",
        headerName: "Request type",
        flex: 0.6,
        minWidth: 150,
        align: "center",
        headerAlign: "center",
        filterable: false,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => {
          const val = p.value;
          return (
            <CustomChip
              sx={{
                width: 105,
                justifyContent: "flex-start",
              }}
              icon={
                val === "ADD" ? (
                  <AddBoxIcon />
                ) : val === "DELETE" ? (
                  <AutoDeleteIcon />
                ) : (
                  <EditDocumentIcon />
                )
              }
              label={
                val === "ADD"
                  ? "Added"
                  : val === "DELETE"
                    ? "Deleted"
                    : "Modified"
              }
              color={
                val === "ADD"
                  ? "success"
                  : val === "DELETE"
                    ? "error"
                    : "warning"
              }
              size="small"
              variant="outlined"
            />
          );
        },
      },

      {
        field: "creatorId",
        headerName: "Creator",
        flex: 0.8,
        minWidth: 160,
        align: "center",
        headerAlign: "center",
        filterable: false,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => (
          <CustomChip
            icon={<AccountCircleIcon />}
            size="small"
            color="info"
            label={p.value}
            variant="outlined"
          />
        ),
      },

      {
        field: "reqDate",
        headerName: "Requested Date",
        flex: 1,
        minWidth: 210,
        disableColumnMenu: true,
        renderCell: (p) => (
          <Typography variant="body1" component="span" sx={styles.requestDate}>
            {timeStampFormatter(p.value)}
          </Typography>
        ),
      },

      {
        field: "actions",
        headerName: "Actions",
        flex: 0.7,
        minWidth: 160,
        headerAlign: "center",
        align: "center",
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        renderCell: (p) => (
          <Stack
            direction="row"
            spacing={1}
            alignItems="center"
            justifyContent="center"
            style={styles.StackStyle}
          >
            <Tooltip title="View">
              <IconButton onClick={() => handleViewClick(p.row)}>
                <Visibility />
              </IconButton>
            </Tooltip>

            {p.row.reqStatus === "PENDING" && (
              <>
                <Tooltip title="Approve">
                  <IconButton
                    color="success"
                    onClick={() => openConfirmDialog("accept", p.row.id)}
                  >
                    <Check />
                  </IconButton>
                </Tooltip>

                <Tooltip title="Reject">
                  <IconButton
                    color="error"
                    onClick={() => openConfirmDialog("reject", p.row.id)}
                  >
                    <Clear />
                  </IconButton>
                </Tooltip>
              </>
            )}
          </Stack>
        ),
      },
    ];
  }, [columns, handleViewClick, openConfirmDialog, selectedMenuItem?.id]);

  // Optional per-screen note in the confirmation dialog. Only screens whose config defines
  // getApprovalNote (CGL_CODE) get one; for every other screen this is always null.
  const approvalNote = useMemo(() => {
    if (!getApprovalNote || !confirmDialog) return null;
    return getApprovalNote(
      rows.find((r) => r.id === selectedRequestId),
      selectedType,
    );
  }, [getApprovalNote, confirmDialog, rows, selectedRequestId, selectedType]);

  return (
    <Box sx={{
      ...styles.container,
      height:"calc(100vh - 120px)",
      minHeight:0, 
      boxSizing:"border-box",
      overflow:"hidden",
      display:"flex",
      flexDirection:"column",
    }}>
      {/* 
        Wrapped Both Components in a unified Card 
      */}
      <Card
        sx={{
          width: "100%",
          height: "calc(100vh - 125px)",
          minHeight: 0,
          boxShadow: 3,
          borderRadius: 2,
          bgcolor: "background.paper",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",

          "@media (max-width: 900px)": {
            height: "calc(100vh - 95px)",
          },

          "@media (max-width: 600px)": {
            height: "calc(100vh - 85px)",
          },
        }}
      >
        <RequestAnalytics data={rows} showDeleteRequest={showDeleteRequest} />

        {/* Divider provides a clean separation between the charts and the grid */}
        <Divider />

        <DataGrid
          rows={rows}
          columns={allColumns}
          loading={dataGridLoading}
          disableRowSelectionOnClick
          pageSizeOptions={[5, 10, 25, 50]}
          initialState={{
            pagination: { paginationModel: { pageSize: 5 } },
            sorting: { sortModel: [{ field: "reqDate", sort: "desc" }] },
          }}
          getRowId={(row) => row.id}
          sx={{
            ...styles.dataGrid,

            flex: 1,
            minHeight: 0,
            height: 0,
            maxHeight: "none",

            border: "none",

            overflow: "hidden",

            "& .MuiDataGrid-virtualScroller": {
              overflowX: "hidden !important",
            },

            "& .MuiDataGrid-columnHeaders": {
                          backgroundColor: "#f5f5f5 !important",
              borderTop: "none",
            },
            "& .MuiDataGrid-main": {
              overflow: "hidden",
            },
          }}
          slots={{
            noRowsOverlay: () => (
              <Stack height="100%" alignItems="center" justifyContent="center">
                <InfoIcon
                  sx={{ fontSize: 48, color: "text.secondary", mb: 2 }}
                />
                <Typography variant="h6">No Pending Requests Found</Typography>
                <Typography>
                  All {selectedMenuItem?.title} have been processed.
                </Typography>
              </Stack>
            ),
          }}
        />
      </Card>

      {/* View Dialog */}
      <ViewRequestDialog
        open={viewOpen}
        handleClose={() => setViewOpen(false)}
        data={viewData}
        screenConfig={screenConfig}
        handleDownload={handleDownload}
      />

      {/* Confirm Dialog */}
      <Dialog
        maxWidth="sm"
        fullWidth
        open={confirmDialog}
        onClose={closeConfirmDialog}
      >
        <DialogTitle>
          {selectedType === "accept" ? "Confirm Approval" : "Confirm Rejection"}
        </DialogTitle>
        <Divider />
        <DialogContent>
          <Typography>
            {selectedType === "accept"
              ? "Are you sure you want to approve the request?"
              : "Please provide remarks to reject this request."}
          </Typography>

          {/* Optional per-screen note (CGL: approval also versions the report templates) */}
          {approvalNote && (
            <Alert severity="info" sx={{ mt: 2 }}>
              {approvalNote}
            </Alert>
          )}

          {selectedType === "reject" && (
            <TextField
              fullWidth
              label="Remarks*"
              value={remarks}
              multiline
              rows={4}
              onChange={handleRemarksChange}
              margin="dense"
              slotProps={{
                htmlInput: {
                  maxLength: 200,
                },
              }}
              helperText={
                remarks?.length > 0 && remarks?.length < 5
                  ? "Enter at least 5 characters"
                  : "Allowed 5-200 characters (alphabets, numbers, spaces,()&,/-.)"
              }
              error={remarks?.length > 0 && remarks?.length < 5}
            />
          )}
        </DialogContent>

        <DialogActions>
           <Button onClick={closeConfirmDialog} 
          sx=
          {{
            "&:hover":
            {
              color:"#fff",
            },
            }}>
              Cancel
            </Button>
          <Button
            variant="contained"
            onClick={handleConfirm}
            color={selectedType === "accept" ? "success" : "error"}
          >
            {selectedType === "accept" ? "Approve" : "Reject"}
          </Button>
        </DialogActions>
      </Dialog>

      <LoadingOverlay loading={loading} />
    </Box>
  );
}
