import React from "react";
import { Box, Chip, Tooltip, Typography } from "@mui/material";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import CglRequestMappingPanel from "./CglRequestMappingPanel";
import { TEMPLATE_MAPPING_ENABLED, summarizeMappings } from "./templateMappingConfig";

/**
 * Everything the shared Common Request (checker) screen needs for CGL_CODE, in one place.
 * CommonConstants.js imports only CGL_REQUEST_SCREEN_EXTENSION; when TEMPLATE_MAPPING_ENABLED is false it is
 * empty and the CGL screen behaves exactly as before.
 */

/** Grid cell: how many Heads/Variables the request maps the CGL to. */
const renderMappingCountCell = (params) => {
  const list = params.row.templateMappings;
  if (!Array.isArray(list)) {
    return (
      <Typography variant="caption" color="text.secondary">
        -
      </Typography>
    );
  }
  return (
    <Tooltip title={summarizeMappings(list)}>
      <Chip size="small" variant="outlined" icon={<AccountTreeIcon />} label={`${list.length} mapped`} />
    </Tooltip>
  );
};

/** Extra block of the "Request Details" dialog: the requested mapping, compared with today's while pending. */
function CglViewExtras({ data }) {
  if (!data) return null;
  const cglNumber = data.cglCode || `${data.comp1 || ""}${data.segmentCode || ""}${data.comp2 || ""}`;
  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1.5 }}>
        <AccountTreeIcon color="primary" fontSize="small" />
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Report Template Mapping
        </Typography>
      </Box>
      <CglRequestMappingPanel
        cglNumber={cglNumber}
        changeType={data.changeType}
        reqStatus={data.reqStatus}
        mappings={data.templateMappings}
        executionRemarks={data.executionRemarks}
      />
    </Box>
  );
}

/** Note shown above the Approve button, so the checker knows approval also changes report templates. */
const getCglApprovalNote = (row, action) => {
  if (!row || action !== "accept") return null;
  if (row.changeType === "BLOCK" || row.changeType === "UNBLOCK") return null;
  if (!Array.isArray(row.templateMappings)) return null;
  const reports = Array.from(new Set(row.templateMappings.map((m) => m.reportId)));
  if (reports.length === 0 && row.changeType !== "UPDATE") return null;
  return reports.length
    ? `Approving also applies this CGL's mapping to the ${reports.join(", ")} template${reports.length > 1 ? "s" : ""} (a new version of each). If a template changed since the request was made, the approval is refused and the request stays pending.`
    : "Approving removes this CGL from all report templates it is currently mapped to.";
};

export const CGL_REQUEST_SCREEN_EXTENSION = TEMPLATE_MAPPING_ENABLED
  ? {
      columns: [
        {
          field: "templateMappings",
          headerName: "Template Mapping",
          flex: 0.6,
          minWidth: 170,
          align: "center",
          headerAlign: "center",
          sortable: false,
          filterable: false,
          disableColumnMenu: true,
          renderCell: renderMappingCountCell,
        },
      ],
      // merged into the CGL_CODE screen config; read by CommonRequestScreen / ViewRequestDialog
      screenProps: { ViewExtras: CglViewExtras, getApprovalNote: getCglApprovalNote },
    }
  : { columns: [], screenProps: {} };
