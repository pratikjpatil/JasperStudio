# Common Request screen: CGL hooks (manual version of the script)

Only needed if `apply_cgl_request_screen_edits.py` reports an anchor it cannot find. 8 small edits in 3 files.
Nothing changes for any screen except `CGL_CODE`: both hooks are optional and do nothing when a screen config does not define them.

## 1. `CommonRequestScreen.jsx`

**a) MUI import** add `Alert,`
```jsx
import {
  Alert,          // <- added
  Box,
  Button,
  Card, // Imported Card
```
**b) read the optional hook from the screen config**
```jsx
    showDeleteRequest = false,
    getApprovalNote, // <- added (optional per-screen hook, CGL_CODE only)
  } = screenConfig || {};
```
**c) just above `return (`** add
```jsx
  // Optional per-screen note in the confirmation dialog; only screens that define getApprovalNote
  const approvalNote = useMemo(() => {
    if (!getApprovalNote || !confirmDialog) return null;
    return getApprovalNote(
      rows.find((r) => r.id === selectedRequestId),
      selectedType,
    );
  }, [getApprovalNote, confirmDialog, rows, selectedRequestId, selectedType]);
```
**d) confirm dialog**, right after the `</Typography>` that ends with `"Please provide remarks to reject this request."}`
```jsx
          {approvalNote && (
            <Alert severity="info" sx={{ mt: 2 }}>
              {approvalNote}
            </Alert>
          )}
```

## 2. `ViewRequestDailog.jsx`

Inside `<DialogContent>`, after the `showTable` block and before `</DialogContent>`:
```jsx
        {/* Optional per-screen extras (CGL template mapping). Undefined for every other screen. */}
        {screenConfig?.ViewExtras && (
          <>
            <Divider sx={{ my: 2 }} />
            <screenConfig.ViewExtras data={data} />
          </>
        )}
```

## 3. `CommonConstants.js`

**a) import** (adjust the path to where `templateMapping/` lives)
```js
import { CGL_REQUEST_SCREEN_EXTENSION } from "../cgl/templateMapping/cglRequestScreenExtension";
```
**b) start of the `CGL_CODE` config**
```js
  CGL_CODE: {
    ...CGL_REQUEST_SCREEN_EXTENSION.screenProps,   // <- added
    columns: [
```
**c) end of the `CGL_CODE` columns**
```js
      {
        field: "description",
        headerName: "CGL Description",
        flex: 1.3,
        minWidth: 250,
      },
      ...CGL_REQUEST_SCREEN_EXTENSION.columns,      // <- added
    ],
```

## Switch off
Set `TEMPLATE_MAPPING_ENABLED = false` in `templateMappingConfig.js`: the extension becomes empty and the checker screen is identical to today.
