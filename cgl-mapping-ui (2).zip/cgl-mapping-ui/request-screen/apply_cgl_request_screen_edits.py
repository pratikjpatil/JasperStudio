#!/usr/bin/env python3
"""
Applies the small CGL-mapping hooks to the shared Common Request screen files.

    python apply_cgl_request_screen_edits.py \
        --screen    path/to/CommonRequestScreen.jsx \
        --dialog    path/to/ViewRequestDailog.jsx \
        --constants path/to/CommonConstants.js \
        [--extension-import "../cgl/templateMapping/cglRequestScreenExtension"]

Safe to re-run (already-applied edits are skipped). A .bak copy of every file is written first.
If an anchor text is not found the script stops without touching that file and tells you which edit to make by hand.
Nothing here changes any screen except CGL_CODE: the hooks are optional and do nothing when a screen config
does not define them.
"""
import argparse
import pathlib
import shutil
import sys


def edits(ext_import):
    screen = [
        (
            "MUI Alert import",
            "  Box,\n  Button,\n  Card, // Imported Card\n",
            "  Alert,\n  Box,\n  Button,\n  Card, // Imported Card\n",
        ),
        (
            "read optional getApprovalNote from the screen config",
            "    showDeleteRequest = false,\n  } = screenConfig || {};",
            "    showDeleteRequest = false,\n    getApprovalNote, // optional per-screen hook (CGL_CODE only)\n  } = screenConfig || {};",
        ),
        (
            "approval note memo",
            "  return (\n    <Box sx={{\n      ...styles.container,",
            "  // Optional per-screen note in the confirmation dialog; only screens that define getApprovalNote\n"
            "  const approvalNote = useMemo(() => {\n"
            "    if (!getApprovalNote || !confirmDialog) return null;\n"
            "    return getApprovalNote(\n"
            "      rows.find((r) => r.id === selectedRequestId),\n"
            "      selectedType,\n"
            "    );\n"
            "  }, [getApprovalNote, confirmDialog, rows, selectedRequestId, selectedType]);\n\n"
            "  return (\n    <Box sx={{\n      ...styles.container,",
        ),
        (
            "approval note in the confirm dialog",
            '              : "Please provide remarks to reject this request."}\n          </Typography>\n',
            '              : "Please provide remarks to reject this request."}\n          </Typography>\n\n'
            "          {approvalNote && (\n"
            '            <Alert severity="info" sx={{ mt: 2 }}>\n'
            "              {approvalNote}\n"
            "            </Alert>\n"
            "          )}\n",
        ),
    ]
    dialog = [
        (
            "ViewExtras block in the details dialog",
            "            <ViewCommonDynamicTable data={payload} />\n          </>\n        )}\n      </DialogContent>",
            "            <ViewCommonDynamicTable data={payload} />\n          </>\n        )}\n\n"
            "        {/* Optional per-screen extras (CGL template mapping). Undefined for every other screen. */}\n"
            "        {screenConfig?.ViewExtras && (\n"
            "          <>\n"
            "            <Divider sx={{ my: 2 }} />\n"
            "            <screenConfig.ViewExtras data={data} />\n"
            "          </>\n"
            "        )}\n"
            "      </DialogContent>",
        ),
    ]
    constants = [
        (
            "import the CGL extension",
            'import { currencyFormatterWith6Decimals } from "../../utils/NumberFormat";',
            'import { currencyFormatterWith6Decimals } from "../../utils/NumberFormat";\n'
            f'import {{ CGL_REQUEST_SCREEN_EXTENSION }} from "{ext_import}";',
        ),
        (
            "CGL_CODE: merge screen props",
            '  CGL_CODE: {\n    columns: [\n      { field: "cglCode", headerName: "CGL Code", flex: 0.5, minWidth: 140 },',
            '  CGL_CODE: {\n    ...CGL_REQUEST_SCREEN_EXTENSION.screenProps,\n    columns: [\n      { field: "cglCode", headerName: "CGL Code", flex: 0.5, minWidth: 140 },',
        ),
        (
            "CGL_CODE: template mapping column",
            '        headerName: "CGL Description",\n        flex: 1.3,\n        minWidth: 250,\n      },\n    ],',
            '        headerName: "CGL Description",\n        flex: 1.3,\n        minWidth: 250,\n      },\n      ...CGL_REQUEST_SCREEN_EXTENSION.columns,\n    ],',
        ),
    ]
    return {"screen": screen, "dialog": dialog, "constants": constants}


def apply(path, edit_list):
    p = pathlib.Path(path)
    raw = p.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    text = raw.replace("\r\n", "\n")
    new_text = text
    todo = []
    for name, old, new in edit_list:
        if new in new_text:
            print(f"  skip   (already applied): {name}")
            continue
        n = new_text.count(old)
        if n != 1:
            print(f"  FAILED {name}: anchor found {n} times in {p}. Apply this edit by hand (see EDITS.md).")
            return False
        new_text = new_text.replace(old, new)
        todo.append(name)
    if todo:
        shutil.copyfile(p, str(p) + ".bak")
        p.write_bytes((new_text.replace("\n", "\r\n") if crlf else new_text).encode("utf-8"))
        for name in todo:
            print(f"  done   {name}")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--screen", required=True)
    ap.add_argument("--dialog", required=True)
    ap.add_argument("--constants", required=True)
    ap.add_argument("--extension-import", default="../cgl/templateMapping/cglRequestScreenExtension")
    a = ap.parse_args()
    e = edits(a.extension_import)
    ok = True
    for key, path in (("screen", a.screen), ("dialog", a.dialog), ("constants", a.constants)):
        print(f"{key}: {path}")
        ok = apply(path, e[key]) and ok
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
